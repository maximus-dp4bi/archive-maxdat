insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (280,1,'Letter Request ID','Unique identifier for the letter/materials request, the email notification request, or the text message notification request.'); 
--insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (556,3,'Create Date','The date/time that the notification request was created in the source system.'); 7
--insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (557,2,'Created By','The name of the user/system that that created the notification request.');157
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (555,3,'Request Date','The date/time that the client notification was requested in the source system.');
--insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (559,2,'Instance Status','The Instance Status indicates if the notification request instance is in process or not.');66
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (556,2,'Letter Type','Indicates the specific type of letter requested.');
--insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (561,2,'Program','The Letter that is mailed will be specific to a single program in the source system.');476
--insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (562,1,'Case ID','The case id for the notification request.'); 479
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (557,2,'County Code','The county code for the mailing address of the letter.');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (558,1,'ZIP Code','The ZIP code for the mailing address of the letter.');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (559,2,'Language','The language that the letter was requested in.');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (560,2,'Reprint','Indicates if the letter request is a request a reprint of a previous letter.');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (561,2,'Request Driver Type','The Driver Type defines at what level the letter is being generated, either Case level or Client level.');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (562,2,'Request Driver Table','The table name which drives the letter.');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (281,2,'Letter Status','The status of the notification request in the source system.');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (309,3,'Letter Status Date','The date/time for the status in the source system.');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (563,3,'Sent Date','The date/time that the letter was sent to the mail vendor for printing and mailing.');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (564,3,'Print Date','The date/time that the letter was printed.');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (565,3,'Mailed Date','The date/time that the letter was mailed.');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (566,3,'Return Date','The date/time that the letter was returned.');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (567,2,'Return Reason','The letter return reason identifies why the letter was returned.');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (568,2,'Rejection Reason','The Reject Reason is the reason the mailhouse rejected the Letter Request.');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (569,2,'Request Error Reason','The Error Reason is the reason that the request could not be processed by the system and was not sent to the mailhouse.');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (570,2,'Transmitted File Name','The Letter File ID is the unique identifier of the interface file sent to the Mail House which contains the Letter Requests.  The Letter File ID identifies which File the Letter Request was transmitted on.');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (571,3,'Transmitted File Date','The Letter File Send Date is the date/time that the Letter interface file containing the Letter Request ID was sent to the Mail House by the system. (Transmitted Date)');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (572,2,'Letter Response File Name','The Letter Response File ID is the unique identifier of the interface file sent from the Mail House to the system that contains the outcome data of Letters sent. The Letter Response File ID identifies which File the Letter Request was transmitted on.');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (573,3,'Letter Response File Date','The Letter Response File Receive Date is the date/time that the Letter Response Interface file was received by the system from the Mail House.');
--insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (582,3,'Last Update Date','The date/time that the letter request was updated in the source system.');18
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (574,2,'Last Updated by Name','The name of the system or performer that updated the letter request in the source system.');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (575,2,'Newborn Flag','If a letter request has been generated for a case with a newly eligible newborn, set the flag to Y; else, N. This information should be retrieved from the details of the case associated with the letter request.');
--insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (585,1,'Task ID','The Task ID is the unique identifier of the task that is created in the source system as a result of an error during processing of the letter request reulting in additional work to address the cause of the error.'); 29
--insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (586,3,'Cancel Date','Date the notification was identifed as not required to be processed and was systematically or logically deleted or otherwise removed from the system.'); 47
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (576,2,'Cancel By','The name of the system or performer who cancelled the letter.');
--insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (588,3,'Complete Date','The date/time that the letter request instance completes the process.'); 5
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (577,3,'Process Ltr Request Start Date','Process Ltr Request Activity Step Start Date');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (578,3,'Process Ltr Request End Date','Process Ltr Request Activity Step End Date');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (579,3,'Send to Mail House Start Date','Send to Mail House Activity Step Start Date');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (580,3,'Send to Mail House End Date','Send to Mail House Activity Step End Date');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (581,3,'Receive Confirmation Start Date','Receive Confirmation Activity Step Start Date');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (582,3,'Receive Confirmation End Date','Receive Confirmation Activity Step End Date');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (583,3,'Create Route Work Star Date','Create Route Work Activity Step Start Date');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (584,3,'Create Route Work End Date','Create Route Work Activity Step End Date');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (585,2,'Process Letters Flag','Process Letters Activity Step Flag');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (586,2,'Transmit Flag','Transmit Activity Step Flag');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (587,2,'Confirmation Flag','Confirmation Activity Step Flag');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (588,2,'Create Route Work Flag','Create Route Work Activity Step Flag');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (589,2,'Validation Flag','Validation Gateway Flag');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (590,2,'Outcome Flag','Outcome Gateway Flag');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (171,2,'Work Required Flag','Work Required Gateway Flag'); 
--insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (604,1,'Age in Business Days','Number of Business Days from the Create Date to the Complete Date.'); 1
--insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (605,2,'Timeliness Status','Indicates if the letter request was processed timely or untimely based on project specific operational standards.'); 35
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (591,1,'Jeopardy Status','Indicates if the notification is in jeopardy of being processed untimely.');
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (592,1,'SLA Category','Establishes the category of the request into SLA compliance groups.');
--insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (608,1,'SLA Days','The number of days after which the letter request is determined to be processed untimely.'); 20
--insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (609,2,'SLA Days Type','Indicates if the SLA DAYS should be measured in Business Days or Calendar Days.'); 21 
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (123,1,'SLA Jeopardy Date','Date on which the letter request is determined to be in jeopardy of becoming untimely'); 
--insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (611,1,'SLA Jeopardy Days','Age at which time the letter request is determined to be in jeopardy of becoming untimely'); 22
--insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (612,1,'SLA Target Days','The number of days in which the letter request should be completed, as defined by the project'); 23
insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (593,1,'Client ID','The client id/s included in the letter request.  This list should NOT include any clients associated to a case that are NOT included in the letter (e.g. - for general notifications sent to the case head that do not include client names, this will be null.');
--insert into BPM_ATTRIBUTE_LKUP (BAL_ID,BDL_ID,NAME,PURPOSE) values (595,1,'Sub-Program','The Sub Program Type that is referenced for the clients included in the letter request.');477

COMMIT;