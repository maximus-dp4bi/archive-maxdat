insert into cc_a_list_lkup (name, list_type, value, out_var) values ('CA_LL_PROV_START_DATE','CA_LL_PROV_START_DATE', 'CA_LL_PROV_START_DATE', '03/01/2020');
commit;
