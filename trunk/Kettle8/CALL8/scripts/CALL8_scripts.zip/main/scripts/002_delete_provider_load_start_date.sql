delete cc_a_list_lkup where 
name = 'CA_LL_PROV_START_DATE'
and list_type = 'CA_LL_PROV_START_DATE'
and value = 'CA_LL_PROV_START_DATE';

commit;
