#!/bin/bash
# pa_run_planning.sh
# ================================================================================
# Do not edit these four SVN_* variable values.  They are populated when you
#     commit code to SVN and used later to identify deployed code.
# $URL: svn://svn-staging.maximus.com/dev1d/maxdat/trunk/Kettle8/PAIEB/ETL/scripts/pa_run_planning8.sh $
# $Revision: 25851 $
# $Date: 2019-01-03 14:19:04 -0800 (Thu, 03 Jan 2019) $
# $Author: aa24065 $
# ================================================================================
#  This shell is used to Run all but the first steps in Production Planning (the 
#    first step - Actuals - should run at the end of the BPM process).  The shell
#    is only needed for Production Planning
# ================================================================================
#----------------------------------------------------------------
#	Function for exit due to fatal program error
#		Accepts 1 argument:
#			string containing descriptive error message
#----------------------------------------------------------------
PROGNAME=$(basename $0 .sh)
function error_exit
{
	echo "${PROGNAME}: ${1:-'Unknown Error'}" 1>&2
	exit 1
}
function get_script_dir () {
     SOURCE="${BASH_SOURCE[0]}"
     # While $SOURCE is a symlink, resolve it
     while [ -h "$SOURCE" ]; do
          DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
          SOURCE="$( readlink "$SOURCE" )"
          # If $SOURCE was a relative symlink (so no "/" as prefix, need to resolve it relative to the symlink base directory
          [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE"
     done
     DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
     echo "$DIR"
}
#
SCRIPTDIR="$(get_script_dir)"
. $SCRIPTDIR/.set_env8.sh
#
# Echo Environment Variables
echo "STCODE=$STCODE"
echo "MAXDAT_ETL_PATH=$MAXDAT_ETL_PATH"
echo "MAXDAT_ETL_LOGS=$MAXDAT_ETL_LOGS"
echo "ENV_CODE=$ENV_CODE"
#
#mail related variables
EMAIL="toddamccracken@maximus.com"
EMAIL_MESSAGE="/tmp/${STCODE}-PPLAN-ERROR-LOG.txt"
EMAIL_SUBJECT="${STCODE}-PPlan-Errors in ${ENV_CODE}"
#
#checking for run file, Abort if it exists, create if it does not exists
if [[ -e $PLANNING_OK ]] ; then
   echo "Run Aborted - $PLANNING_OK exists"
   exit;
else
   echo "Starting ${STCODE}_run_planning.sh in ${ENV_CODE}."
   rm -f $EMAIL_MESSAGE $PLANNING_FAIL
   touch $PLANNING_OK
fi
#
#init check
$MAXDAT_KETTLE_DIR/kitchen.sh -file="$MAXDAT_ETL_PATH/Planning_Init_check.kjb" -level="$KJB_LOG_LEVEL" >> $MAXDAT_ETL_LOGS/Planning_Init_check_$(date +%Y%m%d_%H%M%S).log
rc=$?
if [[ $rc != 0 ]] ; then
   echo "Exited with status: $rc - ${STCODE} Planning_Init_check.kjb, aborting run" >> $EMAIL_MESSAGE
   rm -f $PLANNING_OK
   mail -s "$EMAIL_SUBJECT" "$EMAIL" < $EMAIL_MESSAGE
   cat $EMAIL_MESSAGE
   exit $rc
else
   $MAXDAT_ETL_PATH/run_kjb.sh $MAXDAT_ETL_PATH/ProductionPlanning/PP_Forecast_RUNALL.kjb $KJB_LOG_LEVEL >> $MAXDAT_ETL_LOGS/PP_Forecast_RUNALL_$(date +%Y%m%d_%H%M%S).log &
   wait
   #$MAXDAT_ETL_PATH/run_kjb.sh $MAXDAT_ETL_PATH/ProductionPlanning/PP_Actuals_Import_RUNALL.kjb $KJB_LOG_LEVEL >> $MAXDAT_ETL_LOGS/PP_Actuals_Import_RUNALL_$(date +%Y%m%d_%H%M%S).log &
   #wait
   if [[ -e $PLANNING_FAIL ]]
   then
      #a child process failed, abort mission
      echo "$STCODE - One or more Planning subtasks failed.  Check error logs and $PLANNING_FAIL for more details." >> $EMAIL_MESSAGE
      rm -f $PLANNING_OK
      mail -s "$EMAIL_SUBJECT" "$EMAIL" < $EMAIL_MESSAGE
      cat $EMAIL_MESSAGE
      error_exit "$LINENO: $STCODE - A Child Planning error has occurred."
   else
      #success, move on
      echo "$STCODE - Child Planning processes completed successfully."
      rm -f $PLANNING_OK
      exit 0
   fi	
fi
#
#pan status codes
# 0 	The transformation ran without a problem.
# 1 	Errors occurred during processing
# 2 	An unexpected error occurred during loading / running of the transformation
# 3 	Unable to prepare and initialize this transformation
# 7 	The transformation couldn't be loaded from XML or the Repository
# 8 	Error loading steps or plugins (error in loading one of the plugins mostly)
# 9 	Command line usage printing
#
#kitchen status codes
# 0 	The job ran without a problem.
# 1 	Errors occurred during processing
# 2 	An unexpected error occurred during loading or running of the job
# 7 	The job couldn't be loaded from XML or the Repository
# 8 	Error loading steps or plugins (error in loading one of the plugins mostly)
# 9 	Command line usage printing
