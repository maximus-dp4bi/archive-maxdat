#!/bin/sh
rm /u01/maximus/maxdat/NYEC8/scripts/run_init_check.txt
rm /tmp/child_task_fail.txt
