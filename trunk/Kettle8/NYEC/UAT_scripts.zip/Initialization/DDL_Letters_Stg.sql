alter table letters_stg 
add letter_created_by VARCHAR2(80);