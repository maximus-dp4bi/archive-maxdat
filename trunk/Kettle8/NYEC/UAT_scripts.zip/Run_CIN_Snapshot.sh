#!/bin/sh
source /u01/maximus/maxdat/NYEC8/config/.set_env

# Do not edit these four SVN_* variable values.  They are populated when you commit code to SVN
#    and used later to identify deployed code. 
# $URL: svn://rcmxapp1d.maximus.com/maxdat/trunk/ETL/scripts/Run_CIN_Snapshot.sh $
# $Revision: 6213 $
# $Date: 2013-10-16 19:03:42 -0400 (Wed, 16 Oct 2013) $
# $Author: dh24064 $

#---------------------------
#redefining these paths here to keep them separate frm IL

LOG_LEVEL="Basic"

                                                                                                   
$MAXDAT_KETTLE_DIR/pan.sh -file="$MAXDAT_ETL_PATH/$MODULE_INIT/LOAD_CIN_SNAPSHOT.ktr" -log="$MAXDAT_LOG_DIR/$MODULE_INIT/LOAD_CIN_SNAPSHOT.log" -level="$LOG_LEVEL" 
