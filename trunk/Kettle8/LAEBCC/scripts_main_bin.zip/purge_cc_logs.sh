#!/bin/bash
. /u01/maximus/maxdat-uat/LAEBCC8/scripts/ContactCenter/implementation/LAEB/bin/.set_env

# purge_cc_logs.sh
# ====================================================================================================================================================================
# Do not edit these four SVN_* variable values.  They are populated when
#    you commit code to SVN and used later to identify deployed code.
# $URL: svn://svn-staging.maximus.com/dev1d/maxdat/ContactCenter/trunk/kettle/MAXDAT/implementation/LAEB/bin/purge_cc_logs.sh $
# $Revision: 23098 $
# $Date: 2018-04-20 13:42:19 -0400 (Fri, 20 Apr 2018) $
# $Author: TM151500 $
# ====================================================================================================================================================================
# Script Name:  purge_cc_logs.sh
# Purpose:      This script removes all files from the Contact Center log file directory, $MAXDAT_ETL_LOGS/ContactCenter, that are older than 
#               a number of days specified by $LOG_LIFE_DAYS.  The variables $MAXDAT_ETL_LOGS and $LOG_LIFE_DAYS are specificed in the .set_env_vars.sh file.
#
#               This script writes the log files that will be deleted to the script's log file.  An optional parameter dictates the MODE of the script.  
#               If a value of D is passed, then the files are removed from the the log directory.  Otherwise, the files that would be deleted are written to the
#               script's log, and no files are removed from the directory. 
#
# Important:    Make sure that cron knows $MD_SETENV. 
# 
# WHO		WHEN		WHAT
# ===		====		====
# TAM		04/16/2018	Modified script to preview and delete log files.
# TAM           04/17/2018      Added code to count the number of files that will be deleted.
# TAM		04/19/2018	Added logic to default MODE based on environment, assuming it is not supplied.
# ====================================================================================================================================================================


MODE="$1"
SCRIPT_LOG_TIMESTAMP=$(date +%Y%m%d_%H%M%S)
ETL_LOG_PATH=$MAXDAT_ETL_LOGS/ContactCenter
SCRIPT_LOG_PATH=$MAXDAT_ETL_LOGS/ContactCenter
SCRIPT_LOG_FILE_NAME=purge_cc_logs_$SCRIPT_LOG_TIMESTAMP.log
SCRIPT_LOG=$SCRIPT_LOG_PATH/$SCRIPT_LOG_FILE_NAME
SCRIPT_ENV_CODE=$ENV_CODE

# If the current environment is dev, then force the mode to preview (P), if the mode was not specified as D (delete) for the first parameter.
# If the current environment is not dev, then force the mode to delete (D), if the mode was not specified as P (preview) for the first parameter.

if [ "$SCRIPT_ENV_CODE" = "dev" ]
then
  if [ "$MODE" != "D" ]
  then
    MODE="P"  
  fi
else
  if [ "$MODE" != "P" ]
  then
    MODE="D"  
  fi
fi

function cleanLogDirectory () {

    local P_MODE="$1"
    local P_LOG_LIFE_DAYS="$2"
    local P_LOG_DIR="$3"
    local P_SCRIPT_LOG="$4"

    echo "Scanning directory $P_LOG_DIR..." >> "$P_SCRIPT_LOG"

    NUM_LOG_FILES_TO_DEL=$(find $P_LOG_DIR -type f -ctime +$P_LOG_LIFE_DAYS | wc -l)

    if [ "$NUM_LOG_FILES_TO_DEL" != "0" ] 
    then

      echo "Found $NUM_LOG_FILES_TO_DEL file(s) older than $P_LOG_LIFE_DAYS day(s) old..." >> "$P_SCRIPT_LOG"
      find $P_LOG_DIR -type f -ctime +$P_LOG_LIFE_DAYS >> "$P_SCRIPT_LOG"

      if [ "$P_MODE" = "D" ]
      then
        echo "Started deleting files at $(date +%Y%m%d_%H%M%S)..." >> "$P_SCRIPT_LOG"
        find $P_LOG_DIR -type f -ctime +$P_LOG_LIFE_DAYS -delete >> "$P_SCRIPT_LOG"
        echo "Finished deleting files at $(date +%Y%m%d_%H%M%S)..." >> "$P_SCRIPT_LOG"
      fi
    else
      echo "There are no files that are older than $P_LOG_LIFE_DAYS days old..." >> "$P_SCRIPT_LOG"
    fi
}

echo "Calling function cleanLogDirectory with parameters P_MODE=$MODE, P_LOG_LIFE_DAYS=$LOG_LIFE_DAYS, P_LOG_DIR=$ETL_LOG_PATH, P_SCRIPT_LOG=$SCRIPT_LOG" >> "$SCRIPT_LOG"
cleanLogDirectory $MODE $LOG_LIFE_DAYS $ETL_LOG_PATH $SCRIPT_LOG
