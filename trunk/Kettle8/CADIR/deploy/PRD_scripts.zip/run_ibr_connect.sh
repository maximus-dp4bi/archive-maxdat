#!/bin/bash
export MD_SETENV=/u01/maximus/maxdat-prd/CADIR8/scripts/.set_env
. $MD_SETENV
#run_ibr_connect.sh 
# ================================================================================
# Do not edit these four SVN_* variable values.  They are populated when you
#     commit code to SVN and used later to identify deployed code.
# $URL: svn://svn-staging.maximus.com/dev1d/maxdat/trunk/Kettle8/CADIR/Scripts/run_ibr_connect.sh $
# $Revision: 28616 $
# $Date: 2020-01-07 15:58:13 -0500 (Tue, 07 Jan 2020) $
# $Author: fm18957 $
# ================================================================================
# This is an AdHoc Test shell you can run to test database/mail server connections
# Run the Init Check to see if resources are available
# ================================================================================
$MAXDAT_KETTLE_DIR/kitchen.sh -file="$MAXDAT_ETL_PATH/Check_IBR_Connect.kjb" -level="$KJB_LOG_LEVEL"  > $MAXDAT_ETL_LOGS/${STCODE}_run_ibr_connect_$(date +%Y%m%d_%H%M%S).log

