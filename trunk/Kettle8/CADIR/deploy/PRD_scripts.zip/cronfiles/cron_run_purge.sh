#!/bin/bash
export MD_SETENV=/u01/maximus/maxdat-prd/CADIR8/scripts/.set_env
source $MD_SETENV
#cron_purge_files.sh
# ================================================================================
# Do not edit these four SVN_* variable values.  They are populated when you
#     commit code to SVN and used later to identify deployed code.
# $URL: svn://svn-staging.maximus.com/dev1d/maxdat/trunk/Kettle8/CADIR/Scripts/cronfiles/prd_cron_run_purge.sh $
# $Revision: 28140 $
# $Date: 2019-10-15 10:15:19 -0700 (Tue, 15 Oct 2019) $
# $Author: aa24065 $
# ================================================================================
# This is a cron job to purge old logs
# ================================================================================
$MAXDAT_ETL_PATH/cadir_pruge_logs.sh


