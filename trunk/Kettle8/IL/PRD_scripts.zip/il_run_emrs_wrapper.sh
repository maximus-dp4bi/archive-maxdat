!/usr/bin
/u01/maximus/maxdat/IL8/scripts/il_run_emrs.sh | /bin/sed "s/^/$(date)/ " >> /u01/maximus/maxdat/IL8/logs/$MODULE_INIT/il_run_emrs.log
#/u01/maximus/maxdat-prd/IL/ETL/scripts/il_run_emrs.sh  >> /u01/maximus/maxdat-prd/IL/ETL/logs/il_run_emrs.log
