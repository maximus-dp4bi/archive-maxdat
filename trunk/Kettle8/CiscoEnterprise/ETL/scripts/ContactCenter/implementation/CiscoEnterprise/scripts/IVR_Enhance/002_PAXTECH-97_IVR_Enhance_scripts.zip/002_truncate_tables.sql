truncate table cc_c_ivr_ctrls;
truncate table cc_f_ivr_performance_instance;
truncate table cc_s_ivr_ciscocvp;
truncate table cc_s_ivr_performance_instance_ext;
truncate table cc_s_tmp_class_run;
