insert into cc_a_ivr_job (job_name, job_description, daily_run_enabled, enabled)
values ('LOAD_IVR_RESP', 'Load IVR Response', 'N', 'Y');

commit;
