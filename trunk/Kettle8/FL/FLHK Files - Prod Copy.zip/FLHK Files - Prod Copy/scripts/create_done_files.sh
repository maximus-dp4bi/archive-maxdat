#!/bin/bash
. ~/.bash_profile
date > $MAXDAT_LOG_DIR/ManageWork_done.txt
date > $MAXDAT_LOG_DIR/MonitorDisputes_done.txt 
date > $MAXDAT_LOG_DIR/ProcessApplications_Done.txt 
date > $MAXDAT_LOG_DIR/ProcessDocuments_V2_done.txt 
date > $MAXDAT_LOG_DIR/ProcessLetters_done.txt
date > $MAXDAT_LOG_DIR/SupportMemberInquiry_done.txt
date > $MAXDAT_LOG_DIR/MailFaxBatch_done.txt
