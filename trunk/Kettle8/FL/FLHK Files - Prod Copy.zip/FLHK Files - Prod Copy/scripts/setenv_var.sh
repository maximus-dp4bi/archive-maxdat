#----NEW ".setenv_var.sh"-----
# .set_env - [FLHK]
# corp_set_env.txt
# =======================================================================
# Do not edit these four SVN_* variable values.  They are populated when
#    you commit code to SVN and used later to identify deployed code.
# $URL: svn://svn-staging.maximus.com/dev1d/maxdat/trunk/NYEC7/scripts/.setenv_var7.sh $
# $Revision: 21202 $
# $Date: 2017-09-14 16:17:40 -0600 (Thu, 14 Sep 2017) $
# $Author: iv136523 $
# =======================================================================
#
# Set all of the exported environment variables in this file
# All lines marked with a "->" need to be set for the local server (and the "->" removed)
# -----  MAXDAT VARIABLES  ----
export HOSTNAME=$(hostname)
export JAVA_HOME="/opt/jdk1.8.0_192"
export PDI_VERSION="8.2"
export PENTAHO_JAVA_HOME="/opt/jdk1.8.0_192"
export MAXDAT_KETTLE_DIR="/opt/pentaho8/data-integration"
export MAXDAT_ETL_PATH="/opt/maxdat/FLHK8/scripts"
export MAXDAT_ETL_LOGS="/opt/maxdat/FLHK8/logs"
export MAXDAT_LOG_DIR=$MAXDAT_ETL_LOGS
export KETTLE_HOME="/home/etladmin"
export KTR_LOG_LEVEL="Basic"
export KJB_LOG_LEVEL="Detailed"
PATH="$KETTLE_HOME/.kettle/kettle.properties:.:/opt/pentaho8/data-integration:/usr/bin:/sbin:$PATH"
export PATH
export SCRIPTS_DIR=$MAXDAT_KETTLE_DIR
export CUSTOM_DIR=$MAXDAT_ETL_PATH
#
#mail related variables
export EMAIL="MAXDatSystem@maximus.com"
#
#
# ----  OTHER VARIABLES  ----
export LOG_LIFE_DAYS=30 # Number of days to keep log files in the log directory before deleteing
