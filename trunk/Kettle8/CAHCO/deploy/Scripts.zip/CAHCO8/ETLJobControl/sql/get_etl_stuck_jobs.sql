/*
	Do not edit these four SVN_* variable values.  They are populated when you commit code to SVN and used later to identify deployed code.
    SVN_FILE_URL varchar2(200) := '$URL: svn://svn-staging.maximus.com/dev1d/maxdat/trunk/ETL_Job_Control/ETL/sql/get_etl_stuck_jobs.sql $'; 
    SVN_REVISION varchar2(20) := '$Revision: 30599 $'; 
    SVN_REVISION_DATE varchar2(60) := '$Date: 2020-08-18 20:22:56 -0400 (Tue, 18 Aug 2020) $'; 
    SVN_REVISION_AUTHOR varchar2(20) := '$Author: ss153729 $';
*/

set feedback off
set heading off
set linesize 6000
set newpage none
set verify off

define v_column_separator = ';'

select 
  JOB_ID||'&v_column_separator'||
  PROJECT_NAME||'&v_column_separator'||
  JOB_NAME||'&v_column_separator'||
  JOB_TYPE||'&v_column_separator'||
  PARENT_JOB_ID||'&v_column_separator'||
  JOB_SCRIPT_NAME||'&v_column_separator'||
  JOB_LOG_PATH||'&v_column_separator'||
  JOB_NEXT_EXEC_DT
from ETL_JOB_LIST
where JOB_STUCK='Y'
order by JOB_ID asc;

exit;
