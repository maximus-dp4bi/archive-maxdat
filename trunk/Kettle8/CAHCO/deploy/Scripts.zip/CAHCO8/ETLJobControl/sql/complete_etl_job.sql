/*
	Do not edit these four SVN_* variable values.  They are populated when you commit code to SVN and used later to identify deployed code.
    SVN_FILE_URL varchar2(200) := '$URL: svn://svn-staging.maximus.com/dev1d/maxdat/trunk/ETL_Job_Control/ETL/sql/complete_etl_job.sql $'; 
    SVN_REVISION varchar2(20) := '$Revision: 30597 $'; 
    SVN_REVISION_DATE varchar2(60) := '$Date: 2020-08-18 20:20:00 -0400 (Tue, 18 Aug 2020) $'; 
    SVN_REVISION_AUTHOR varchar2(20) := '$Author: ss153729 $';
*/
set feedback off
set heading off
set linesize 5000
set newpage none
set verify off

define p_job_id = &1

BEGIN
    ETL_JOB.COMPLETE_ETL_JOB(&p_job_id);
    COMMIT;
END;
/

exit;
