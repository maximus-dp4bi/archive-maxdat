/*
	Do not edit these four SVN_* variable values.  They are populated when you commit code to SVN and used later to identify deployed code.
    SVN_FILE_URL varchar2(200) := '$URL: svn://svn-staging.maximus.com/dev1d/maxdat/trunk/ETL_Job_Control/ETL/sql/set_etl_jobs.sql $'; 
    SVN_REVISION varchar2(20) := '$Revision: 29993 $'; 
    SVN_REVISION_DATE varchar2(60) := '$Date: 2020-06-17 12:56:03 -0400 (Wed, 17 Jun 2020) $'; 
    SVN_REVISION_AUTHOR varchar2(20) := '$Author: ss153729 $';
*/

set feedback off
set heading off
set linesize 5000
set newpage none
set verify off

BEGIN
    ETL_JOB.SET_ETL_JOBS;
    COMMIT;
END;
/

exit;
