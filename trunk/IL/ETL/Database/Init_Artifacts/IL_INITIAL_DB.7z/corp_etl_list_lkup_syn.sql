-- Create the synonym 
create or replace public synonym CORP_ETL_LIST_LKUP
  for MAXDAT.CORP_ETL_LIST_LKUP;
