-- Create the synonym 
create or replace public synonym STAFF_STG
  for MAXDAT.STAFF_STG;
