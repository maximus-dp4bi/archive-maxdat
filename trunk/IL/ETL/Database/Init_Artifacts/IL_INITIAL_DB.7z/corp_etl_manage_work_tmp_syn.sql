-- Create the synonym 
create or replace public synonym CORP_ETL_MANAGE_WORK_TMP
  for MAXDAT.CORP_ETL_MANAGE_WORK_TMP;
