-- Create the synonym 
create or replace public synonym CORP_ETL_MANAGE_WORK
  for MAXDAT.CORP_ETL_MANAGE_WORK;
