-- Create the synonym 
create or replace public synonym GROUPS_STG
  for MAXDAT.GROUPS_STG;
