-- Create the synonym 
create or replace public synonym CORP_ETL_LIST_LKUP_HIST
  for MAXDAT.CORP_ETL_LIST_LKUP_HIST;
