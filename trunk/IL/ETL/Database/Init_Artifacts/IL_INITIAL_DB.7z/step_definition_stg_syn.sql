-- Create the synonym 
create or replace public synonym STEP_DEFINITION_STG
  for MAXDAT.STEP_DEFINITION_STG;
