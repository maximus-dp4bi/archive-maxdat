-- Create the synonym 
create or replace public synonym STEP_INSTANCE_STG
  for MAXDAT.STEP_INSTANCE_STG;
