spool il_maxdat_runall.log

@@corp_etl_control_ddl.sql
@@corp_etl_control_syn.sql
echo ---------
@@corp_etl_list_lkup_ddl.sql
@@corp_etl_list_lkup_syn.sql
echo ---------
@@corp_etl_list_lkup_hist_ddl.sql
@@corp_etl_list_lkup_hist_syn.sql
echo ---------
@@corp_etl_manage_work_ddl.sql
@@corp_etl_manage_work_syn.sql
echo ---------
@@corp_etl_manage_work_tmp_ddl.sql
@@corp_etl_manage_work_tmp_syn.sql
echo ---------
@@groups_stg_dll.sql
@@groups_stg_syn.sql
echo ---------
@@holidays_ddl.sql
@@holidays_syn.sql
echo ---------
@@staff_stg_ddl.sql
@@staff_stg_syn.sql
echo ---------
@@step_definition_stg_ddl.sql
@@step_definition_stg_syn.sql
echo ---------
@@step_instance_stg_ddl.sql
@@step_instance_stg_syn.sql
echo ---------
@@Seq_holiday_Id.sql
@@CELL_HISTORY_SEQ.sql
@@Seq_cemw_Id.sql
@@seq_cec.sql
@@Seq_cell_Id.sql
echo ---------
@@STAFF_LKUP_VW.sql
@@MW_STEP_INSTANCE_VW.sql
echo ---------
@@TRG_BIU_R_HOLIDAYS.trg
@@TRG_cec.trg
@@TRG_R_AIUD_ETL_LIST_LKUP_HIST.trg
@@TRG_R_CORP_ETL_MANAGE_WORK.trg
@@TRG_R_ETL_LIST_LKUP.trg
echo ---------
@@BUS_DAYS_BETWEEN.fnc
@@get_bus_date.fnc
echo ---------
@@INS_corp_etl_control_init.sql
echo ---------
spool off
