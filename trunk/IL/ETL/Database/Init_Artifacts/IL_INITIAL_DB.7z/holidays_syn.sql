-- Create the synonym 
create or replace public synonym HOLIDAYS
  for MAXDAT.HOLIDAYS;
