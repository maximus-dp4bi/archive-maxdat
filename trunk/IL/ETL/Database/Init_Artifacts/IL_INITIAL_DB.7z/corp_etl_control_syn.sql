-- Create the synonym 
create or replace public synonym CORP_ETL_CONTROL
  for MAXDAT.CORP_ETL_CONTROL;
