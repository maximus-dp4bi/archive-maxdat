CREATE OR REPLACE PACKAGE CAHCO_ETL_MW_UTIL_PKG AS

    FUNCTION    is_true
    RETURN                                                                      PLS_INTEGER;
    
    FUNCTION    is_false
    RETURN                                                                      PLS_INTEGER;

    FUNCTION    get_unknown_staff_id
    RETURN                                                                      PLS_INTEGER;

    FUNCTION    get_unknown_business_unit_id
    RETURN                                                                      PLS_INTEGER;

    FUNCTION    get_unknown_team_id
    RETURN                                                                      PLS_INTEGER;

    FUNCTION    get_unknown_dcn
    RETURN                                                                      VARCHAR2;

    FUNCTION    get_unknown_client_number
    RETURN                                                                      PLS_INTEGER;

    FUNCTION    get_unknown_ref_type
    RETURN                                                                      VARCHAR2;

    FUNCTION    get_unknown_ref_id
    RETURN                                                                      PLS_INTEGER;

    FUNCTION    automatically_claimed
    RETURN                                                                      VARCHAR2;

    FUNCTION    claimed_on_ownership_change
    RETURN                                                                      VARCHAR2;
    
    FUNCTION    get_corp_etl_control_date
                (
                    p_NAME                              IN                      CORP_ETL_CONTROL.name%TYPE
                )
    RETURN                                                                      DATE;    

    FUNCTION    get_corp_etl_control_number
                (
                    p_NAME                              IN                      CORP_ETL_CONTROL.name%TYPE
                )
    RETURN                                                                      NUMBER;
    
    FUNCTION    get_corp_etl_control_string
                (
                    p_NAME                              IN                      CORP_ETL_CONTROL.name%TYPE
                )
    RETURN                                                                      VARCHAR2;                
    
    PROCEDURE   set_corp_etl_control_string
                (
                    p_NAME                              IN                      CORP_ETL_CONTROL.name%TYPE,
                    p_STRING                            IN                      VARCHAR2
                );
                
    PROCEDURE   set_corp_etl_control_date
                (
                    p_NAME                              IN                      CORP_ETL_CONTROL.name%TYPE,
                    p_DATE                              IN                      DATE
                );
                

    FUNCTION    get_team_biz_unit_id
                (
                    p_TEAM_ID                           IN                      GROUPS_STG.group_id%TYPE,
                    p_LEVEL                             IN                      VARCHAR2
                )
    RETURN                                                                      GROUPS_STG.group_id%TYPE;

    PROCEDURE   get_staff_team_biz_unit_ids
                (
                    p_STAFF_KEY                         IN                      STAFF_KEY_LKUP.staff_key%TYPE,
                    p_TEAM_ID                                       OUT         D_TEAMS.team_id%TYPE,
                    p_BUSINESS_UNIT_ID                              OUT         D_BUSINESS_UNITS.business_unit_id%TYPE
                );                

    FUNCTION    get_staff_id
                (
                    p_EXT_STAFF_NUMBER                  IN                      D_STAFF.ext_staff_number%TYPE
                )
    RETURN                                                                      D_STAFF.staff_id%TYPE;
                    
END CAHCO_ETL_MW_UTIL_PKG;
/
CREATE OR REPLACE PACKAGE BODY CAHCO_ETL_MW_UTIL_PKG AS

    c_int_true                                                                  PLS_INTEGER                             :=                  1;
    c_int_false                                                                 PLS_INTEGER                             :=                  0;

    c_unknown_staff_id                                                          PLS_INTEGER                             :=                  0;
    c_unknown_business_unit_id                                                  PLS_INTEGER                             :=                  0;
    c_unknown_team_id                                                           PLS_INTEGER                             :=                  1;

    c_unknown_dcn                                                               VARCHAR2(2)                             :=                  '?';
    c_unknown_client_number                                                     PLS_INTEGER                             :=                  0;

    c_unknown_ref_type                                                          VARCHAR2(2)                             :=                  '?';
    c_unknown_ref_id                                                            PLS_INTEGER                             :=                  0;

    c_claimed_on_ownership_change                                               VARCHAR2(100)                           :=                  'CLAIMED ON OWNERSHIP CHANGE';
    c_automatically_claimed                                                     VARCHAR2(100)                           :=                  'AUTOMATICALLY CLAIMED';
    
    /*****************************************************************************************************************************************************************

        NAME:           is_true
        DESCRIPTION:    Return c_int_true.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    FUNCTION    is_true
    RETURN                                                                      PLS_INTEGER
    IS
    BEGIN

        RETURN  c_int_true;

    END         is_true;        
    /*****************************************************************************************************************************************************************

        NAME:           is_false
        DESCRIPTION:    Return c_int_false.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    FUNCTION    is_false
    RETURN                                                                      PLS_INTEGER
    IS
    BEGIN

        RETURN  c_int_false;

    END         is_false;            
    /*****************************************************************************************************************************************************************

        NAME:           claimed_on_ownership_change
        DESCRIPTION:    Return c_claimed_on_ownership_change.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    FUNCTION    claimed_on_ownership_change
    RETURN                                                                      VARCHAR2
    IS
    BEGIN

        RETURN  c_claimed_on_ownership_change;

    END         claimed_on_ownership_change;        
    /*****************************************************************************************************************************************************************

        NAME:           automatically_claimed
        DESCRIPTION:    Return c_automatically_claimed.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    FUNCTION    automatically_claimed
    RETURN                                                                      VARCHAR2
    IS
    BEGIN

        RETURN  c_automatically_claimed;

    END         automatically_claimed;        
    /*****************************************************************************************************************************************************************

        NAME:           get_corp_etl_control_date
        DESCRIPTION:    Get the corp etl control date associated with p_NAME.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    FUNCTION    get_corp_etl_control_date
                (
                    p_NAME                              IN                      CORP_ETL_CONTROL.name%TYPE
                )
    RETURN                                                                      DATE
    IS
        l_corp_etl_control_date                                                 DATE;
    BEGIN

        BEGIN

            SELECT  TO_DATE(cec.value, 'YYYY/MM/DD HH24:MI:SS')
              INTO  l_corp_etl_control_date
              FROM  CORP_ETL_CONTROL                                cec
             WHERE  cec.name                                    =   p_NAME;
             
        EXCEPTION
        
            WHEN    NO_DATA_FOUND
            THEN    l_corp_etl_control_date  :=  NULL;
                
        END;
        
        RETURN  l_corp_etl_control_date;
        
    END         get_corp_etl_control_date;
    /*****************************************************************************************************************************************************************

        NAME:           set_corp_etl_control_date
        DESCRIPTION:    Set the corp etl control date associated with p_NAME.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    PROCEDURE   set_corp_etl_control_date
                (
                    p_NAME                              IN                      CORP_ETL_CONTROL.name%TYPE,
                    p_DATE                              IN                      DATE
                )
    IS
    BEGIN

        IF  p_DATE IS NOT NULL
        THEN
                    
            UPDATE  CORP_ETL_CONTROL        cec
               SET  value               =   TO_CHAR(p_date, 'YYYY/MM/DD HH24:MI:SS')
             WHERE  cec.name            =   p_NAME;
             
            COMMIT;             

        END IF;

    END         set_corp_etl_control_date;
    /*****************************************************************************************************************************************************************

        NAME:           get_corp_etl_control_number
        DESCRIPTION:    Get the corp etl control number associated with p_NAME.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    FUNCTION    get_corp_etl_control_number
                (
                    p_NAME                              IN                      CORP_ETL_CONTROL.name%TYPE
                )
    RETURN                                                                      NUMBER
    IS
        l_corp_etl_control_number                                               NUMBER;
    BEGIN

        BEGIN

            SELECT  TO_NUMBER(cec.value)
              INTO  l_corp_etl_control_number
              FROM  CORP_ETL_CONTROL                                cec
             WHERE  cec.name                                    =   p_NAME;
             
        EXCEPTION
        
            WHEN    NO_DATA_FOUND
            THEN    l_corp_etl_control_number  :=  NULL;
                
        END;
        
        RETURN  l_corp_etl_control_number;
        
    END         get_corp_etl_control_number;  
    /*****************************************************************************************************************************************************************

        NAME:           get_corp_etl_control_string
        DESCRIPTION:    Get the corp etl control string associated with p_NAME.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    FUNCTION    get_corp_etl_control_string
                (
                    p_NAME                              IN                      CORP_ETL_CONTROL.name%TYPE
                )
    RETURN                                                                      VARCHAR2
    IS
        l_corp_etl_control_string                                               VARCHAR2(4000);
    BEGIN

        BEGIN

            SELECT  cec.value
              INTO  l_corp_etl_control_string
              FROM  CORP_ETL_CONTROL                                cec
             WHERE  cec.name                                    =   p_NAME;
             
        EXCEPTION
        
            WHEN    NO_DATA_FOUND
            THEN    l_corp_etl_control_string  :=  NULL;
                
        END;
        
        RETURN  l_corp_etl_control_string;
        
    END         get_corp_etl_control_string;  
    /*****************************************************************************************************************************************************************

        NAME:           set_corp_etl_control_string
        DESCRIPTION:    Set the corp etl control string associated with p_NAME.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    PROCEDURE   set_corp_etl_control_string
                (
                    p_NAME                              IN                      CORP_ETL_CONTROL.name%TYPE,
                    p_STRING                            IN                      VARCHAR2
                )
    IS
    BEGIN

        IF  p_STRING IS NOT NULL
        THEN
                    
            UPDATE  CORP_ETL_CONTROL        cec
               SET  value               =   p_STRING
             WHERE  cec.name            =   p_NAME;
             
            COMMIT;             

        END IF;

    END         set_corp_etl_control_string;    
    /*****************************************************************************************************************************************************************

        NAME:           get_unknown_staff_id
        DESCRIPTION:    Get the ID of the unknown staff record.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created function.

    *****************************************************************************************************************************************************************/
    FUNCTION    get_unknown_staff_id
    RETURN                                                                      PLS_INTEGER
    IS
    BEGIN

        RETURN  c_unknown_staff_id; 

    END         get_unknown_staff_id;    
    /*****************************************************************************************************************************************************************

        NAME:           get_unknown_business_unit_id
        DESCRIPTION:    Get the ID of the unknown business unit record.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created function.

    *****************************************************************************************************************************************************************/
    FUNCTION    get_unknown_business_unit_id
    RETURN                                                                      PLS_INTEGER
    IS
    BEGIN
    
        RETURN  c_unknown_business_unit_id; 

    END         get_unknown_business_unit_id;    
    /*****************************************************************************************************************************************************************

        NAME:           get_unknown_team_id
        DESCRIPTION:    Get the ID of the unknown team record.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created function.

    *****************************************************************************************************************************************************************/
    FUNCTION    get_unknown_team_id
    RETURN                                                                      PLS_INTEGER
    IS
    BEGIN
    
        RETURN  c_unknown_team_id; 

    END         get_unknown_team_id;    
    /*****************************************************************************************************************************************************************

        NAME:           get_unknown_dcn
        DESCRIPTION:    Get the value that corresponds to an unknown DCN.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created function.

    *****************************************************************************************************************************************************************/
    FUNCTION    get_unknown_dcn
    RETURN                                                                      VARCHAR2
    IS
    BEGIN

        RETURN  c_unknown_dcn; 

    END         get_unknown_dcn;    
    /*****************************************************************************************************************************************************************

        NAME:           get_unknown_client_number
        DESCRIPTION:    Get the value that corresponds to an unknown client number.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created function.

    *****************************************************************************************************************************************************************/
    FUNCTION    get_unknown_client_number
    RETURN                                                                      PLS_INTEGER
    IS
    BEGIN

        RETURN  c_unknown_client_number; 

    END         get_unknown_client_number;    
    /*****************************************************************************************************************************************************************

        NAME:           get_unknown_ref_type
        DESCRIPTION:    Get the value that corresponds to an unknown Ref Type.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created function.

    *****************************************************************************************************************************************************************/
    FUNCTION    get_unknown_ref_type
    RETURN                                                                      VARCHAR2
    IS
    BEGIN

        RETURN  c_unknown_ref_type; 

    END         get_unknown_ref_type;    
    /*****************************************************************************************************************************************************************

        NAME:           get_unknown_ref_id
        DESCRIPTION:    Get the value that corresponds to an unknown Ref ID.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created function.

    *****************************************************************************************************************************************************************/
    FUNCTION    get_unknown_ref_id
    RETURN                                                                      PLS_INTEGER
    IS
    BEGIN

        RETURN  c_unknown_ref_id; 

    END         get_unknown_ref_id;    
    /*****************************************************************************************************************************************************************

        NAME:           get_staff_id
        DESCRIPTION:    Get the ID of the staff record that corresponds to p_EXT_STAFF_NUMBER.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created function.

    *****************************************************************************************************************************************************************/
    FUNCTION    get_staff_id
                (
                    p_EXT_STAFF_NUMBER                  IN                      D_STAFF.ext_staff_number%TYPE
                )
    RETURN                                                                      D_STAFF.staff_id%TYPE
    IS
        l_ext_staff_number                                                      D_STAFF.ext_staff_number%TYPE                               DEFAULT LOWER(TRIM(p_EXT_STAFF_NUMBER));
        l_staff_id                                                              D_STAFF.staff_id%TYPE;
    
        l_string_index                                                          PLS_INTEGER;

    BEGIN

        IF  l_ext_staff_number IS NULL
        THEN
            RETURN  get_unknown_staff_id;
        END IF;
        
        l_string_index  :=  INSTR(l_ext_staff_number, ' ');

        IF  l_string_index  >   0
        THEN
            l_ext_staff_number  :=  TRIM(SUBSTR(l_ext_staff_number, 1, l_string_index));
        END IF;

        BEGIN
        
            SELECT  NVL(MAX(s.staff_id), get_unknown_staff_id)
              INTO  l_staff_id
              FROM  D_STAFF                     s
             WHERE  s.ext_staff_number      =   l_ext_staff_number
                OR  SUBSTR(s.ext_staff_number, -LENGTH('\' || l_ext_staff_number)) = '\' || l_ext_staff_number
                OR  (
                            SUBSTR(s.last_name, 1, 1)   =   SUBSTR(l_ext_staff_number, -1, 1)
                        AND LOWER(s.first_name)         =   SUBSTR(l_ext_staff_number, 1, LENGTH(l_ext_staff_number) - 1)
                    );
                
        EXCEPTION
        
            WHEN    NO_DATA_FOUND
            THEN    l_staff_id  :=  get_unknown_staff_id;  
        
        END;

        RETURN  l_staff_id; 

    END         get_staff_id;    
    /*****************************************************************************************************************************************************************

        NAME:           get_team_biz_unit_id
        DESCRIPTION:    Get the ID of the business unit that is associated with p_TEAM_ID, based on p_LEVEL.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created function.

    *****************************************************************************************************************************************************************/
    FUNCTION    get_team_biz_unit_id
                (
                    p_TEAM_ID                           IN                      GROUPS_STG.group_id%TYPE,
                    p_LEVEL                             IN                      VARCHAR2
                )
    RETURN                                                                      GROUPS_STG.group_id%TYPE                
    IS
        l_group_id                                                              GROUPS_STG.group_id%TYPE                                    DEFAULT p_TEAM_ID;
        l_business_unit_id                                                      GROUPS_STG.group_id%TYPE                                    DEFAULT NULL;
        l_type_cd                                                               GROUPS_STG.type_cd%TYPE;
        l_parent_group_id                                                       GROUPS_STG.parent_group_id%TYPE;
    BEGIN

        WHILE   TRUE 
        LOOP

            BEGIN
            
                SELECT  gsp.group_id,
                        gsp.type_cd,
                        gsp.parent_group_id
                  INTO  l_group_id,
                        l_type_cd,
                        l_parent_group_id
                  FROM  GROUPS_STG                  gsc,
                        GROUPS_STG                  gsp
                 WHERE  gsc.group_id            =   l_group_id
                   AND  gsp.group_id            =   gsc.parent_group_id;

                IF  l_type_cd   =   'BIZUNIT'
                THEN
                    l_business_unit_id  :=  l_group_id;
                    
                    IF      p_LEVEL =   'NEXT'
                    THEN
                        EXIT;
                    END IF;
                    
                END IF;
                
                IF  l_group_id  =   l_parent_group_id
                THEN
                    EXIT;
                END IF;
                    
            EXCEPTION
            
                WHEN    NO_DATA_FOUND
                THEN    l_business_unit_id  :=  get_unknown_business_unit_id;
            
            END;
        
        END LOOP;
        
        RETURN  l_business_unit_id; 

    END         get_team_biz_unit_id;        
    /*****************************************************************************************************************************************************************

        NAME:           get_staff_team_biz_unit_ids
        DESCRIPTION:    Get the IDs of the team and business units that are associated with p_STAFF_KEY.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    PROCEDURE   get_staff_team_biz_unit_ids
                (
                    p_STAFF_KEY                         IN                      STAFF_KEY_LKUP.staff_key%TYPE,
                    p_TEAM_ID                                       OUT         D_TEAMS.team_id%TYPE,
                    p_BUSINESS_UNIT_ID                              OUT         D_BUSINESS_UNITS.business_unit_id%TYPE
                )
    IS
        l_team_id                                                               D_TEAMS.team_id%TYPE;
        l_business_unit_id                                                      D_BUSINESS_UNITS.business_unit_id%TYPE;
    BEGIN

        BEGIN
        
            SELECT  CASE    WHEN    gs.type_cd  =   'TEAM'
                            THEN    s.default_group_id                  
                    END,
                    CASE    WHEN    gs.type_cd  =   'BIZUNIT'
                            THEN    s.default_group_id                  
                    END                                     
              INTO  l_team_id,
                    l_business_unit_id
              FROM  STAFF_KEY_LKUP              skl,
                    D_STAFF                     s,
                    GROUPS_STG                  gs
             WHERE  skl.staff_key           =   p_STAFF_KEY
               AND  skl.staff_id            =   s.staff_id
               AND  s.default_group_id      =   gs.group_id;
                
        EXCEPTION
        
            WHEN    NO_DATA_FOUND
            THEN    l_team_id   :=  NULL;  
                    l_business_unit_id  :=  NULL;
        
        END;

        IF  l_team_id IS NULL
        THEN
            l_team_id   :=  get_unknown_team_id;
        END IF;

        IF  l_business_unit_id IS NULL
        THEN

            l_business_unit_id  :=  get_team_biz_unit_id
                                    (
                                        p_TEAM_ID                           =>  l_team_id,
                                        p_LEVEL                             =>  'NEXT'
                                    );
        END IF;

        p_TEAM_ID   :=  l_team_id;
        p_BUSINESS_UNIT_ID  :=  NVL(l_business_unit_id, get_unknown_business_unit_id);

    END         get_staff_team_biz_unit_ids;    
                
END CAHCO_ETL_MW_UTIL_PKG;
/