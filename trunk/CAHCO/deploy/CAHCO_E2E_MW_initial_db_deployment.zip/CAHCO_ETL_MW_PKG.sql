CREATE OR REPLACE PACKAGE CAHCO_ETL_MW_PKG AS

    --  Batch Info
    
    CURSOR  c_batch_info
            (   
                cp_DCN                                                          HCO_BATCH_DCN.dcn%TYPE  
            )
    IS
    SELECT  hbs.*
      FROM  HCO_BATCH_DCN               hbd,
            HCO_BATCH_STATS             hbs
     WHERE  hbd.dcn                 =   cp_DCN
       AND  hbd.batch_guid          =   hbs.batch_guid;    

    -- Exemption cursors

    CURSOR  c_emrs_d_exemption_req
    IS
    SELECT  er.*
      FROM  EMRS_D_EXEMPTION_REQ        er
     WHERE  er.modified_date   >=       CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_date
                                        (
                                            p_NAME  =>  'MW_EXEMPTION_PROC_DATE'
                                        )
      AND   er.dcn              IS  NOT NULL
      AND   er.client_number    IS  NOT NULL;
      
    CURSOR  c_emrs_d_exempt_status_hist
    IS
    SELECT  esh.*,
            e.record_date               EXEMPTION_RECORD_DATE,
            e.client_number,
            e.dcn,
            es.final_status
      FROM  EMRS_D_EXEMPT_STATUS_HIST   esh,
            EMRS_D_EXEMPTION_REQ        e,
            EMRS_D_EXEMPTION_STATUS     es
     WHERE  esh.record_date   >=        CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_date
                                        (
                                            p_NAME      =>  'MW_EXEMPTION_SH_PROC_DATE'
                                        )
       AND  esh.exemption_id            =   e.exemption_id
       AND  e.dcn                       IS  NOT NULL
       AND  e.client_number             IS  NOT NULL
       AND  esh.exemption_status_code   =   es.exemption_status_code;                                            

    -- EDER cursors

    CURSOR  c_emrs_d_emrgcy_disenroll
    IS
    SELECT  eder.*
      FROM  EMRS_D_EMRGCY_DISENROLL     eder
     WHERE  eder.modified_date   >=     CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_date
                                        (
                                            p_NAME      =>  'MW_EDER_STG_PROC_DATE'
                                        )
       AND  eder.dcn             IS NOT NULL;
      
    CURSOR  c_proc_emrs_d_emrgcy_denr_hist
    IS
    SELECT  ederhist.*,
            e.record_date               EDER_RECORD_DATE,
            e.client_number,
            e.dcn,
            es.final_status
      FROM  EMRS_D_EMRGCY_DENR_HIST     ederhist,
            EMRS_D_EMRGCY_DISENROLL     e,
            EMRS_D_EMRGCY_DENR_STATUS   es
     WHERE  ederhist.record_date   >=   CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_date
                                        (
                                            p_NAME      =>  'MW_EDER_SH_PROC_DATE'
                                        )
       AND  ederhist.emrgcy_denr_id             =   e.emrgcy_disenroll_id
       AND  e.dcn                               IS  NOT NULL
       AND  e.client_number                     IS  NOT NULL
       AND  ederhist.emrgcy_denr_status_code    =   es.emrgcy_denr_status_code;                                            

    -- Enrollment cursor
    
    CURSOR  c_emrs_f_enrollment
    IS
    SELECT  e.*,
            ext.export_batch_date,                
            (
                SELECT  MIN(sl.process_start_date)
                  FROM  HCO_SYSTEM_LOG                  sl
                 WHERE  sl.process_start_date       >=  ext.export_batch_date
                   AND  sl.process_name    IN ('uspMedsUploadWrapUp')
                   AND  sl.status                   =   'DONE'
            )                           meds_process_start_date,
            (
                SELECT  MIN(sl.process_end_date)
                  FROM  HCO_SYSTEM_LOG                  sl
                 WHERE  sl.process_end_date         >=  ext.export_batch_date
                   AND  sl.process_name    IN ('uspMedsUploadWrapUp')
                   AND  sl.status                   =   'DONE'                       
            )                           meds_process_end_date,
            (
                SELECT  MIN(sth.modified_date)
                  FROM  EMRS_D_SELECTION_TRANS_HISTORY  sth
                 WHERE  sth.selection_transaction_id    =   e.selection_transaction_id
                   AND  sth.accept_ind                  IS  NOT NULL
            )                           accept_date
      FROM  EMRS_F_ENROLLMENT           e,
            HCO_ENROLLMENT_EXT          ext
     WHERE  e.modified_date        >=   CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_date
                                        (
                                            p_NAME      =>  'MW_ENROLLMENT_PROC_DATE'
                                        )
       AND  e.enrollment_trans_type_code        IN  ('1', '2')
       AND  e.dcn                               IS  NOT NULL
       AND  e.client_number                     IS  NOT NULL
       AND  e.channel_id in ('1','2','9','10','13','14','15','17') 
       AND  e.enrollment_id         =   ext.enrollment_id;    

    -- Return Mail cursor
    
    CURSOR  c_proc_return_mail
    IS
    SELECT  c.case_number,
            c.clnt_client_id,
            cd.dcn,
            c.addr_bad_date,
            c.modified_name         c_modified_name,
            c.modified_date         c_modified_date,
            obt.modified_date       obt_modified_date        
      FROM  EMRS_D_CASE             c
            INNER JOIN
            EMRS_D_CLIENT           cl
            ON
            (
                c.case_number           =   cl.case_number
            )
            LEFT JOIN
            HCO_CASE_DCN            cd
            ON
            (
                    c.case_number       =   cd.case_number
            )
            LEFT JOIN
            HCO_OB_TRANSACTIONS     obt
            ON  
            (
                    c.case_number       =   obt.case_number
                AND cl.client_number    =   obt.client_number
                AND obt.ob_call_type    =   'IA'
            )
     WHERE  c.addr_bad_date     IS NOT NULL
       AND  cd.dcn              IS NOT NULL
       AND  cl.client_number    IS NOT NULL
       AND  (
                     c.modified_date       >=   CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_date
                                                (
                                                    p_NAME      =>  'MW_RETURN_MAIL_PROC_DATE'
                                                )
                OR  obt.modified_date       >=  CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_date
                                                (
                                                    p_NAME      =>  'MW_RETURN_MAIL_PROC_DATE'
                                                )
            );                                                    
    
    -- Leter Mailing cursor

    CURSOR  c_hco_d_letter_mailing
    IS
    SELECT  lm.dim_letter_mailing_id,
            lm.vendor_received_date,
            lm.date_mailed,
            lm.modified_date,
            mct.mail_id,
            mct.client_number,
            mct.case_id,
            ec.case_number,
            MAX(mct.mt_modified_date)                                           AS  MAIL_TRANSACTION_DATE,
            MAX(mct.mail_response_letter_date)                                  AS  MAIL_RESPONSE_LETTER_DATE,
            MAX(mct.dcn)                                                        AS  DCN
      FROM  HCO_D_LETTER_MAILING        lm,
            HCO_MAIL_CLIENT_TRANS       mct,
            EMRS_D_CASE                 ec
     WHERE  lm.modified_date   >=       CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_date
                                        (
                                            p_NAME  =>  'MW_LETTER_MAILING_PROC_DATE'
                                        )
       AND  lm.date_mailed IS NOT NULL
       AND  lm.dcin             =       mct.mail_id
       AND  lm.case_id          =       mct.case_id
       AND  ec.case_id          =       mct.case_id
     GROUP
        BY  lm.dim_letter_mailing_id,
            lm.vendor_received_date,
            lm.date_mailed,
            lm.modified_date,
            mct.mail_id,
            mct.client_number,
            mct.case_id,
            ec.case_number;

    -- Packet Mailing cursor

    CURSOR  c_hco_d_packet_mailing
    IS
    SELECT  pm.dim_packet_mailing_id,
            pm.vendor_received_date,
            pm.date_mailed,
            pm.modified_date,
            mct.mail_id,
            mct.client_number,
            mct.case_id,
            ec.case_number,
            MAX(mct.mt_modified_date)                                           AS  MAIL_TRANSACTION_DATE,
            MAX(mct.mail_response_packet_date)                                  AS  MAIL_RESPONSE_PACKET_DATE,
            MAX(mct.dcn)                                                        AS  DCN
      FROM  HCO_D_PACKET_MAILING        pm,
            HCO_MAIL_CLIENT_TRANS       mct,
            EMRS_D_CASE                 ec
     WHERE  pm.modified_date   >=       CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_date
                                        (
                                            p_NAME  =>  'MW_LETTER_MAILING_PROC_DATE'
                                        )
       AND  pm.date_mailed IS NOT NULL
       AND  pm.dcin             =       mct.mail_id
       AND  pm.case_id          =       mct.case_id
       AND  ec.case_id          =       mct.case_id
     GROUP
        BY  pm.dim_packet_mailing_id,
            pm.vendor_received_date,
            pm.date_mailed,
            pm.modified_date,
            mct.mail_id,
            mct.client_number,
            mct.case_id,
            ec.case_number;    
    
    PROCEDURE   ins_hco_activity_queue
                (
                    p_ACT_STATUS                        IN                      HCO_ACTIVITY_QUEUE.act_status%TYPE,
                    p_ACT_STATUS_TS                     IN                      HCO_ACTIVITY_QUEUE.act_status_ts%TYPE,
                    p_ACT_OWNER                         IN                      HCO_ACTIVITY_QUEUE.act_owner%TYPE,
                    p_ACT_TEAM_ID                       IN                      HCO_ACTIVITY_QUEUE.act_team_id%TYPE,
                    p_ACT_CASE_ID                       IN                      HCO_ACTIVITY_QUEUE.act_case_id%TYPE,
                    p_ACT_CLIENT_ID                     IN                      HCO_ACTIVITY_QUEUE.act_client_id%TYPE,
                    p_ACT_DCN                           IN                      HCO_ACTIVITY_QUEUE.act_dcn%TYPE,
                    p_ACT_REF_ID                        IN                      HCO_ACTIVITY_QUEUE.act_ref_id%TYPE,
                    p_ACT_REF_TYPE                      IN                      HCO_ACTIVITY_QUEUE.act_ref_type%TYPE,
                    p_ACT_STEP_DEFINITION_ID            IN                      HCO_ACTIVITY_QUEUE.act_step_definition_id%TYPE,
                    p_ACT_PROCESS_ID                    IN                      HCO_ACTIVITY_QUEUE.act_process_id%TYPE,                    
                    p_ACT_CREATED_BY                    IN                      HCO_ACTIVITY_QUEUE.act_created_by%TYPE,
                    p_ACT_CREATE_TS                     IN                      HCO_ACTIVITY_QUEUE.act_create_ts%TYPE,                    
                    p_ACT_COMMENTS                      IN                      HCO_ACTIVITY_QUEUE.act_comments%TYPE
                );
                
    PROCEDURE   proc_hco_activity_queue
                (
                    p_BATCH_SIZE                        IN                      NUMBER                                                      DEFAULT 10000
                );

    PROCEDURE   proc_emrs_d_exemption_req;
    PROCEDURE   proc_emrs_d_exempt_status_hist;
        
    PROCEDURE   proc_emrs_d_emrgcy_disenroll;
    PROCEDURE   proc_emrs_d_emrgcy_denr_hist;
    
    PROCEDURE   proc_emrs_f_enrollment;
    
    PROCEDURE   proc_return_mail;
    
    PROCEDURE   proc_hco_d_letter_mailing;
    PROCEDURE   proc_hco_d_packet_mailing;
                
    PROCEDURE   ins_step_instance_stg;
    
    FUNCTION    step_inst_hist_rec_exists
                (
                    p_REF_ID                            IN                      STEP_INSTANCE.ref_id%TYPE,
                    p_REF_TYPE                          IN                      STEP_INSTANCE.ref_type%TYPE,
                    p_STEP_DEFINITION_ID                IN                      STEP_INSTANCE.step_definition_id%TYPE,
                    p_CREATE_TS                         IN                      STEP_INSTANCE.create_ts%TYPE,                    
                    p_STATUS                            IN                      STEP_INSTANCE.status%TYPE,
                    p_STATUS_TS                         IN                      STEP_INSTANCE.status_ts%TYPE
                )
    RETURN                                                                      PLS_INTEGER;

    FUNCTION    map_hco_process_instance
                (
                    p_HCO_PROCESS_ID                    IN                      D_HCO_PROCESS_INSTANCE.hco_process_id%TYPE,
                    p_DCN                               IN                      D_HCO_PROCESS_INSTANCE.dcn%TYPE,
                    p_CLIENT_NUMBER                     IN                      D_HCO_PROCESS_INSTANCE.client_number%TYPE,
                    p_REF_TYPE                          IN                      D_HCO_PROCESS_INSTANCE.ref_type%TYPE,
                    p_REF_ID                            IN                      D_HCO_PROCESS_INSTANCE.ref_id%TYPE,
                    p_INS_IF_NOT_EXISTS                 IN                      PLS_INTEGER                                                 DEFAULT CAHCO_ETL_MW_UTIL_PKG.is_false
    
                )                    
    RETURN                                                                      D_HCO_PROCESS_INSTANCE.hco_process_instance_id%TYPE;

    FUNCTION    get_dcn_date
                (
                    p_DCN                               IN                      D_HCO_PROCESS_INSTANCE.dcn%TYPE
                )
    RETURN                                                                      DATE;
    
END CAHCO_ETL_MW_PKG;
/
CREATE OR REPLACE PACKAGE BODY CAHCO_ETL_MW_PKG AS

    c_unclaimed                                                                 VARCHAR2(40)                            :=                  'UNCLAIMED';
    c_claimed                                                                   VARCHAR2(40)                            :=                  'CLAIMED';
    c_completed                                                                 VARCHAR2(40)                            :=                  'COMPLETED';

    c_automated_process                                                         VARCHAR2(40)                            :=                  'Automated Process';
    c_letter_mailing                                                            VARCHAR2(40)                            :=                  'Letter Mailing';
    c_packet_mailing                                                            VARCHAR2(40)                            :=                  'Packet Mailing';
    c_eder                                                                      VARCHAR2(40)                            :=                  'EDER';
    c_exemption                                                                 VARCHAR2(40)                            :=                  'Exemption';
    c_enrollment                                                                VARCHAR2(40)                            :=                  'Enrollment';
    c_disenrollment                                                             VARCHAR2(40)                            :=                  'Disenrollment';
    c_return_mail_case                                                          VARCHAR2(40)                            :=                  'Return Mail Case';
    /*****************************************************************************************************************************************************************

        NAME:           ins_hco_activity_queue
        DESCRIPTION:    Insert a record into the table INS_HCO_ACTIVITY_QUEUE.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    PROCEDURE   ins_hco_activity_queue
                (
                    p_ACT_STATUS                        IN                      HCO_ACTIVITY_QUEUE.act_status%TYPE,
                    p_ACT_STATUS_TS                     IN                      HCO_ACTIVITY_QUEUE.act_status_ts%TYPE,
                    p_ACT_OWNER                         IN                      HCO_ACTIVITY_QUEUE.act_owner%TYPE,
                    p_ACT_TEAM_ID                       IN                      HCO_ACTIVITY_QUEUE.act_team_id%TYPE,
                    p_ACT_CASE_ID                       IN                      HCO_ACTIVITY_QUEUE.act_case_id%TYPE,
                    p_ACT_CLIENT_ID                     IN                      HCO_ACTIVITY_QUEUE.act_client_id%TYPE,
                    p_ACT_DCN                           IN                      HCO_ACTIVITY_QUEUE.act_dcn%TYPE,
                    p_ACT_REF_ID                        IN                      HCO_ACTIVITY_QUEUE.act_ref_id%TYPE,
                    p_ACT_REF_TYPE                      IN                      HCO_ACTIVITY_QUEUE.act_ref_type%TYPE,
                    p_ACT_STEP_DEFINITION_ID            IN                      HCO_ACTIVITY_QUEUE.act_step_definition_id%TYPE,
                    p_ACT_PROCESS_ID                    IN                      HCO_ACTIVITY_QUEUE.act_process_id%TYPE,                    
                    p_ACT_CREATED_BY                    IN                      HCO_ACTIVITY_QUEUE.act_created_by%TYPE,
                    p_ACT_CREATE_TS                     IN                      HCO_ACTIVITY_QUEUE.act_create_ts%TYPE,                    
                    p_ACT_COMMENTS                      IN                      HCO_ACTIVITY_QUEUE.act_comments%TYPE
                )
    IS
        l_step_inst_hist_rec_exists                                             PLS_INTEGER                                                 DEFAULT CAHCO_ETL_MW_UTIL_PKG.is_false;
    BEGIN

        IF  p_ACT_STATUS IS NOT NULL
        THEN
            l_step_inst_hist_rec_exists :=  step_inst_hist_rec_exists
                                            (
                                                p_REF_ID                =>  p_ACT_REF_ID, 
                                                p_REF_TYPE              =>  p_ACT_REF_TYPE, 
                                                p_STEP_DEFINITION_ID    =>  p_ACT_STEP_DEFINITION_ID, 
                                                p_CREATE_TS             =>  p_ACT_STATUS_TS,
                                                p_STATUS                =>  p_ACT_STATUS, 
                                                p_STATUS_TS             =>  p_ACT_STATUS_TS
                                            );

        ELSE

            l_step_inst_hist_rec_exists :=  CAHCO_ETL_MW_UTIL_PKG.is_false;

        END IF;
    
        IF  l_step_inst_hist_rec_exists = CAHCO_ETL_MW_UTIL_PKG.is_false
        THEN
    
            INSERT
              INTO  HCO_ACTIVITY_QUEUE          (   act_status,     act_status_ts,      act_owner,      act_team_id,        act_case_id,        act_client_id,      act_dcn,        act_ref_id,     act_ref_type,       act_step_definition_id,     act_process_id,     act_created_by,     act_create_ts,      act_comments    )
            VALUES                              (   p_ACT_STATUS,   p_ACT_STATUS_TS,    p_ACT_OWNER,    p_ACT_TEAM_ID,      p_ACT_CASE_ID,      p_ACT_CLIENT_ID,    p_ACT_DCN,      p_ACT_REF_ID,   p_ACT_REF_TYPE,     p_ACT_STEP_DEFINITION_ID,   p_ACT_PROCESS_ID,   p_ACT_CREATED_BY,   p_ACT_CREATE_TS,    p_ACT_COMMENTS  );          

        END IF;            

    END         ins_hco_activity_queue;
    /*****************************************************************************************************************************************************************

        NAME:           upd_hco_activity_queue
        DESCRIPTION:    Update date the record in HCO_ACTIVITY_QUEUE that corresponds to p_HCO_ACTIVITY_QUEUE_ID.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    PROCEDURE   upd_hco_activity_queue
                (
                    p_HCO_ACTIVITY_QUEUE_ID             IN                      HCO_ACTIVITY_QUEUE.hco_activity_queue_id%TYPE,
                    p_REC_STATUS                        IN                      HCO_ACTIVITY_QUEUE.rec_status%TYPE
                )
    IS
    BEGIN

        UPDATE  HCO_ACTIVITY_QUEUE         
           SET  rec_status                              =   p_REC_STATUS
         WHERE  hco_activity_queue_id                   =   p_HCO_ACTIVITY_QUEUE_ID;
        
    END         upd_hco_activity_queue;
    /*****************************************************************************************************************************************************************

        NAME:           del_hco_activity_queue
        DESCRIPTION:    Delete the record from HCO_ACTIVITY_QUEUE that corresponds to p_HCO_ACTIVITY_QUEUE_ID.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    PROCEDURE   del_hco_activity_queue
                (
                    p_HCO_ACTIVITY_QUEUE_ID             IN                      HCO_ACTIVITY_QUEUE.hco_activity_queue_id%TYPE
                )
    IS
    BEGIN

        DELETE  
         FROM   HCO_ACTIVITY_QUEUE
         WHERE  hco_activity_queue_id                   =   p_HCO_ACTIVITY_QUEUE_ID;
        
    END         del_hco_activity_queue;
    /*****************************************************************************************************************************************************************

        NAME:           step_inst_hist_rec_exists
        DESCRIPTION:    Determine whether the step instance record exists in history.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created function.

    *****************************************************************************************************************************************************************/
    FUNCTION    step_inst_hist_rec_exists
                (
                    p_REF_ID                            IN                      STEP_INSTANCE.ref_id%TYPE,
                    p_REF_TYPE                          IN                      STEP_INSTANCE.ref_type%TYPE,
                    p_STEP_DEFINITION_ID                IN                      STEP_INSTANCE.step_definition_id%TYPE,
                    p_CREATE_TS                         IN                      STEP_INSTANCE.create_ts%TYPE,                    
                    p_STATUS                            IN                      STEP_INSTANCE.status%TYPE,
                    p_STATUS_TS                         IN                      STEP_INSTANCE.status_ts%TYPE
                )
    RETURN                                                                      PLS_INTEGER
    IS
        l_step_inst_hist_rec_exists                                             PLS_INTEGER                                                 DEFAULT CAHCO_ETL_MW_UTIL_PKG.is_false;
    BEGIN

        BEGIN

            SELECT  CAHCO_ETL_MW_UTIL_PKG.is_true
              INTO  l_step_inst_hist_rec_exists 
              FROM  DUAL
             WHERE  EXISTS  (
                                SELECT  1
                                  FROM  STEP_INSTANCE                   si,
                                        STEP_INSTANCE_HISTORY           sih
                                 WHERE  si.ref_type                 =   p_REF_TYPE
                                   AND  si.ref_id                   =   p_REF_ID
                                   AND  si.step_definition_id       =   p_STEP_DEFINITION_ID
                                   AND  si.create_ts                =   p_CREATE_TS
                                   AND  si.status                   !=  p_STATUS
                                   AND  si.step_instance_id         =   sih.step_instance_id
                                   AND  sih.status                  =   p_STATUS
                                   AND  sih.create_ts               =   p_STATUS_TS
                            );

        EXCEPTION
        
            WHEN    NO_DATA_FOUND
            THEN    l_step_inst_hist_rec_exists :=  CAHCO_ETL_MW_UTIL_PKG.is_false;
                
        END;
        
        RETURN  l_step_inst_hist_rec_exists;
        
    END         step_inst_hist_rec_exists;
    /*****************************************************************************************************************************************************************

        NAME:           get_cur_step_instance_status
        DESCRIPTION:    Get the current step instance status.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created function.

    *****************************************************************************************************************************************************************/
    FUNCTION    get_cur_step_instance_status
                (
                    p_REF_ID                            IN                      STEP_INSTANCE.ref_id%TYPE,
                    p_REF_TYPE                          IN                      STEP_INSTANCE.ref_type%TYPE,
                    p_STEP_DEFINITION_ID                IN                      STEP_INSTANCE.step_definition_id%TYPE,
                    p_CREATE_TS                         IN                      STEP_INSTANCE.create_ts%TYPE
                )
    RETURN                                                                      STEP_INSTANCE.status%TYPE
    IS
        l_cur_step_instance_status                                              STEP_INSTANCE.status%TYPE                                   DEFAULT c_unclaimed;
    BEGIN

        BEGIN

            SELECT  si.status
              INTO  l_cur_step_instance_status
              FROM  STEP_INSTANCE                                       si
             WHERE  si.ref_id                                       =   p_REF_ID
               AND  si.ref_type                                     =   p_REF_TYPE
               AND  si.step_definition_id                           =   p_STEP_DEFINITION_ID
               AND  si.create_ts                                    =   p_CREATE_TS;
             
        EXCEPTION
        
            WHEN    NO_DATA_FOUND
            THEN    l_cur_step_instance_status  :=  c_unclaimed;
                
        END;
        
        RETURN  l_cur_step_instance_status;
        
    END         get_cur_step_instance_status;
    /*****************************************************************************************************************************************************************

        NAME:           mrg_staff_key_lkup
        DESCRIPTION:    Upsert a record into the table STAFF_KEY_LKUP.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    PROCEDURE   mrg_staff_key_lkup
                (
                    p_STAFF_KEY                         IN                      STAFF_KEY_LKUP.staff_key%TYPE
                )
    IS
    BEGIN
                        
        IF  p_STAFF_KEY IS NOT NULL
        THEN

            MERGE 
            INTO        STAFF_KEY_LKUP                                                                                  d
            USING       (
                            SELECT  CAHCO_ETL_MW_UTIL_PKG.get_staff_id( p_EXT_STAFF_NUMBER  =>  p_STAFF_KEY )       AS  STAFF_ID,
                                    p_STAFF_KEY                                                                     AS  STAFF_KEY
                              FROM  DUAL
                        )                                               s
            ON          (
                                d.staff_key                         =   s.staff_key
                        )                                                   

            WHEN MATCHED THEN UPDATE SET
    
                d.staff_id                                          =   s.staff_id

            WHEN NOT MATCHED THEN INSERT
                (
                    d.staff_id,
                    d.staff_key    
                )   
            VALUES 
                (
                    s.staff_id,
                    s.staff_key                    
                );
            
        END IF;

    END         mrg_staff_key_lkup;
    /*****************************************************************************************************************************************************************

        NAME:           map_hco_process_instance
        DESCRIPTION:    Return a value for HCO_PROCESS_INSTANCE_ID from the table D_HCO_PROCESS_INSTANCE.  If p_INS_IF_NOT_EXISTS is TRUE, then a record is
                        inserted.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created function.

    *****************************************************************************************************************************************************************/
    FUNCTION    map_hco_process_instance
                (
                    p_HCO_PROCESS_ID                    IN                      D_HCO_PROCESS_INSTANCE.hco_process_id%TYPE,
                    p_DCN                               IN                      D_HCO_PROCESS_INSTANCE.dcn%TYPE,
                    p_CLIENT_NUMBER                     IN                      D_HCO_PROCESS_INSTANCE.client_number%TYPE,
                    p_REF_TYPE                          IN                      D_HCO_PROCESS_INSTANCE.ref_type%TYPE,
                    p_REF_ID                            IN                      D_HCO_PROCESS_INSTANCE.ref_id%TYPE,
                    p_INS_IF_NOT_EXISTS                 IN                      PLS_INTEGER                                                 DEFAULT CAHCO_ETL_MW_UTIL_PKG.is_false

                )                    
    RETURN                                                                      D_HCO_PROCESS_INSTANCE.hco_process_instance_id%TYPE                                                             
    IS

        l_hco_process_id                                                        D_HCO_PROCESS_INSTANCE.hco_process_id%TYPE                  DEFAULT p_HCO_PROCESS_ID;
        l_dcn                                                                   D_HCO_PROCESS_INSTANCE.dcn%TYPE                             DEFAULT NVL(p_DCN, CAHCO_ETL_MW_UTIL_PKG.get_unknown_dcn);
        l_client_number                                                         D_HCO_PROCESS_INSTANCE.client_number%TYPE                   DEFAULT NVL(p_CLIENT_NUMBER, CAHCO_ETL_MW_UTIL_PKG.get_unknown_client_number); 
        l_ref_type                                                              D_HCO_PROCESS_INSTANCE.ref_type%TYPE                        DEFAULT NVL(p_REF_TYPE, CAHCO_ETL_MW_UTIL_PKG.get_unknown_ref_type);
        l_ref_id                                                                D_HCO_PROCESS_INSTANCE.ref_id%TYPE                          DEFAULT NVL(p_REF_ID, CAHCO_ETL_MW_UTIL_PKG.get_unknown_ref_id);
        l_hco_process_instance_id                                               D_HCO_PROCESS_INSTANCE.hco_process_instance_id%TYPE;

    BEGIN

        BEGIN

            SELECT  mhpi.hco_process_instance_id
              INTO  l_hco_process_instance_id
              FROM  D_HCO_PROCESS_INSTANCE                      mhpi
             WHERE  mhpi.hco_process_id                     =   l_hco_process_id
               AND  mhpi.dcn                                =   l_dcn
               AND  mhpi.client_number                      =   l_client_number
               AND  mhpi.ref_type                           =   l_ref_type
               AND  mhpi.ref_id                             =   l_ref_id;
        
        EXCEPTION
        
            WHEN    NO_DATA_FOUND
            THEN    l_hco_process_instance_id    :=  NULL;

        END;
    
        IF      l_hco_process_instance_id IS NULL
            AND p_INS_IF_NOT_EXISTS =   CAHCO_ETL_MW_UTIL_PKG.is_true
        THEN

            INSERT
              INTO  D_HCO_PROCESS_INSTANCE  (   hco_process_instance_id,                hco_process_id,         dcn,        client_number,      ref_type,       ref_id      )
            VALUES                          (   SEQ_HCO_PROCESS_INSTANCE_ID.nextval,    l_hco_process_id,       l_dcn,      l_client_number,    l_ref_type,     l_ref_id    )
            RETURNING   hco_process_instance_id
            INTO        l_hco_process_instance_id;

        END IF;        
                            
        RETURN  l_hco_process_instance_id;
            
    END         map_hco_process_instance;
    /*****************************************************************************************************************************************************************

        NAME:           mrg_step_instance
        DESCRIPTION:    Upsert a record into the table STEP_INSTANCE.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    PROCEDURE   mrg_step_instance
                (
                    p_STATUS                            IN                      STEP_INSTANCE.status%TYPE,
                    p_STATUS_TS                         IN                      STEP_INSTANCE.status_ts%TYPE,
                    p_ESCALATED_IND                     IN                      STEP_INSTANCE.escalated_ind%TYPE,
                    p_STEP_DUE_TS                       IN                      STEP_INSTANCE.step_due_ts%TYPE,
                    p_FORWARDED_IND                     IN                      STEP_INSTANCE.forwarded_ind%TYPE,
                    p_ESCALATE_TO                       IN                      STEP_INSTANCE.escalate_to%TYPE,
                    p_FORWARDED_BY                      IN                      STEP_INSTANCE.forwarded_by%TYPE,
                    p_OWNER                             IN                      STEP_INSTANCE.owner%TYPE,
                    p_LOCKED_ID                         IN                      STEP_INSTANCE.locked_id%TYPE,
                    p_GROUP_STEP_DEFINITION_ID          IN                      STEP_INSTANCE.group_step_definition_id%TYPE,
                    p_GROUP_ID                          IN                      STEP_INSTANCE.group_id%TYPE,
                    p_TEAM_ID                           IN                      STEP_INSTANCE.team_id%TYPE,
                    p_PROCESS_ID                        IN                      STEP_INSTANCE.process_id%TYPE,
                    p_PRIORITY_CD                       IN                      STEP_INSTANCE.priority_cd%TYPE,
                    p_PROCESS_ROUTER_ID                 IN                      STEP_INSTANCE.process_router_id%TYPE,
                    p_PROCESS_INSTANCE_ID               IN                      STEP_INSTANCE.process_instance_id%TYPE,
                    p_CASE_ID                           IN                      STEP_INSTANCE.case_id%TYPE,
                    p_CLIENT_ID                         IN                      STEP_INSTANCE.client_id%TYPE,
                    p_REF_ID                            IN                      STEP_INSTANCE.ref_id%TYPE,
                    p_REF_TYPE                          IN                      STEP_INSTANCE.ref_type%TYPE,
                    p_STEP_DEFINITION_ID                IN                      STEP_INSTANCE.step_definition_id%TYPE,
                    p_CREATED_BY                        IN                      STEP_INSTANCE.created_by%TYPE,
                    p_CREATE_TS                         IN                      STEP_INSTANCE.create_ts%TYPE,
                    p_SUSPENDED_TS                      IN                      STEP_INSTANCE.suspended_ts%TYPE,
                    p_COMMENTS                          IN                      STEP_INSTANCE.comments%TYPE,
                    p_CREATE_NDT                        IN                      STEP_INSTANCE.create_ndt%TYPE,
                    p_STEP_DUE_NDT                      IN                      STEP_INSTANCE.step_due_ndt%TYPE

                )
    IS
        l_step_inst_hist_rec_exists                                             PLS_INTEGER                                                 DEFAULT CAHCO_ETL_MW_UTIL_PKG.is_false;
        l_status                                                                STEP_INSTANCE.status%TYPE                                   DEFAULT c_unclaimed;
                        
    BEGIN
                        
        IF  p_STATUS IS NULL
        THEN

            l_status    :=  get_cur_step_instance_status
                            (
                                p_REF_ID                            =>  p_REF_ID,
                                p_REF_TYPE                          =>  p_REF_TYPE,
                                p_STEP_DEFINITION_ID                =>  p_STEP_DEFINITION_ID,
                                p_CREATE_TS                         =>  p_CREATE_TS
                            );

            l_step_inst_hist_rec_exists :=  step_inst_hist_rec_exists
                                            (
                                                p_REF_ID                =>  p_REF_ID, 
                                                p_REF_TYPE              =>  p_REF_TYPE, 
                                                p_STEP_DEFINITION_ID    =>  p_STEP_DEFINITION_ID, 
                                                p_CREATE_TS             =>  p_CREATE_TS,
                                                p_STATUS                =>  l_status, 
                                                p_STATUS_TS             =>  p_STATUS_TS

                                            );
        ELSE
            l_status    :=  p_STATUS;
            l_step_inst_hist_rec_exists :=  CAHCO_ETL_MW_UTIL_PKG.is_false;
        END IF;

        IF  l_step_inst_hist_rec_exists = CAHCO_ETL_MW_UTIL_PKG.is_false
        THEN

            MERGE 
            INTO        STEP_INSTANCE                                   d
            USING       (
                            SELECT  l_STATUS                        AS  STATUS,
                                    p_STATUS_TS                     AS  STATUS_TS,
                                    p_ESCALATED_IND                 AS  ESCALATED_IND,
                                    p_STEP_DUE_TS                   AS  STEP_DUE_TS,
                                    p_FORWARDED_IND                 AS  FORWARDED_IND,
                                    p_ESCALATE_TO                   AS  ESCALATE_TO,
                                    p_FORWARDED_BY                  AS  FORWARDED_BY,
                                    p_OWNER                         AS  OWNER,
                                    p_LOCKED_ID                     AS  LOCKED_ID,
                                    p_GROUP_STEP_DEFINITION_ID      AS  GROUP_STEP_DEFINITION_ID,    
                                    p_GROUP_ID                      AS  GROUP_ID,
                                    p_TEAM_ID                       AS  TEAM_ID,
                                    p_PROCESS_ID                    AS  PROCESS_ID,
                                    p_PRIORITY_CD                   AS  PRIORITY_CD,
                                    p_PROCESS_ROUTER_ID             AS  PROCESS_ROUTER_ID,
                                    p_PROCESS_INSTANCE_ID           AS  PROCESS_INSTANCE_ID,
                                    p_CASE_ID                       AS  CASE_ID,
                                    p_CLIENT_ID                     AS  CLIENT_ID,
                                    p_REF_ID                        AS  REF_ID,
                                    p_REF_TYPE                      AS  REF_TYPE,
                                    p_STEP_DEFINITION_ID            AS  STEP_DEFINITION_ID,
                                    p_CREATED_BY                    AS  CREATED_BY,
                                    p_CREATE_TS                     AS  CREATE_TS,
                                    p_SUSPENDED_TS                  AS  SUSPENDED_TS,
                                    p_COMMENTS                      AS  COMMENTS,
                                    p_CREATE_NDT                    AS  CREATE_NDT,
                                    p_STEP_DUE_NDT                  AS  STEP_DUE_NDT
                              FROM  DUAL
                        )                                               s
            ON          (
                                d.ref_type                          =   s.ref_type 
                            AND d.ref_id                            =   s.ref_id
                            AND d.step_definition_id                =   s.step_definition_id   
                            AND d.create_ts                         =   s.create_ts
                        )                                               
            WHEN MATCHED THEN UPDATE SET
    
                d.status                                            =   s.STATUS,
                d.status_ts                                         =   s.STATUS_TS,
                d.escalated_ind                                     =   s.ESCALATED_IND,
                d.step_due_ts                                       =   s.STEP_DUE_TS,
                d.forwarded_ind                                     =   s.FORWARDED_IND,
                d.escalate_to                                       =   s.ESCALATE_TO,
                d.forwarded_by                                      =   s.FORWARDED_BY,
                d.owner                                             =   s.OWNER,
                d.locked_id                                         =   s.LOCKED_ID,
                d.group_step_definition_id                          =   s.GROUP_STEP_DEFINITION_ID,    
                d.group_id                                          =   s.GROUP_ID,
                d.team_id                                           =   s.TEAM_ID,
                d.process_id                                        =   s.PROCESS_ID,
                d.priority_cd                                       =   s.PRIORITY_CD,
                d.process_router_id                                 =   s.PROCESS_ROUTER_ID,
                d.process_instance_id                               =   s.PROCESS_INSTANCE_ID,
                d.case_id                                           =   s.CASE_ID,
                d.client_id                                         =   s.CLIENT_ID,
                d.suspended_ts                                      =   s.SUSPENDED_TS,
                d.comments                                          =   s.COMMENTS,
                d.create_ndt                                        =   s.CREATE_NDT
    
            WHEN NOT MATCHED THEN INSERT
                (
                    d.step_instance_id,
                    d.status,
                    d.status_ts,
                    d.escalated_ind,
                    d.step_due_ts,
                    d.forwarded_ind,
                    d.escalate_to,
                    d.forwarded_by,
                    d.owner,
                    d.locked_id,
                    d.group_step_definition_id,
                    d.group_id,
                    d.team_id,
                    d.process_id,
                    d.priority_cd,
                    d.process_router_id,
                    d.process_instance_id,
                    d.case_id,
                    d.client_id,
                    d.ref_id,
                    d.ref_type,
                    d.step_definition_id,
                    d.created_by,
                    d.create_ts,                    
                    d.suspended_ts,
                    d.comments,
                    d.create_ndt,
                    d.step_due_ndt
    
                )   
            VALUES 
                (
    
                    SEQ_STEP_INSTANCE_ID.nextval,
                    s.STATUS,
                    s.STATUS_TS,
                    s.ESCALATED_IND,
                    s.STEP_DUE_TS,
                    s.FORWARDED_IND,
                    s.ESCALATE_TO,
                    s.FORWARDED_BY,
                    s.OWNER,
                    s.LOCKED_ID,
                    s.GROUP_STEP_DEFINITION_ID,    
                    s.GROUP_ID,
                    s.TEAM_ID,
                    s.PROCESS_ID,
                    s.PRIORITY_CD,
                    s.PROCESS_ROUTER_ID,
                    s.PROCESS_INSTANCE_ID,
                    s.CASE_ID,
                    s.CLIENT_ID,
                    s.REF_ID,
                    s.REF_TYPE,
                    s.STEP_DEFINITION_ID,
                    s.CREATED_BY,
                    s.CREATE_TS,
                    s.SUSPENDED_TS,
                    s.COMMENTS,
                    s.CREATE_NDT,
                    s.STEP_DUE_NDT            
    
                );
            
        END IF;
            
    END         mrg_step_instance;
    /*****************************************************************************************************************************************************************

        NAME:           del_hco_activity_queue
        DESCRIPTION:    Remove records from HCO_ACTIVITY_QUEUE that have REC_STATUS = p_REC_STATUS.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    PROCEDURE   del_hco_activity_queue
                (
                    p_REC_STATUS                        IN                      HCO_ACTIVITY_QUEUE.rec_status%TYPE,
                    p_BATCH_SIZE                        IN                      NUMBER                                                      DEFAULT 5000
                )    
    IS
        
        TYPE t_hco_activity_arr IS TABLE OF HCO_ACTIVITY_QUEUE%ROWTYPE;
        
        l_hco_activity_arr                                                      t_hco_activity_arr;

        l_hco_activity_arr_cnt                                                  NUMBER;
        
    BEGIN

        l_hco_activity_arr_cnt  :=  1;
        
        WHILE   l_hco_activity_arr_cnt  >   0
        LOOP
        
            SELECT  *
                    BULK COLLECT INTO
                    l_hco_activity_arr
              FROM  HCO_ACTIVITY_QUEUE
             WHERE  rec_status          =   p_REC_STATUS
               AND  rownum              <=  p_BATCH_SIZE;
        
            l_hco_activity_arr_cnt  :=  l_hco_activity_arr.COUNT;
            
            FOR i IN 1..l_hco_activity_arr.COUNT
            LOOP

                del_hco_activity_queue
                (
                    p_HCO_ACTIVITY_QUEUE_ID             =>  l_hco_activity_arr(i).hco_activity_queue_id
                );
            
                COMMIT;
            
            END LOOP;
        
        END LOOP;
            
    END         del_hco_activity_queue;    
    /*****************************************************************************************************************************************************************

        NAME:           proc_hco_activity_queue
        DESCRIPTION:    Process the records in HCO_ACTIVITY_QUEUE that are pending.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    PROCEDURE   proc_hco_activity_queue
                (
                    p_BATCH_SIZE                        IN                      NUMBER                                                      DEFAULT 10000
                )
    IS
        TYPE t_hco_activity_arr IS TABLE OF HCO_ACTIVITY_QUEUE%ROWTYPE;
        
        l_hco_activity_arr                                                      t_hco_activity_arr;
        
        l_hco_activity_arr_cnt                                                  NUMBER;
        
        l_hco_process_instance_id                                               D_HCO_PROCESS_INSTANCE.hco_process_instance_id%TYPE;        
        
        l_team_id                                                               STEP_INSTANCE.team_id%TYPE;
        l_group_id                                                              STEP_INSTANCE.group_id%TYPE;

        
    BEGIN

        IF  CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_string(p_NAME  =>  'MW_PROC_CONTROL')  =   'STOP'
        THEN
            RETURN;
        END IF;

        l_hco_activity_arr_cnt  :=  1;
        
        WHILE   l_hco_activity_arr_cnt  >   0
        LOOP
        
            IF  CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_string(p_NAME  =>  'MW_PROC_CONTROL')  =   'STOP'
            THEN
                RETURN;
            END IF;

            SELECT  *
                    BULK COLLECT INTO
                    l_hco_activity_arr
              FROM  (
                        SELECT  *
                          FROM  HCO_ACTIVITY_QUEUE
                         WHERE  rec_status              =   'P'
                         ORDER
                            BY  act_status_ts,
                                hco_activity_queue_id
                    )
             WHERE  rownum <= p_BATCH_SIZE;
        
            l_hco_activity_arr_cnt  :=  l_hco_activity_arr.COUNT;
            
            FOR i IN 1..l_hco_activity_arr.COUNT
            LOOP

                upd_hco_activity_queue
                (
                    p_HCO_ACTIVITY_QUEUE_ID             =>  l_hco_activity_arr(i).hco_activity_queue_id,  
                    p_REC_STATUS                        =>  'IP'
                );

                mrg_staff_key_lkup
                (
                    p_STAFF_KEY         =>  l_hco_activity_arr(i).act_owner
                );
        
                mrg_staff_key_lkup
                (
                    p_STAFF_KEY         =>  l_hco_activity_arr(i).act_created_by
                );
    
                IF      l_hco_activity_arr(i).act_owner IS NOT NULL
                    OR  l_hco_activity_arr(i).act_created_by IS NOT NULL
                THEN
                
                    CAHCO_ETL_MW_UTIL_PKG.get_staff_team_biz_unit_ids
                    (
                        p_STAFF_KEY                         =>  NVL(l_hco_activity_arr(i).act_owner, l_hco_activity_arr(i).act_created_by),
                        p_TEAM_ID                           =>  l_team_id,
                        p_BUSINESS_UNIT_ID                  =>  l_group_id
                    );
    
                ELSE
                
                    l_team_id   :=  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id;
                    l_group_id  :=  CAHCO_ETL_MW_UTIL_PKG.get_unknown_business_unit_id;
    
                END IF;

                -- NOTE:  In the call to map_hco_process_instance, the values for p_REF_TYPE and p_REF_ID are NULLed out for process #1, because 
                --        those values are not used when mapping to the process instance.

                l_hco_process_instance_id    :=
                
                map_hco_process_instance
                (
                    p_HCO_PROCESS_ID                    =>  l_hco_activity_arr(i).act_process_id,  
                    p_DCN                               =>  l_hco_activity_arr(i).act_dcn,
                    p_CLIENT_NUMBER                     =>  l_hco_activity_arr(i).act_client_id,
                    p_REF_TYPE                          =>  CASE WHEN   l_hco_activity_arr(i).act_process_id = 1
                                                                 THEN   NULL
                                                                 ELSE   l_hco_activity_arr(i).act_ref_type
                                                            END,
                    p_REF_ID                            =>  CASE WHEN   l_hco_activity_arr(i).act_process_id = 1
                                                                 THEN   NULL
                                                                 ELSE   l_hco_activity_arr(i).act_ref_id
                                                            END,
                    p_INS_IF_NOT_EXISTS                 =>  CAHCO_ETL_MW_UTIL_PKG.is_true
                );

                mrg_step_instance
                (
                    p_STATUS                            =>  l_hco_activity_arr(i).act_status,  
                    p_STATUS_TS                         =>  l_hco_activity_arr(i).act_status_ts,
                    p_ESCALATED_IND                     =>  NULL,
                    p_STEP_DUE_TS                       =>  NULL,
                    p_FORWARDED_IND                     =>  NULL,
                    p_ESCALATE_TO                       =>  NULL,
                    p_FORWARDED_BY                      =>  NULL,
                    p_OWNER                             =>  l_hco_activity_arr(i).act_owner,
                    p_LOCKED_ID                         =>  NULL,
                    p_GROUP_STEP_DEFINITION_ID          =>  NULL,
                    p_GROUP_ID                          =>  l_group_id,
                    p_TEAM_ID                           =>  l_team_id,
                    p_PROCESS_ID                        =>  l_hco_activity_arr(i).act_process_id,
                    p_PRIORITY_CD                       =>  NULL,
                    p_PROCESS_ROUTER_ID                 =>  NULL,
                    p_PROCESS_INSTANCE_ID               =>  l_hco_process_instance_id,
                    p_CASE_ID                           =>  l_hco_activity_arr(i).act_case_id,
                    p_CLIENT_ID                         =>  l_hco_activity_arr(i).act_client_id,
                    p_REF_ID                            =>  l_hco_activity_arr(i).act_ref_id,
                    p_REF_TYPE                          =>  l_hco_activity_arr(i).act_ref_type,
                    p_STEP_DEFINITION_ID                =>  l_hco_activity_arr(i).act_step_definition_id,
                    p_CREATED_BY                        =>  l_hco_activity_arr(i).act_created_by,
                    p_CREATE_TS                         =>  l_hco_activity_arr(i).act_create_ts,                    
                    p_SUSPENDED_TS                      =>  NULL,
                    p_COMMENTS                          =>  l_hco_activity_arr(i).act_comments,
                    p_CREATE_NDT                        =>  NULL,
                    p_STEP_DUE_NDT                      =>  NULL
               
                );

                upd_hco_activity_queue
                (
                    p_HCO_ACTIVITY_QUEUE_ID             =>  l_hco_activity_arr(i).hco_activity_queue_id,  
                    p_REC_STATUS                        =>  'C'
                );
                
                COMMIT;
                
                IF  CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_string(p_NAME  =>  'MW_PROC_CONTROL')  =   'STOP'
                THEN
                    RETURN;
                END IF;
                            
            END LOOP;
        
        END LOOP;
            
    END         proc_hco_activity_queue;
    /*****************************************************************************************************************************************************************

        NAME:           cr_exemption_req_activities
        DESCRIPTION:    Create Exemption Request activities from the Exemption Request record, p_exemption_req_rec.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    PROCEDURE   cr_exemption_req_activities
                (
                    p_exemption_req_rec                 IN                      c_emrs_d_exemption_req%ROWTYPE
                )
    IS          
        rec                                                                     c_emrs_d_exemption_req%ROWTYPE;
    BEGIN

        rec :=  p_exemption_req_rec;
        
        FOR birec IN c_batch_info(  cp_DCN  =>  rec.DCN )
        LOOP
        
            IF  birec.PERFORM_SCAN_START IS NOT NULL
            THEN

                ins_hco_activity_queue
                (
                    p_ACT_STATUS                        =>  c_claimed,
                    p_ACT_STATUS_TS                     =>  birec.PERFORM_SCAN_START,
                    p_ACT_OWNER                         =>  birec.CREATION_USER_ID,
                    p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                    p_ACT_CASE_ID                       =>  NULL,
                    p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                    p_ACT_DCN                           =>  rec.DCN,
                    p_ACT_REF_ID                        =>  rec.EXEMPTION_ID,
                    p_ACT_REF_TYPE                      =>  c_exemption,
                    p_ACT_STEP_DEFINITION_ID            =>  1,
                    p_ACT_PROCESS_ID                    =>  1,
                    p_ACT_CREATED_BY                    =>  birec.CREATION_USER_ID,
                    p_ACT_CREATE_TS                     =>  birec.PERFORM_SCAN_START,
                    p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
                );

                IF  birec.PERFORM_SCAN_END IS NOT NULL
                THEN

                    ins_hco_activity_queue
                    (
                        p_ACT_STATUS                        =>  c_completed,
                        p_ACT_STATUS_TS                     =>  birec.PERFORM_SCAN_END,
                        p_ACT_OWNER                         =>  birec.CREATION_USER_ID,
                        p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                        p_ACT_CASE_ID                       =>  NULL,
                        p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                        p_ACT_DCN                           =>  rec.DCN,
                        p_ACT_REF_ID                        =>  rec.EXEMPTION_ID,
                        p_ACT_REF_TYPE                      =>  c_exemption,
                        p_ACT_STEP_DEFINITION_ID            =>  1,
                        p_ACT_PROCESS_ID                    =>  1,
                        p_ACT_CREATED_BY                    =>  birec.CREATION_USER_ID,
                        p_ACT_CREATE_TS                     =>  birec.PERFORM_SCAN_START,
                        p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
                    );

                END IF;

            END IF;

            IF  birec.RECOGNITION_START IS NOT NULL
            THEN

                ins_hco_activity_queue
                (
                    p_ACT_STATUS                        =>  c_claimed,
                    p_ACT_STATUS_TS                     =>  birec.RECOGNITION_START,
                    p_ACT_OWNER                         =>  birec.CREATION_USER_ID,
                    p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                    p_ACT_CASE_ID                       =>  NULL,
                    p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                    p_ACT_DCN                           =>  rec.DCN,
                    p_ACT_REF_ID                        =>  rec.EXEMPTION_ID,
                    p_ACT_REF_TYPE                      =>  c_exemption,
                    p_ACT_STEP_DEFINITION_ID            =>  2,
                    p_ACT_PROCESS_ID                    =>  1,
                    p_ACT_CREATED_BY                    =>  birec.CREATION_USER_ID,
                    p_ACT_CREATE_TS                     =>  birec.RECOGNITION_START,
                    p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
                );

                IF  birec.RECOGNITION_END IS NOT NULL
                THEN

                    ins_hco_activity_queue
                    (
                        p_ACT_STATUS                        =>  c_completed,
                        p_ACT_STATUS_TS                     =>  birec.RECOGNITION_END,
                        p_ACT_OWNER                         =>  birec.CREATION_USER_ID,
                        p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                        p_ACT_CASE_ID                       =>  NULL,
                        p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                        p_ACT_DCN                           =>  rec.DCN,
                        p_ACT_REF_ID                        =>  rec.EXEMPTION_ID,
                        p_ACT_REF_TYPE                      =>  c_exemption,
                        p_ACT_STEP_DEFINITION_ID            =>  2,
                        p_ACT_PROCESS_ID                    =>  1,
                        p_ACT_CREATED_BY                    =>  birec.CREATION_USER_ID,
                        p_ACT_CREATE_TS                     =>  birec.RECOGNITION_START,
                        p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
                    );

                END IF;

            END IF;

            IF  birec.RELEASE_TO_DMS_START IS NOT NULL
            THEN

                ins_hco_activity_queue
                (
                    p_ACT_STATUS                        =>  c_claimed,
                    p_ACT_STATUS_TS                     =>  birec.RELEASE_TO_DMS_START,
                    p_ACT_OWNER                         =>  birec.CREATION_USER_ID,
                    p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                    p_ACT_CASE_ID                       =>  NULL,
                    p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                    p_ACT_DCN                           =>  rec.DCN,
                    p_ACT_REF_ID                        =>  rec.EXEMPTION_ID,
                    p_ACT_REF_TYPE                      =>  c_exemption,
                    p_ACT_STEP_DEFINITION_ID            =>  12,
                    p_ACT_PROCESS_ID                    =>  1,
                    p_ACT_CREATED_BY                    =>  birec.CREATION_USER_ID,
                    p_ACT_CREATE_TS                     =>  birec.RELEASE_TO_DMS_START,
                    p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
                );

                IF  birec.RELEASE_TO_DMS_END IS NOT NULL
                THEN

                    ins_hco_activity_queue
                    (
                        p_ACT_STATUS                        =>  c_completed,
                        p_ACT_STATUS_TS                     =>  birec.RELEASE_TO_DMS_END,
                        p_ACT_OWNER                         =>  birec.CREATION_USER_ID,
                        p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                        p_ACT_CASE_ID                       =>  NULL,
                        p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                        p_ACT_DCN                           =>  rec.DCN,
                        p_ACT_REF_ID                        =>  rec.EXEMPTION_ID,
                        p_ACT_REF_TYPE                      =>  c_exemption,
                        p_ACT_STEP_DEFINITION_ID            =>  12,
                        p_ACT_PROCESS_ID                    =>  1,
                        p_ACT_CREATED_BY                    =>  birec.CREATION_USER_ID,
                        p_ACT_CREATE_TS                     =>  birec.RELEASE_TO_DMS_START,
                        p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
                    );

                END IF;

            END IF;
                                
        END LOOP;

        ins_hco_activity_queue
        (
            p_ACT_STATUS                        =>  c_claimed,
            p_ACT_STATUS_TS                     =>  rec.RECORD_DATE,
            p_ACT_OWNER                         =>  NULL,
            p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
            p_ACT_CASE_ID                       =>  NULL,
            p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
            p_ACT_DCN                           =>  rec.DCN,
            p_ACT_REF_ID                        =>  rec.EXEMPTION_ID,
            p_ACT_REF_TYPE                      =>  c_exemption,
            p_ACT_STEP_DEFINITION_ID            =>  7,
            p_ACT_PROCESS_ID                    =>  1,
            p_ACT_CREATED_BY                    =>  rec.RECORD_NAME,
            p_ACT_CREATE_TS                     =>  rec.RECORD_DATE,
            p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
        );


        ins_hco_activity_queue
        (
            p_ACT_STATUS                        =>  c_completed,
            p_ACT_STATUS_TS                     =>  rec.RECORD_DATE,
            p_ACT_OWNER                         =>  NULL,
            p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
            p_ACT_CASE_ID                       =>  NULL,
            p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
            p_ACT_DCN                           =>  rec.DCN,
            p_ACT_REF_ID                        =>  rec.EXEMPTION_ID,
            p_ACT_REF_TYPE                      =>  c_exemption,
            p_ACT_STEP_DEFINITION_ID            =>  7,
            p_ACT_PROCESS_ID                    =>  1,
            p_ACT_CREATED_BY                    =>  rec.RECORD_NAME,
            p_ACT_CREATE_TS                     =>  rec.RECORD_DATE,
            p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
        );

        ins_hco_activity_queue
        (
            p_ACT_STATUS                        =>  c_unclaimed,
            p_ACT_STATUS_TS                     =>  rec.RECORD_DATE,
            p_ACT_OWNER                         =>  NULL,
            p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
            p_ACT_CASE_ID                       =>  NULL,
            p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
            p_ACT_DCN                           =>  rec.DCN,
            p_ACT_REF_ID                        =>  rec.EXEMPTION_ID,
            p_ACT_REF_TYPE                      =>  c_exemption,
            p_ACT_STEP_DEFINITION_ID            =>  9,
            p_ACT_PROCESS_ID                    =>  1,
            p_ACT_CREATED_BY                    =>  rec.RECORD_NAME,
            p_ACT_CREATE_TS                     =>  rec.RECORD_DATE,
            p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.claimed_on_ownership_change
        );
    
    END         cr_exemption_req_activities;
    /*****************************************************************************************************************************************************************

        NAME:           proc_emrs_d_exemption_req
        DESCRIPTION:    Process the records in the table EMRS_D_EXEMPTION_REQ.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    PROCEDURE   proc_emrs_d_exemption_req
    IS
                                     
        l_mw_exemption_proc_dt                                                  DATE;
        
    BEGIN

        IF  CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_string(p_NAME  =>  'MW_PROC_CONTROL')  =   'STOP'
        THEN
            RETURN;
        END IF;

        FOR rec IN c_emrs_d_exemption_req
        LOOP

            IF  CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_string(p_NAME  =>  'MW_PROC_CONTROL')  =   'STOP'
            THEN
                RETURN;
            END IF;
        
            IF  l_mw_exemption_proc_dt IS NULL
            THEN
                l_mw_exemption_proc_dt    :=  rec.modified_date;
            ELSIF       rec.modified_date   >   l_mw_exemption_proc_dt
                    AND rec.modified_date   <=  SYSDATE
            THEN
                l_mw_exemption_proc_dt    :=  rec.modified_date;  
            END IF;
            
            cr_exemption_req_activities
            (
                p_exemption_req_rec                 =>  rec
            );
                
            COMMIT;
                    
        END LOOP;
        
        CAHCO_ETL_MW_UTIL_PKG.set_corp_etl_control_date
        (
            p_NAME                              =>  'MW_EXEMPTION_PROC_DATE',
            p_DATE                              =>  l_mw_exemption_proc_dt
        );

    END         proc_emrs_d_exemption_req;
    /*****************************************************************************************************************************************************************

        NAME:           cr_exemption_sh_activities
        DESCRIPTION:    Create Exemption Status History activities from the Exemption Status History record, p_exemption_sh_rec.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    PROCEDURE   cr_exemption_sh_activities
                (
                    p_exemption_sh_rec                 IN                      c_emrs_d_exempt_status_hist%ROWTYPE
                )
    IS          
        rec                                                                     c_emrs_d_exempt_status_hist%ROWTYPE;        
    BEGIN

        rec :=  p_exemption_sh_rec;

        ins_hco_activity_queue
        (
            p_ACT_STATUS                        =>  CASE WHEN rec.final_status = 'Y' THEN c_completed ELSE NULL END,
            p_ACT_STATUS_TS                     =>  rec.RECORD_DATE,
            p_ACT_OWNER                         =>  rec.RECORD_NAME,
            p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
            p_ACT_CASE_ID                       =>  NULL,
            p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
            p_ACT_DCN                           =>  rec.DCN,
            p_ACT_REF_ID                        =>  rec.EXEMPTION_ID,
            p_ACT_REF_TYPE                      =>  c_exemption,
            p_ACT_STEP_DEFINITION_ID            =>  9,
            p_ACT_PROCESS_ID                    =>  1,
            p_ACT_CREATED_BY                    =>  rec.RECORD_NAME,
            p_ACT_CREATE_TS                     =>  rec.EXEMPTION_RECORD_DATE,
            p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.claimed_on_ownership_change
        );
            
    END         cr_exemption_sh_activities;
    /*****************************************************************************************************************************************************************

        NAME:           proc_emrs_d_exempt_status_hist
        DESCRIPTION:    Process the records in the table EMRS_D_EXEMPT_STATUS_HIST.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    PROCEDURE   proc_emrs_d_exempt_status_hist
    IS

        l_mw_exemption_sh_proc_dt                                               DATE;
        
    BEGIN

        IF  CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_string(p_NAME  =>  'MW_PROC_CONTROL')  =   'STOP'
        THEN
            RETURN;
        END IF;

        FOR rec IN c_emrs_d_exempt_status_hist
        LOOP

            IF  CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_string(p_NAME  =>  'MW_PROC_CONTROL')  =   'STOP'
            THEN
                RETURN;
            END IF;
        
            IF  l_mw_exemption_sh_proc_dt IS NULL
            THEN
                l_mw_exemption_sh_proc_dt    :=  rec.record_date;
            ELSIF       rec.record_date     >   l_mw_exemption_sh_proc_dt
                    AND rec.record_date     <=  SYSDATE
            THEN
                l_mw_exemption_sh_proc_dt    :=  rec.record_date;  
            END IF;

            cr_exemption_sh_activities
            (
                p_exemption_sh_rec                 =>   rec
            );   
                
            COMMIT;
            
        END LOOP;
        
        CAHCO_ETL_MW_UTIL_PKG.set_corp_etl_control_date
        (
            p_NAME                              =>  'MW_EXEMPTION_SH_PROC_DATE',
            p_DATE                              =>  l_mw_exemption_sh_proc_dt
        );
        
    END         proc_emrs_d_exempt_status_hist;
    /*****************************************************************************************************************************************************************

        NAME:           cr_eder_activities
        DESCRIPTION:    Create EDER activities from the EDER record, p_eder_rec.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    PROCEDURE   cr_eder_activities
                (
                    p_eder_rec                          IN                      c_emrs_d_emrgcy_disenroll%ROWTYPE
                )
    IS          
        rec                                                                     c_emrs_d_emrgcy_disenroll%ROWTYPE;
    BEGIN

        rec :=  p_eder_rec;
        
        FOR birec IN c_batch_info(  cp_DCN  =>  rec.DCN )
        LOOP
        
            IF  birec.PERFORM_SCAN_START IS NOT NULL
            THEN

                ins_hco_activity_queue
                (
                    p_ACT_STATUS                        =>  c_claimed,
                    p_ACT_STATUS_TS                     =>  birec.PERFORM_SCAN_START,
                    p_ACT_OWNER                         =>  birec.CREATION_USER_ID,
                    p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                    p_ACT_CASE_ID                       =>  NULL,
                    p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                    p_ACT_DCN                           =>  rec.DCN,
                    p_ACT_REF_ID                        =>  rec.EMRGCY_DISENROLL_ID,
                    p_ACT_REF_TYPE                      =>  c_eder,
                    p_ACT_STEP_DEFINITION_ID            =>  1,
                    p_ACT_PROCESS_ID                    =>  1,
                    p_ACT_CREATED_BY                    =>  birec.CREATION_USER_ID,
                    p_ACT_CREATE_TS                     =>  birec.PERFORM_SCAN_START,
                    p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
                );

                IF  birec.PERFORM_SCAN_END IS NOT NULL
                THEN

                    ins_hco_activity_queue
                    (
                        p_ACT_STATUS                        =>  c_completed,
                        p_ACT_STATUS_TS                     =>  birec.PERFORM_SCAN_END,
                        p_ACT_OWNER                         =>  birec.CREATION_USER_ID,
                        p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                        p_ACT_CASE_ID                       =>  NULL,
                        p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                        p_ACT_DCN                           =>  rec.DCN,
                        p_ACT_REF_ID                        =>  rec.EMRGCY_DISENROLL_ID,
                        p_ACT_REF_TYPE                      =>  c_eder,
                        p_ACT_STEP_DEFINITION_ID            =>  1,
                        p_ACT_PROCESS_ID                    =>  1,
                        p_ACT_CREATED_BY                    =>  birec.CREATION_USER_ID,
                        p_ACT_CREATE_TS                     =>  birec.PERFORM_SCAN_START,
                        p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
                    );

                END IF;

            END IF;

            IF  birec.RECOGNITION_START IS NOT NULL
            THEN

                ins_hco_activity_queue
                (
                    p_ACT_STATUS                        =>  c_claimed,
                    p_ACT_STATUS_TS                     =>  birec.RECOGNITION_START,
                    p_ACT_OWNER                         =>  birec.CREATION_USER_ID,
                    p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                    p_ACT_CASE_ID                       =>  NULL,
                    p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                    p_ACT_DCN                           =>  rec.DCN,
                    p_ACT_REF_ID                        =>  rec.EMRGCY_DISENROLL_ID,
                    p_ACT_REF_TYPE                      =>  c_eder,
                    p_ACT_STEP_DEFINITION_ID            =>  2,
                    p_ACT_PROCESS_ID                    =>  1,
                    p_ACT_CREATED_BY                    =>  birec.CREATION_USER_ID,
                    p_ACT_CREATE_TS                     =>  birec.RECOGNITION_START,
                    p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
                );

                IF  birec.RECOGNITION_END IS NOT NULL
                THEN

                    ins_hco_activity_queue
                    (
                        p_ACT_STATUS                        =>  c_completed,
                        p_ACT_STATUS_TS                     =>  birec.RECOGNITION_END,
                        p_ACT_OWNER                         =>  birec.CREATION_USER_ID,
                        p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                        p_ACT_CASE_ID                       =>  NULL,
                        p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                        p_ACT_DCN                           =>  rec.DCN,
                        p_ACT_REF_ID                        =>  rec.EMRGCY_DISENROLL_ID,
                        p_ACT_REF_TYPE                      =>  c_eder,
                        p_ACT_STEP_DEFINITION_ID            =>  2,
                        p_ACT_PROCESS_ID                    =>  1,
                        p_ACT_CREATED_BY                    =>  birec.CREATION_USER_ID,
                        p_ACT_CREATE_TS                     =>  birec.RECOGNITION_START,
                        p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
                    );

                END IF;

            END IF;

            IF  birec.RELEASE_TO_DMS_START IS NOT NULL
            THEN

                ins_hco_activity_queue
                (
                    p_ACT_STATUS                        =>  c_claimed,
                    p_ACT_STATUS_TS                     =>  birec.RELEASE_TO_DMS_START,
                    p_ACT_OWNER                         =>  birec.CREATION_USER_ID,
                    p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                    p_ACT_CASE_ID                       =>  NULL,
                    p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                    p_ACT_DCN                           =>  rec.DCN,
                    p_ACT_REF_ID                        =>  rec.EMRGCY_DISENROLL_ID,
                    p_ACT_REF_TYPE                      =>  c_eder,
                    p_ACT_STEP_DEFINITION_ID            =>  12,
                    p_ACT_PROCESS_ID                    =>  1,
                    p_ACT_CREATED_BY                    =>  birec.CREATION_USER_ID,
                    p_ACT_CREATE_TS                     =>  birec.RELEASE_TO_DMS_START,
                    p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
                );

                IF  birec.RELEASE_TO_DMS_END IS NOT NULL
                THEN

                    ins_hco_activity_queue
                    (
                        p_ACT_STATUS                        =>  c_completed,
                        p_ACT_STATUS_TS                     =>  birec.RELEASE_TO_DMS_END,
                        p_ACT_OWNER                         =>  birec.CREATION_USER_ID,
                        p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                        p_ACT_CASE_ID                       =>  NULL,
                        p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                        p_ACT_DCN                           =>  rec.DCN,
                        p_ACT_REF_ID                        =>  rec.EMRGCY_DISENROLL_ID,
                        p_ACT_REF_TYPE                      =>  c_eder,
                        p_ACT_STEP_DEFINITION_ID            =>  12,
                        p_ACT_PROCESS_ID                    =>  1,
                        p_ACT_CREATED_BY                    =>  birec.CREATION_USER_ID,
                        p_ACT_CREATE_TS                     =>  birec.RELEASE_TO_DMS_START,
                        p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
                    );

                END IF;

            END IF;
                                
        END LOOP;

        ins_hco_activity_queue
        (
            p_ACT_STATUS                        =>  c_claimed,
            p_ACT_STATUS_TS                     =>  rec.RECORD_DATE,
            p_ACT_OWNER                         =>  NULL,
            p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
            p_ACT_CASE_ID                       =>  NULL,
            p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
            p_ACT_DCN                           =>  rec.DCN,
            p_ACT_REF_ID                        =>  rec.EMRGCY_DISENROLL_ID,
            p_ACT_REF_TYPE                      =>  c_eder,
            p_ACT_STEP_DEFINITION_ID            =>  7,
            p_ACT_PROCESS_ID                    =>  1,
            p_ACT_CREATED_BY                    =>  rec.RECORD_NAME,
            p_ACT_CREATE_TS                     =>  rec.RECORD_DATE,
            p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
        );


        ins_hco_activity_queue
        (
            p_ACT_STATUS                        =>  c_completed,
            p_ACT_STATUS_TS                     =>  rec.RECORD_DATE,
            p_ACT_OWNER                         =>  NULL,
            p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
            p_ACT_CASE_ID                       =>  NULL,
            p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
            p_ACT_DCN                           =>  rec.DCN,
            p_ACT_REF_ID                        =>  rec.EMRGCY_DISENROLL_ID,
            p_ACT_REF_TYPE                      =>  c_eder,
            p_ACT_STEP_DEFINITION_ID            =>  7,
            p_ACT_PROCESS_ID                    =>  1,
            p_ACT_CREATED_BY                    =>  rec.RECORD_NAME,
            p_ACT_CREATE_TS                     =>  rec.RECORD_DATE,
            p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
        );

        ins_hco_activity_queue
        (
            p_ACT_STATUS                        =>  c_unclaimed,
            p_ACT_STATUS_TS                     =>  rec.RECORD_DATE,
            p_ACT_OWNER                         =>  NULL,
            p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
            p_ACT_CASE_ID                       =>  NULL,
            p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
            p_ACT_DCN                           =>  rec.DCN,
            p_ACT_REF_ID                        =>  rec.EMRGCY_DISENROLL_ID,
            p_ACT_REF_TYPE                      =>  c_eder,
            p_ACT_STEP_DEFINITION_ID            =>  8,
            p_ACT_PROCESS_ID                    =>  1,
            p_ACT_CREATED_BY                    =>  rec.RECORD_NAME,
            p_ACT_CREATE_TS                     =>  rec.RECORD_DATE,
            p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.claimed_on_ownership_change
        );
    
    END         cr_eder_activities;
    /*****************************************************************************************************************************************************************

        NAME:           proc_emrs_d_emrgcy_disenroll
        DESCRIPTION:    Process the records in the table EMRS_D_EMRGCY_DISENROLL.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    PROCEDURE   proc_emrs_d_emrgcy_disenroll
    IS
        
        l_mw_eder_proc_dt                                                       DATE;
        
    BEGIN

        IF  CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_string(p_NAME  =>  'MW_PROC_CONTROL')  =   'STOP'
        THEN
            RETURN;
        END IF;

        FOR rec IN c_emrs_d_emrgcy_disenroll
        LOOP

            IF  CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_string(p_NAME  =>  'MW_PROC_CONTROL')  =   'STOP'
            THEN
                RETURN;
            END IF;
        
            IF  l_mw_eder_proc_dt IS NULL
            THEN
                l_mw_eder_proc_dt    :=  rec.modified_date;
            ELSIF       rec.modified_date   >   l_mw_eder_proc_dt
                    AND rec.modified_date   <=  SYSDATE
            THEN
                l_mw_eder_proc_dt    :=  rec.modified_date;  
            END IF;

            cr_eder_activities
            (
                p_eder_rec                          =>  rec
            );           
                
            COMMIT;
                    
        END LOOP;

        CAHCO_ETL_MW_UTIL_PKG.set_corp_etl_control_date
        (
            p_NAME                              =>  'MW_EDER_PROC_DATE',
            p_DATE                              =>  l_mw_eder_proc_dt
        );
                
    END         proc_emrs_d_emrgcy_disenroll;
    /*****************************************************************************************************************************************************************

        NAME:           cr_eder_hist_activities
        DESCRIPTION:    Create EDER History activities from the EDER History record, p_eder_hist_rec.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    PROCEDURE   cr_eder_hist_activities
                (
                    p_eder_hist_rec                     IN                      c_proc_emrs_d_emrgcy_denr_hist%ROWTYPE
                )
    IS          
        rec                                                                     c_proc_emrs_d_emrgcy_denr_hist%ROWTYPE;        
    BEGIN

        rec :=  p_eder_hist_rec;

        ins_hco_activity_queue
        (
            p_ACT_STATUS                        =>  CASE WHEN rec.final_status = 'Y' THEN c_completed ELSE NULL END,
            p_ACT_STATUS_TS                     =>  rec.RECORD_DATE,
            p_ACT_OWNER                         =>  rec.RECORD_NAME,
            p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
            p_ACT_CASE_ID                       =>  NULL,
            p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
            p_ACT_DCN                           =>  rec.DCN,
            p_ACT_REF_ID                        =>  rec.EMRGCY_DENR_ID,
            p_ACT_REF_TYPE                      =>  c_eder,
            p_ACT_STEP_DEFINITION_ID            =>  8,
            p_ACT_PROCESS_ID                    =>  1,
            p_ACT_CREATED_BY                    =>  rec.RECORD_NAME,
            p_ACT_CREATE_TS                     =>  rec.EDER_RECORD_DATE,
            p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.claimed_on_ownership_change
        );
            
    END         cr_eder_hist_activities;
   /*****************************************************************************************************************************************************************

        NAME:           proc_emrs_d_emrgcy_denr_hist
        DESCRIPTION:    Process the records in the table EMRS_D_EMRGCY_DENR_HIST.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    PROCEDURE   proc_emrs_d_emrgcy_denr_hist
    IS

        l_mw_eder_sh_proc_dt                                                    DATE;
        
    BEGIN

        IF  CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_string(p_NAME  =>  'MW_PROC_CONTROL')  =   'STOP'
        THEN
            RETURN;
        END IF;

        FOR rec IN c_proc_emrs_d_emrgcy_denr_hist
        LOOP

            IF  CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_string(p_NAME  =>  'MW_PROC_CONTROL')  =   'STOP'
            THEN
                RETURN;
            END IF;
        
            IF  l_mw_eder_sh_proc_dt IS NULL
            THEN
                l_mw_eder_sh_proc_dt    :=  rec.record_date;
            ELSIF       rec.record_date     >   l_mw_eder_sh_proc_dt
                    AND rec.record_date     <=  SYSDATE
            THEN
                l_mw_eder_sh_proc_dt    :=  rec.record_date;  
            END IF;
            
            cr_eder_hist_activities
            (
                p_eder_hist_rec                     =>  rec
            );
                
            COMMIT;
                    
        END LOOP;
        
        CAHCO_ETL_MW_UTIL_PKG.set_corp_etl_control_date
        (
            p_NAME                              =>  'MW_EDER_SH_PROC_DATE',
            p_DATE                              =>  l_mw_eder_sh_proc_dt
        );

    END         proc_emrs_d_emrgcy_denr_hist;   
    /*****************************************************************************************************************************************************************

        NAME:           cr_enrollment_activities
        DESCRIPTION:    Create Enrollment activities from the Enrollment record, p_enrollment_rec.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    PROCEDURE   cr_enrollment_activities
                (
                    p_enrollment_rec                    IN                      c_emrs_f_enrollment%ROWTYPE
                )
    IS          
        l_act_ref_type                                                          HCO_ACTIVITY_QUEUE.act_ref_type%TYPE;

        rec                                                                     c_emrs_f_enrollment%ROWTYPE;            
    BEGIN

        rec :=  p_enrollment_rec;
        
        IF  rec.enrollment_trans_type_code = '1'
        THEN
            l_act_ref_type  :=  c_enrollment;
        ELSE
            l_act_ref_type  :=  c_disenrollment;
        END IF;
                
        FOR birec IN c_batch_info(  cp_DCN  =>  rec.DCN )
        LOOP
        
            IF  birec.PERFORM_SCAN_START IS NOT NULL
            THEN

                ins_hco_activity_queue
                (
                    p_ACT_STATUS                        =>  c_claimed,
                    p_ACT_STATUS_TS                     =>  birec.PERFORM_SCAN_START,
                    p_ACT_OWNER                         =>  birec.CREATION_USER_ID,
                    p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                    p_ACT_CASE_ID                       =>  NULL,
                    p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                    p_ACT_DCN                           =>  rec.DCN,
                    p_ACT_REF_ID                        =>  rec.ENROLLMENT_ID,
                    p_ACT_REF_TYPE                      =>  l_act_ref_type,
                    p_ACT_STEP_DEFINITION_ID            =>  1,
                    p_ACT_PROCESS_ID                    =>  1,
                    p_ACT_CREATED_BY                    =>  birec.CREATION_USER_ID,
                    p_ACT_CREATE_TS                     =>  birec.PERFORM_SCAN_START,
                    p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
                );

                IF  birec.PERFORM_SCAN_END IS NOT NULL
                THEN

                    ins_hco_activity_queue
                    (
                        p_ACT_STATUS                        =>  c_completed,
                        p_ACT_STATUS_TS                     =>  birec.PERFORM_SCAN_END,
                        p_ACT_OWNER                         =>  birec.CREATION_USER_ID,
                        p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                        p_ACT_CASE_ID                       =>  NULL,
                        p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                        p_ACT_DCN                           =>  rec.DCN,
                        p_ACT_REF_ID                        =>  rec.ENROLLMENT_ID,
                        p_ACT_REF_TYPE                      =>  l_act_ref_type,
                        p_ACT_STEP_DEFINITION_ID            =>  1,
                        p_ACT_PROCESS_ID                    =>  1,
                        p_ACT_CREATED_BY                    =>  birec.CREATION_USER_ID,
                        p_ACT_CREATE_TS                     =>  birec.PERFORM_SCAN_START,
                        p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
                    );

                END IF;

            END IF;

            IF  birec.RECOGNITION_START IS NOT NULL
            THEN

                ins_hco_activity_queue
                (
                    p_ACT_STATUS                        =>  c_claimed,
                    p_ACT_STATUS_TS                     =>  birec.RECOGNITION_START,
                    p_ACT_OWNER                         =>  birec.CREATION_USER_ID,
                    p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                    p_ACT_CASE_ID                       =>  NULL,
                    p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                    p_ACT_DCN                           =>  rec.DCN,
                    p_ACT_REF_ID                        =>  rec.ENROLLMENT_ID,
                    p_ACT_REF_TYPE                      =>  l_act_ref_type,
                    p_ACT_STEP_DEFINITION_ID            =>  2,
                    p_ACT_PROCESS_ID                    =>  1,
                    p_ACT_CREATED_BY                    =>  birec.CREATION_USER_ID,
                    p_ACT_CREATE_TS                     =>  birec.RECOGNITION_START,
                    p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
                );

                IF  birec.RECOGNITION_END IS NOT NULL
                THEN

                    ins_hco_activity_queue
                    (
                        p_ACT_STATUS                        =>  c_completed,
                        p_ACT_STATUS_TS                     =>  birec.RECOGNITION_END,
                        p_ACT_OWNER                         =>  birec.CREATION_USER_ID,
                        p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                        p_ACT_CASE_ID                       =>  NULL,
                        p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                        p_ACT_DCN                           =>  rec.DCN,
                        p_ACT_REF_ID                        =>  rec.ENROLLMENT_ID,
                        p_ACT_REF_TYPE                      =>  l_act_ref_type,
                        p_ACT_STEP_DEFINITION_ID            =>  2,
                        p_ACT_PROCESS_ID                    =>  1,
                        p_ACT_CREATED_BY                    =>  birec.CREATION_USER_ID,
                        p_ACT_CREATE_TS                     =>  birec.RECOGNITION_START,
                        p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
                    );

                END IF;

            END IF;

            IF  birec.RELEASE_TO_DMS_START IS NOT NULL
            THEN

                ins_hco_activity_queue
                (
                    p_ACT_STATUS                        =>  c_claimed,
                    p_ACT_STATUS_TS                     =>  birec.RELEASE_TO_DMS_START,
                    p_ACT_OWNER                         =>  birec.CREATION_USER_ID,
                    p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                    p_ACT_CASE_ID                       =>  NULL,
                    p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                    p_ACT_DCN                           =>  rec.DCN,
                    p_ACT_REF_ID                        =>  rec.ENROLLMENT_ID,
                    p_ACT_REF_TYPE                      =>  l_act_ref_type,
                    p_ACT_STEP_DEFINITION_ID            =>  12,
                    p_ACT_PROCESS_ID                    =>  1,
                    p_ACT_CREATED_BY                    =>  birec.CREATION_USER_ID,
                    p_ACT_CREATE_TS                     =>  birec.RELEASE_TO_DMS_START,
                    p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
                );

                IF  birec.RELEASE_TO_DMS_END IS NOT NULL
                THEN

                    ins_hco_activity_queue
                    (
                        p_ACT_STATUS                        =>  c_completed,
                        p_ACT_STATUS_TS                     =>  birec.RELEASE_TO_DMS_END,
                        p_ACT_OWNER                         =>  birec.CREATION_USER_ID,
                        p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                        p_ACT_CASE_ID                       =>  NULL,
                        p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                        p_ACT_DCN                           =>  rec.DCN,
                        p_ACT_REF_ID                        =>  rec.ENROLLMENT_ID,
                        p_ACT_REF_TYPE                      =>  l_act_ref_type,
                        p_ACT_STEP_DEFINITION_ID            =>  12,
                        p_ACT_PROCESS_ID                    =>  1,
                        p_ACT_CREATED_BY                    =>  birec.CREATION_USER_ID,
                        p_ACT_CREATE_TS                     =>  birec.RELEASE_TO_DMS_START,
                        p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
                    );

                END IF;

            END IF;
                                
        END LOOP;

        IF      rec.verifier_id IS NOT NULL
            AND rec.channel_id in ('2')
        THEN

            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_claimed,
                p_ACT_STATUS_TS                     =>  rec.RECORD_DATE,
                p_ACT_OWNER                         =>  rec.RECORD_NAME,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  NULL,
                p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                p_ACT_DCN                           =>  rec.DCN,
                p_ACT_REF_ID                        =>  rec.ENROLLMENT_ID,
                p_ACT_REF_TYPE                      =>  l_act_ref_type,
                p_ACT_STEP_DEFINITION_ID            =>  3,
                p_ACT_PROCESS_ID                    =>  1,
                p_ACT_CREATED_BY                    =>  rec.RECORD_NAME,
                p_ACT_CREATE_TS                     =>  rec.RECORD_DATE,
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );
        
        END IF;
        
        IF      rec.channel_id in ('1','9','10','13','14','15','17') 
        THEN

            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_claimed,
                p_ACT_STATUS_TS                     =>  rec.RECORD_DATE,
                p_ACT_OWNER                         =>  rec.RECORD_NAME,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  NULL,
                p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                p_ACT_DCN                           =>  rec.DCN,
                p_ACT_REF_ID                        =>  rec.ENROLLMENT_ID,
                p_ACT_REF_TYPE                      =>  l_act_ref_type,
                p_ACT_STEP_DEFINITION_ID            =>  14,
                p_ACT_PROCESS_ID                    =>  1,
                p_ACT_CREATED_BY                    =>  rec.RECORD_NAME,
                p_ACT_CREATE_TS                     =>  rec.RECORD_DATE,                    
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );

        END IF;

        IF      rec.verifier_id IS NOT NULL
            AND rec.channel_id in ('2')
            AND rec.export_batch_date IS NOT NULL            
        THEN

            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_completed,
                p_ACT_STATUS_TS                     =>  rec.EXPORT_BATCH_DATE,
                p_ACT_OWNER                         =>  rec.MODIFIED_NAME,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  NULL,
                p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                p_ACT_DCN                           =>  rec.DCN,
                p_ACT_REF_ID                        =>  rec.ENROLLMENT_ID,
                p_ACT_REF_TYPE                      =>  l_act_ref_type,
                p_ACT_STEP_DEFINITION_ID            =>  3,
                p_ACT_PROCESS_ID                    =>  1,
                p_ACT_CREATED_BY                    =>  rec.RECORD_NAME,
                p_ACT_CREATE_TS                     =>  rec.RECORD_DATE,                    
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );

        END IF;                

        IF      rec.channel_id in ('1','9','10','13','14','15','17') 
            AND rec.export_batch_date IS NOT NULL                        
        THEN

            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_completed,
                p_ACT_STATUS_TS                     =>  rec.EXPORT_BATCH_DATE,
                p_ACT_OWNER                         =>  rec.MODIFIED_NAME,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  NULL,
                p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                p_ACT_DCN                           =>  rec.DCN,
                p_ACT_REF_ID                        =>  rec.ENROLLMENT_ID,
                p_ACT_REF_TYPE                      =>  l_act_ref_type,
                p_ACT_STEP_DEFINITION_ID            =>  14,
                p_ACT_PROCESS_ID                    =>  1,
                p_ACT_CREATED_BY                    =>  rec.RECORD_NAME,
                p_ACT_CREATE_TS                     =>  rec.RECORD_DATE,                                            
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );

        END IF;
                    
        IF      rec.meds_process_start_date IS NOT NULL
            AND rec.meds_process_end_date IS NOT NULL
        THEN

            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_claimed,
                p_ACT_STATUS_TS                     =>  rec.meds_process_start_date,
                p_ACT_OWNER                         =>  rec.MODIFIED_NAME,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  NULL,
                p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                p_ACT_DCN                           =>  rec.DCN,
                p_ACT_REF_ID                        =>  rec.ENROLLMENT_ID,
                p_ACT_REF_TYPE                      =>  l_act_ref_type,
                p_ACT_STEP_DEFINITION_ID            =>  4,
                p_ACT_PROCESS_ID                    =>  1,
                p_ACT_CREATED_BY                    =>  rec.MODIFIED_NAME,
                p_ACT_CREATE_TS                     =>  rec.meds_process_start_date,                    
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );

            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_completed,
                p_ACT_STATUS_TS                     =>  rec.meds_process_end_date,
                p_ACT_OWNER                         =>  rec.MODIFIED_NAME,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  NULL,
                p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                p_ACT_DCN                           =>  rec.DCN,
                p_ACT_REF_ID                        =>  rec.ENROLLMENT_ID,
                p_ACT_REF_TYPE                      =>  l_act_ref_type,
                p_ACT_STEP_DEFINITION_ID            =>  4,
                p_ACT_PROCESS_ID                    =>  1,
                p_ACT_CREATED_BY                    =>  rec.MODIFIED_NAME,
                p_ACT_CREATE_TS                     =>  rec.meds_process_start_date,                                        
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );

            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_claimed,
                p_ACT_STATUS_TS                     =>  rec.meds_process_end_date,
                p_ACT_OWNER                         =>  rec.MODIFIED_NAME,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  NULL,
                p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                p_ACT_DCN                           =>  rec.DCN,
                p_ACT_REF_ID                        =>  rec.ENROLLMENT_ID,
                p_ACT_REF_TYPE                      =>  l_act_ref_type,
                p_ACT_STEP_DEFINITION_ID            =>  5,
                p_ACT_PROCESS_ID                    =>  1,
                p_ACT_CREATED_BY                    =>  rec.MODIFIED_NAME,
                p_ACT_CREATE_TS                     =>  rec.meds_process_end_date,                    
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );
            
            IF      rec.date_errors_fixed IS NOT NULL
            THEN
                ins_hco_activity_queue
                (
                    p_ACT_STATUS                        =>  c_claimed,
                    p_ACT_STATUS_TS                     =>  rec.meds_process_end_date,
                    p_ACT_OWNER                         =>  rec.MODIFIED_NAME,
                    p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                    p_ACT_CASE_ID                       =>  NULL,
                    p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                    p_ACT_DCN                           =>  rec.DCN,
                    p_ACT_REF_ID                        =>  rec.ENROLLMENT_ID,
                    p_ACT_REF_TYPE                      =>  l_act_ref_type,
                    p_ACT_STEP_DEFINITION_ID            =>  15,
                    p_ACT_PROCESS_ID                    =>  1,
                    p_ACT_CREATED_BY                    =>  rec.MODIFIED_NAME,
                    p_ACT_CREATE_TS                     =>  rec.meds_process_end_date,                        
                    p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
                );

                ins_hco_activity_queue
                (
                    p_ACT_STATUS                        =>  c_completed,
                    p_ACT_STATUS_TS                     =>  rec.DATE_ERRORS_FIXED,
                    p_ACT_OWNER                         =>  rec.MODIFIED_NAME,
                    p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                    p_ACT_CASE_ID                       =>  NULL,
                    p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                    p_ACT_DCN                           =>  rec.DCN,
                    p_ACT_REF_ID                        =>  rec.ENROLLMENT_ID,
                    p_ACT_REF_TYPE                      =>  l_act_ref_type,
                    p_ACT_STEP_DEFINITION_ID            =>  15,
                    p_ACT_PROCESS_ID                    =>  1,
                    p_ACT_CREATED_BY                    =>  rec.MODIFIED_NAME,
                    p_ACT_CREATE_TS                     =>  rec.meds_process_end_date,                        
                    p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
                );

            END IF;
                    
        END IF;
        
        IF      rec.meds_process_end_date IS NOT NULL
            AND rec.accept_date IS NOT NULL                
        THEN

            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_completed,
                p_ACT_STATUS_TS                     =>  rec.ACCEPT_DATE,
                p_ACT_OWNER                         =>  rec.MODIFIED_NAME,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  NULL,
                p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                p_ACT_DCN                           =>  rec.DCN,
                p_ACT_REF_ID                        =>  rec.ENROLLMENT_ID,
                p_ACT_REF_TYPE                      =>  l_act_ref_type,
                p_ACT_STEP_DEFINITION_ID            =>  5,
                p_ACT_PROCESS_ID                    =>  1,
                p_ACT_CREATED_BY                    =>  rec.MODIFIED_NAME,
                p_ACT_CREATE_TS                     =>  rec.meds_process_end_date,                    
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );

            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_claimed,
                p_ACT_STATUS_TS                     =>  rec.ACCEPT_DATE,
                p_ACT_OWNER                         =>  rec.MODIFIED_NAME,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  NULL,
                p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                p_ACT_DCN                           =>  rec.DCN,
                p_ACT_REF_ID                        =>  rec.ENROLLMENT_ID,
                p_ACT_REF_TYPE                      =>  l_act_ref_type,
                p_ACT_STEP_DEFINITION_ID            =>  6,
                p_ACT_PROCESS_ID                    =>  1,
                p_ACT_CREATED_BY                    =>  rec.MODIFIED_NAME,
                p_ACT_CREATE_TS                     =>  rec.ACCEPT_DATE,                    
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );
        
        END IF;

        IF      rec.ACCEPT_DATE IS NOT NULL
            AND rec.cldl_sent_date IS NOT NULL
        THEN

            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_completed,
                p_ACT_STATUS_TS                     =>  rec.CLDL_SENT_DATE,
                p_ACT_OWNER                         =>  rec.MODIFIED_NAME,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  NULL,
                p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                p_ACT_DCN                           =>  rec.DCN,
                p_ACT_REF_ID                        =>  rec.ENROLLMENT_ID,
                p_ACT_REF_TYPE                      =>  l_act_ref_type,
                p_ACT_STEP_DEFINITION_ID            =>  6,
                p_ACT_PROCESS_ID                    =>  1,
                p_ACT_CREATED_BY                    =>  rec.MODIFIED_NAME,
                p_ACT_CREATE_TS                     =>  rec.ACCEPT_DATE,                                        
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );

        END IF;
        
        IF  rec.date_timed_out IS NOT NULL
        THEN

            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_claimed,
                p_ACT_STATUS_TS                     =>  rec.RECORD_DATE,
                p_ACT_OWNER                         =>  rec.MODIFIED_NAME,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  NULL,
                p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                p_ACT_DCN                           =>  rec.DCN,
                p_ACT_REF_ID                        =>  rec.ENROLLMENT_ID,
                p_ACT_REF_TYPE                      =>  l_act_ref_type,
                p_ACT_STEP_DEFINITION_ID            =>  16,
                p_ACT_PROCESS_ID                    =>  1,
                p_ACT_CREATED_BY                    =>  rec.MODIFIED_NAME,
                p_ACT_CREATE_TS                     =>  rec.RECORD_DATE,                        
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );

            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_completed,
                p_ACT_STATUS_TS                     =>  rec.DATE_TIMED_OUT,
                p_ACT_OWNER                         =>  rec.MODIFIED_NAME,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  NULL,
                p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                p_ACT_DCN                           =>  rec.DCN,
                p_ACT_REF_ID                        =>  rec.ENROLLMENT_ID,
                p_ACT_REF_TYPE                      =>  l_act_ref_type,
                p_ACT_STEP_DEFINITION_ID            =>  16,
                p_ACT_PROCESS_ID                    =>  1,
                p_ACT_CREATED_BY                    =>  rec.MODIFIED_NAME,
                p_ACT_CREATE_TS                     =>  rec.RECORD_DATE,                                                
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );
        
        END IF;
    
    END         cr_enrollment_activities;
   /*****************************************************************************************************************************************************************

        NAME:           proc_emrs_f_enrollment
        DESCRIPTION:    Process the records in the table EMRS_F_ENROLLMENT.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    PROCEDURE   proc_emrs_f_enrollment
    IS
           
        l_mw_enrollment_proc_dt                                                 DATE;
        
    BEGIN

        IF  CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_string(p_NAME  =>  'MW_PROC_CONTROL')  =   'STOP'
        THEN
            RETURN;
        END IF;

        FOR rec IN c_emrs_f_enrollment
        LOOP

            IF  CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_string(p_NAME  =>  'MW_PROC_CONTROL')  =   'STOP'
            THEN
                RETURN;
            END IF;
        
            IF  l_mw_enrollment_proc_dt IS NULL
            THEN
                l_mw_enrollment_proc_dt    :=  rec.modified_date;
            ELSIF       rec.modified_date   >   l_mw_enrollment_proc_dt
                    AND rec.modified_date   <=  SYSDATE
            THEN
                l_mw_enrollment_proc_dt    :=  rec.modified_date;  
            END IF;

            cr_enrollment_activities
            (
                p_enrollment_rec                    =>  rec
            );
                            
            COMMIT;
                    
        END LOOP;

        CAHCO_ETL_MW_UTIL_PKG.set_corp_etl_control_date
        (
            p_NAME                              =>  'MW_ENROLLMENT_PROC_DATE',
            p_DATE                              =>  l_mw_enrollment_proc_dt
        );
        
    END         proc_emrs_f_enrollment;    
    /*****************************************************************************************************************************************************************

        NAME:           cr_return_mail_activities
        DESCRIPTION:    Create Return Mail activities from the Return Mail record, p_return_mail_rec.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    PROCEDURE   cr_return_mail_activities
                (
                    p_return_mail_rec                   IN                      c_proc_return_mail%ROWTYPE
                )
    IS          
        rec                                                                     c_proc_return_mail%ROWTYPE;        
    BEGIN

        rec :=  p_return_mail_rec;

        ins_hco_activity_queue
        (
            p_ACT_STATUS                        =>  c_claimed,
            p_ACT_STATUS_TS                     =>  rec.addr_bad_date,
            p_ACT_OWNER                         =>  rec.c_modified_name,
            p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
            p_ACT_CASE_ID                       =>  rec.case_number,
            p_ACT_CLIENT_ID                     =>  rec.clnt_client_id,
            p_ACT_DCN                           =>  rec.dcn,
            p_ACT_REF_ID                        =>  rec.case_number,
            p_ACT_REF_TYPE                      =>  c_return_mail_case,
            p_ACT_STEP_DEFINITION_ID            =>  10,
            p_ACT_PROCESS_ID                    =>  1,
            p_ACT_CREATED_BY                    =>  rec.c_modified_name,
            p_ACT_CREATE_TS                     =>  rec.addr_bad_date,                
            p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
        );

        ins_hco_activity_queue
        (
            p_ACT_STATUS                        =>  c_completed,
            p_ACT_STATUS_TS                     =>  rec.addr_bad_date,
            p_ACT_OWNER                         =>  rec.c_modified_name,
            p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
            p_ACT_CASE_ID                       =>  rec.case_number,
            p_ACT_CLIENT_ID                     =>  rec.clnt_client_id,
            p_ACT_DCN                           =>  rec.dcn,
            p_ACT_REF_ID                        =>  rec.case_number,
            p_ACT_REF_TYPE                      =>  c_return_mail_case,
            p_ACT_STEP_DEFINITION_ID            =>  10,
            p_ACT_PROCESS_ID                    =>  1,
            p_ACT_CREATED_BY                    =>  rec.c_modified_name,
            p_ACT_CREATE_TS                     =>  rec.addr_bad_date,                                
            p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
        );
        
        IF      rec.obt_modified_date IS NOT NULL
        THEN

            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_claimed,
                p_ACT_STATUS_TS                     =>  rec.addr_bad_date,
                p_ACT_OWNER                         =>  c_automated_process,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  rec.case_number,
                p_ACT_CLIENT_ID                     =>  rec.clnt_client_id,
                p_ACT_DCN                           =>  rec.dcn,
                p_ACT_REF_ID                        =>  rec.case_number,
                p_ACT_REF_TYPE                      =>  c_return_mail_case,
                p_ACT_STEP_DEFINITION_ID            =>  11,
                p_ACT_PROCESS_ID                    =>  1,
                p_ACT_CREATED_BY                    =>  c_automated_process,
                p_ACT_CREATE_TS                     =>  rec.addr_bad_date,                    
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );

            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_completed,
                p_ACT_STATUS_TS                     =>  rec.obt_modified_date,
                p_ACT_OWNER                         =>  c_automated_process,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  rec.case_number,
                p_ACT_CLIENT_ID                     =>  rec.clnt_client_id,
                p_ACT_DCN                           =>  rec.dcn,
                p_ACT_REF_ID                        =>  rec.case_number,
                p_ACT_REF_TYPE                      =>  c_return_mail_case,
                p_ACT_STEP_DEFINITION_ID            =>  11,
                p_ACT_PROCESS_ID                    =>  1,
                p_ACT_CREATED_BY                    =>  c_automated_process,
                p_ACT_CREATE_TS                     =>  rec.addr_bad_date,                                        
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );

        END IF;
                            
        COMMIT;
            
    END         cr_return_mail_activities;
   /*****************************************************************************************************************************************************************

        NAME:           proc_return_mail
        DESCRIPTION:    Process the records in the table EMRS_D_CASE that indicate addresses were bad.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    PROCEDURE   proc_return_mail
    IS
    
        l_mw_return_mail_proc_dt                                                DATE;
        l_temp_date                                                             DATE;
                
    BEGIN

        IF  CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_string(p_NAME  =>  'MW_PROC_CONTROL')  =   'STOP'
        THEN
            RETURN;
        END IF;

        FOR rec IN c_proc_return_mail
        LOOP
        
            IF  CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_string(p_NAME  =>  'MW_PROC_CONTROL')  =   'STOP'
            THEN
                RETURN;
            END IF;

            IF  l_mw_return_mail_proc_dt IS NULL
            THEN
                l_mw_return_mail_proc_dt    :=  rec.c_modified_date;
            ELSE       
                
                l_temp_date :=  GREATEST(l_mw_return_mail_proc_dt, rec.c_modified_date, NVL(rec.obt_modified_date, l_mw_return_mail_proc_dt));
            
                IF      l_temp_date >   l_mw_return_mail_proc_dt 
                    AND l_temp_date <=  SYSDATE
                THEN
                    l_mw_return_mail_proc_dt    :=  l_temp_date;
                END IF;

            END IF;

            cr_return_mail_activities
            (
                p_return_mail_rec                   =>  rec
            );
                    
        END LOOP;

        CAHCO_ETL_MW_UTIL_PKG.set_corp_etl_control_date
        (
            p_NAME                              =>  'MW_RETURN_MAIL_PROC_DATE',
            p_DATE                              =>  l_mw_return_mail_proc_dt
        );
        
    END         proc_return_mail;   
    /*****************************************************************************************************************************************************************

        NAME:           cr_letter_mailing_activities
        DESCRIPTION:    Create Letter Mailing activities from the Letter Mailing record, p_letter_mailing_rec.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    PROCEDURE   cr_letter_mailing_activities
                (
                    p_letter_mailing_rec                IN                      c_hco_d_letter_mailing%ROWTYPE
                )
    IS          

        l_mail_transaction_date                                                 HCO_MAIL_CLIENT_TRANS.mt_modified_date%TYPE;
        l_mail_response_letter_date                                             HCO_MAIL_CLIENT_TRANS.mail_response_letter_date%TYPE;
        l_vendor_received_date                                                  HCO_D_LETTER_MAILING.vendor_received_date%TYPE;
        l_date_mailed                                                           HCO_D_LETTER_MAILING.date_mailed%TYPE;

        rec                                                                     c_hco_d_letter_mailing%ROWTYPE;        

    BEGIN

        rec :=  p_letter_mailing_rec;

        l_mail_transaction_date             :=  rec.mail_transaction_date;
        l_mail_response_letter_date         :=  rec.mail_response_letter_date;
        l_vendor_received_date              :=  rec.vendor_received_date;
        l_date_mailed                       :=  rec.date_mailed;

        IF  l_mail_transaction_date IS NOT NULL
        THEN        

            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_claimed,
                p_ACT_STATUS_TS                     =>  l_mail_transaction_date,
                p_ACT_OWNER                         =>  c_automated_process,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  rec.CASE_NUMBER,
                p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                p_ACT_DCN                           =>  rec.DCN,
                p_ACT_REF_ID                        =>  rec.DIM_LETTER_MAILING_ID,
                p_ACT_REF_TYPE                      =>  c_letter_mailing,
                p_ACT_STEP_DEFINITION_ID            =>  20,
                p_ACT_PROCESS_ID                    =>  2,
                p_ACT_CREATED_BY                    =>  c_automated_process,
                p_ACT_CREATE_TS                     =>  l_mail_transaction_date,
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );
            
            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_completed,
                p_ACT_STATUS_TS                     =>  l_mail_transaction_date,
                p_ACT_OWNER                         =>  c_automated_process,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  rec.CASE_NUMBER,
                p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                p_ACT_DCN                           =>  rec.DCN,
                p_ACT_REF_ID                        =>  rec.DIM_LETTER_MAILING_ID,
                p_ACT_REF_TYPE                      =>  c_letter_mailing,
                p_ACT_STEP_DEFINITION_ID            =>  20,
                p_ACT_PROCESS_ID                    =>  2,
                p_ACT_CREATED_BY                    =>  c_automated_process,
                p_ACT_CREATE_TS                     =>  l_mail_transaction_date,
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );

            COMMIT;

        END IF;                

        IF  l_mail_response_letter_date IS NOT NULL
        THEN        

            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_claimed,
                p_ACT_STATUS_TS                     =>  l_mail_response_letter_date,
                p_ACT_OWNER                         =>  c_automated_process,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  rec.CASE_NUMBER,
                p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                p_ACT_DCN                           =>  rec.DCN,
                p_ACT_REF_ID                        =>  rec.DIM_LETTER_MAILING_ID,
                p_ACT_REF_TYPE                      =>  c_letter_mailing,
                p_ACT_STEP_DEFINITION_ID            =>  21,
                p_ACT_PROCESS_ID                    =>  2,
                p_ACT_CREATED_BY                    =>  c_automated_process,
                p_ACT_CREATE_TS                     =>  l_mail_response_letter_date,
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );
            
            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_completed,
                p_ACT_STATUS_TS                     =>  l_mail_response_letter_date,
                p_ACT_OWNER                         =>  c_automated_process,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  rec.CASE_NUMBER,
                p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                p_ACT_DCN                           =>  rec.DCN,
                p_ACT_REF_ID                        =>  rec.DIM_LETTER_MAILING_ID,
                p_ACT_REF_TYPE                      =>  c_letter_mailing,
                p_ACT_STEP_DEFINITION_ID            =>  21,
                p_ACT_PROCESS_ID                    =>  2,
                p_ACT_CREATED_BY                    =>  c_automated_process,
                p_ACT_CREATE_TS                     =>  l_mail_response_letter_date,
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );

            COMMIT;

        END IF;                

        IF  l_vendor_received_date  IS NOT NULL
        THEN        

            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_claimed,
                p_ACT_STATUS_TS                     =>  l_vendor_received_date ,
                p_ACT_OWNER                         =>  c_automated_process,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  rec.CASE_NUMBER,
                p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                p_ACT_DCN                           =>  rec.DCN,
                p_ACT_REF_ID                        =>  rec.DIM_LETTER_MAILING_ID,
                p_ACT_REF_TYPE                      =>  c_letter_mailing,
                p_ACT_STEP_DEFINITION_ID            =>  22,
                p_ACT_PROCESS_ID                    =>  2,
                p_ACT_CREATED_BY                    =>  c_automated_process,
                p_ACT_CREATE_TS                     =>  l_vendor_received_date ,
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );
            
            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_completed,
                p_ACT_STATUS_TS                     =>  l_vendor_received_date ,
                p_ACT_OWNER                         =>  c_automated_process,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  rec.CASE_NUMBER,
                p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                p_ACT_DCN                           =>  rec.DCN,
                p_ACT_REF_ID                        =>  rec.DIM_LETTER_MAILING_ID,
                p_ACT_REF_TYPE                      =>  c_letter_mailing,
                p_ACT_STEP_DEFINITION_ID            =>  22,
                p_ACT_PROCESS_ID                    =>  2,
                p_ACT_CREATED_BY                    =>  c_automated_process,
                p_ACT_CREATE_TS                     =>  l_vendor_received_date ,
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );

            COMMIT;

        END IF;                

        IF  l_date_mailed  IS NOT NULL
        THEN        

            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_claimed,
                p_ACT_STATUS_TS                     =>  l_date_mailed,
                p_ACT_OWNER                         =>  c_automated_process,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  rec.CASE_NUMBER,
                p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                p_ACT_DCN                           =>  rec.DCN,
                p_ACT_REF_ID                        =>  rec.DIM_LETTER_MAILING_ID,
                p_ACT_REF_TYPE                      =>  c_letter_mailing,
                p_ACT_STEP_DEFINITION_ID            =>  23,
                p_ACT_PROCESS_ID                    =>  2,
                p_ACT_CREATED_BY                    =>  c_automated_process,
                p_ACT_CREATE_TS                     =>  l_date_mailed,
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );
            
            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_completed,
                p_ACT_STATUS_TS                     =>  l_date_mailed,
                p_ACT_OWNER                         =>  c_automated_process,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  rec.CASE_NUMBER,
                p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                p_ACT_DCN                           =>  rec.DCN,
                p_ACT_REF_ID                        =>  rec.DIM_LETTER_MAILING_ID,
                p_ACT_REF_TYPE                      =>  c_letter_mailing,
                p_ACT_STEP_DEFINITION_ID            =>  23,
                p_ACT_PROCESS_ID                    =>  2,
                p_ACT_CREATED_BY                    =>  c_automated_process,
                p_ACT_CREATE_TS                     =>  l_date_mailed,
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );

            COMMIT;

        END IF;                
            
    END         cr_letter_mailing_activities;
    /*****************************************************************************************************************************************************************

        NAME:           proc_hco_d_letter_mailing
        DESCRIPTION:    Process the records in the table HCO_D_LETTER_MAILING.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    PROCEDURE   proc_hco_d_letter_mailing
    IS
        
        l_mw_letter_mailing_proc_dt                                             DATE;
                
    BEGIN

        IF  CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_string(p_NAME  =>  'MW_PROC_CONTROL')  =   'STOP'
        THEN
            RETURN;
        END IF;

        FOR rec IN  c_hco_d_letter_mailing   
        LOOP

            IF  CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_string(p_NAME  =>  'MW_PROC_CONTROL')  =   'STOP'
            THEN
                RETURN;
            END IF;
        
            IF  l_mw_letter_mailing_proc_dt   IS NULL
            THEN
                l_mw_letter_mailing_proc_dt      :=  rec.modified_date;
            ELSIF       rec.modified_date   >   l_mw_letter_mailing_proc_dt  
                    AND rec.modified_date   <=  SYSDATE
            THEN
                l_mw_letter_mailing_proc_dt      :=  rec.modified_date;  
            END IF;

            cr_letter_mailing_activities
            (
                p_letter_mailing_rec                =>  rec
            );

            COMMIT;

        END LOOP;
        
        CAHCO_ETL_MW_UTIL_PKG.set_corp_etl_control_date
        (
            p_NAME                              =>  'MW_LETTER_MAILING_PROC_DATE',
            p_DATE                              =>  l_mw_letter_mailing_proc_dt 
        );

    END         proc_hco_d_letter_mailing;
    /*****************************************************************************************************************************************************************

        NAME:           cr_packet_mailing_activities
        DESCRIPTION:    Create Packet Mailing activities from the Packet Mailing record, p_packet_mailing_rec.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    PROCEDURE   cr_packet_mailing_activities
                (
                    p_packet_mailing_rec                IN                      c_hco_d_packet_mailing%ROWTYPE
                )
    IS          

        l_mail_transaction_date                                                 HCO_MAIL_CLIENT_TRANS.mt_modified_date%TYPE;
        l_mail_response_packet_date                                             HCO_MAIL_CLIENT_TRANS.mail_response_letter_date%TYPE;
        l_vendor_received_date                                                  HCO_D_PACKET_MAILING.vendor_received_date%TYPE;
        l_date_mailed                                                           HCO_D_PACKET_MAILING.date_mailed%TYPE;

        rec                                                                     c_hco_d_packet_mailing%ROWTYPE;        

    BEGIN

        rec :=  p_packet_mailing_rec;

        l_mail_transaction_date             :=  rec.mail_transaction_date;
        l_mail_response_packet_date         :=  rec.mail_response_packet_date;
        l_vendor_received_date              :=  rec.vendor_received_date;
        l_date_mailed                       :=  rec.date_mailed;

        IF  l_mail_transaction_date IS NOT NULL
        THEN        

            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_claimed,
                p_ACT_STATUS_TS                     =>  l_mail_transaction_date,
                p_ACT_OWNER                         =>  c_automated_process,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  rec.CASE_NUMBER,
                p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                p_ACT_DCN                           =>  rec.DCN,
                p_ACT_REF_ID                        =>  rec.DIM_PACKET_MAILING_ID,
                p_ACT_REF_TYPE                      =>  c_packet_mailing,
                p_ACT_STEP_DEFINITION_ID            =>  20,
                p_ACT_PROCESS_ID                    =>  2,
                p_ACT_CREATED_BY                    =>  c_automated_process,
                p_ACT_CREATE_TS                     =>  l_mail_transaction_date,
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );
            
            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_completed,
                p_ACT_STATUS_TS                     =>  l_mail_transaction_date,
                p_ACT_OWNER                         =>  c_automated_process,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  rec.CASE_NUMBER,
                p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                p_ACT_DCN                           =>  rec.DCN,
                p_ACT_REF_ID                        =>  rec.DIM_PACKET_MAILING_ID,
                p_ACT_REF_TYPE                      =>  c_packet_mailing,
                p_ACT_STEP_DEFINITION_ID            =>  20,
                p_ACT_PROCESS_ID                    =>  2,
                p_ACT_CREATED_BY                    =>  c_automated_process,
                p_ACT_CREATE_TS                     =>  l_mail_transaction_date,
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );

            COMMIT;

        END IF;                

        IF  l_mail_response_packet_date IS NOT NULL
        THEN        

            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_claimed,
                p_ACT_STATUS_TS                     =>  l_mail_response_packet_date,
                p_ACT_OWNER                         =>  c_automated_process,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  rec.CASE_NUMBER,
                p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                p_ACT_DCN                           =>  rec.DCN,
                p_ACT_REF_ID                        =>  rec.DIM_PACKET_MAILING_ID,
                p_ACT_REF_TYPE                      =>  c_packet_mailing,
                p_ACT_STEP_DEFINITION_ID            =>  21,
                p_ACT_PROCESS_ID                    =>  2,
                p_ACT_CREATED_BY                    =>  c_automated_process,
                p_ACT_CREATE_TS                     =>  l_mail_response_packet_date,
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );
            
            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_completed,
                p_ACT_STATUS_TS                     =>  l_mail_response_packet_date,
                p_ACT_OWNER                         =>  c_automated_process,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  rec.CASE_NUMBER,
                p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                p_ACT_DCN                           =>  rec.DCN,
                p_ACT_REF_ID                        =>  rec.DIM_PACKET_MAILING_ID,
                p_ACT_REF_TYPE                      =>  c_packet_mailing,
                p_ACT_STEP_DEFINITION_ID            =>  21,
                p_ACT_PROCESS_ID                    =>  2,
                p_ACT_CREATED_BY                    =>  c_automated_process,
                p_ACT_CREATE_TS                     =>  l_mail_response_packet_date,
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );

            COMMIT;

        END IF;                

        IF  l_vendor_received_date  IS NOT NULL
        THEN        

            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_claimed,
                p_ACT_STATUS_TS                     =>  l_vendor_received_date ,
                p_ACT_OWNER                         =>  c_automated_process,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  rec.CASE_NUMBER,
                p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                p_ACT_DCN                           =>  rec.DCN,
                p_ACT_REF_ID                        =>  rec.DIM_PACKET_MAILING_ID,
                p_ACT_REF_TYPE                      =>  c_packet_mailing,
                p_ACT_STEP_DEFINITION_ID            =>  22,
                p_ACT_PROCESS_ID                    =>  2,
                p_ACT_CREATED_BY                    =>  c_automated_process,
                p_ACT_CREATE_TS                     =>  l_vendor_received_date ,
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );
            
            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_completed,
                p_ACT_STATUS_TS                     =>  l_vendor_received_date ,
                p_ACT_OWNER                         =>  c_automated_process,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  rec.CASE_NUMBER,
                p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                p_ACT_DCN                           =>  rec.DCN,
                p_ACT_REF_ID                        =>  rec.DIM_PACKET_MAILING_ID,
                p_ACT_REF_TYPE                      =>  c_packet_mailing,
                p_ACT_STEP_DEFINITION_ID            =>  22,
                p_ACT_PROCESS_ID                    =>  2,
                p_ACT_CREATED_BY                    =>  c_automated_process,
                p_ACT_CREATE_TS                     =>  l_vendor_received_date ,
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );

            COMMIT;

        END IF;                

        IF  l_date_mailed  IS NOT NULL
        THEN        

            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_claimed,
                p_ACT_STATUS_TS                     =>  l_date_mailed,
                p_ACT_OWNER                         =>  c_automated_process,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  rec.CASE_NUMBER,
                p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                p_ACT_DCN                           =>  rec.DCN,
                p_ACT_REF_ID                        =>  rec.DIM_PACKET_MAILING_ID,
                p_ACT_REF_TYPE                      =>  c_packet_mailing,
                p_ACT_STEP_DEFINITION_ID            =>  23,
                p_ACT_PROCESS_ID                    =>  2,
                p_ACT_CREATED_BY                    =>  c_automated_process,
                p_ACT_CREATE_TS                     =>  l_date_mailed,
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );
            
            ins_hco_activity_queue
            (
                p_ACT_STATUS                        =>  c_completed,
                p_ACT_STATUS_TS                     =>  l_date_mailed,
                p_ACT_OWNER                         =>  c_automated_process,
                p_ACT_TEAM_ID                       =>  CAHCO_ETL_MW_UTIL_PKG.get_unknown_team_id,
                p_ACT_CASE_ID                       =>  rec.CASE_NUMBER,
                p_ACT_CLIENT_ID                     =>  rec.CLIENT_NUMBER,
                p_ACT_DCN                           =>  rec.DCN,
                p_ACT_REF_ID                        =>  rec.DIM_PACKET_MAILING_ID,
                p_ACT_REF_TYPE                      =>  c_packet_mailing,
                p_ACT_STEP_DEFINITION_ID            =>  23,
                p_ACT_PROCESS_ID                    =>  2,
                p_ACT_CREATED_BY                    =>  c_automated_process,
                p_ACT_CREATE_TS                     =>  l_date_mailed,
                p_ACT_COMMENTS                      =>  CAHCO_ETL_MW_UTIL_PKG.automatically_claimed
            );

            COMMIT;

        END IF;                
            
    END         cr_packet_mailing_activities;
    /*****************************************************************************************************************************************************************

        NAME:           proc_hco_d_packet_mailing
        DESCRIPTION:    Process the records in the table HCO_D_PACKET_MAILING.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    PROCEDURE   proc_hco_d_packet_mailing
    IS
        
        l_mw_packet_mailing_proc_dt                                             DATE;
                
    BEGIN

        IF  CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_string(p_NAME  =>  'MW_PROC_CONTROL')  =   'STOP'
        THEN
            RETURN;
        END IF;

        FOR rec IN  c_hco_d_packet_mailing   
        LOOP

            IF  CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_string(p_NAME  =>  'MW_PROC_CONTROL')  =   'STOP'
            THEN
                RETURN;
            END IF;
        
            IF  l_mw_packet_mailing_proc_dt   IS NULL
            THEN
                l_mw_packet_mailing_proc_dt      :=  rec.modified_date;
            ELSIF       rec.modified_date   >   l_mw_packet_mailing_proc_dt  
                    AND rec.modified_date   <=  SYSDATE
            THEN
                l_mw_packet_mailing_proc_dt      :=  rec.modified_date;  
            END IF;

            cr_packet_mailing_activities
            (
                p_packet_mailing_rec                =>  rec
            );

            COMMIT;

        END LOOP;
        
        CAHCO_ETL_MW_UTIL_PKG.set_corp_etl_control_date
        (
            p_NAME                              =>  'MW_PACKET_MAILING_PROC_DATE',
            p_DATE                              =>  l_mw_packet_mailing_proc_dt 
        );

    END         proc_hco_d_packet_mailing;    
    /*****************************************************************************************************************************************************************

        NAME:           ins_step_instance_stg
        DESCRIPTION:    Insert recprds from STEP_INSTANCE, STEP_INSTANCE_HISTORY into the table STEP_INSTANCE_STG.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     10/19/2018              Created procedure.

    *****************************************************************************************************************************************************************/
    PROCEDURE   ins_step_instance_stg
    IS
        CURSOR  c_step_instance
        IS
        SELECT  si.step_instance_id,
                si.status,
                si.create_ts,
                si.completed_ts, 
                sh.escalated_ind,
                si.step_due_ts,
                sh.forwarded_ind,
                sh.group_id,
                sh.team_id,
                si.ref_id,
                si.ref_type,
                si.step_definition_id,
                si.created_by,
                sh.escalate_to,
                sh.forwarded_by,
                sh.owner,
                si.suspended_ts,
                sh.step_instance_history_id,
                sh.status                        HIST_STATUS,
                sh.create_ts                     HIST_CREATE_TS,
                sh.created_by                    HIST_CREATE_BY,
                'N'                              MW_PROCESSED,
                'N'                              MIB_PROCESSED,
                SYSDATE                          STAGE_CREATE_TS,
                si.case_id,
                si.client_id,
                si.priority_cd                   PRIORITY,
                si.process_id,
                si.process_instance_id,
                si.claimed_ts
        FROM    STEP_INSTANCE                   si,  
                STEP_INSTANCE_HISTORY           sh,  
                STEP_DEFINITION                 sd  
       WHERE    SH.STEP_INSTANCE_ID         =   SI.STEP_INSTANCE_ID
         AND    si.step_definition_id = sd.step_definition_id(+)
         AND    sd.step_type_cd in ('VIRTUAL_HUMAN_TASK','HUMAN_TASK')
         AND    SH.STEP_INSTANCE_HISTORY_ID >   GREATEST
                                                (
                                                    CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_number
                                                    (
                                                        p_NAME      =>  'MW_LAST_STEP_INST_HIST_ID'
                                                    ),
                                                    (
                                                        SELECT  NVL(MAX(step_instance_history_id), 0)
                                                          FROM  STEP_INSTANCE_STG
                                                    )
                                                )
         AND    SH.STEP_INSTANCE_HISTORY_ID <=      CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_number
                                                    (
                                                        p_NAME      =>  'HIGH_LIMIT_TASK_HISTORY_ID'
                                                    );
        
    BEGIN

        IF  CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_string(p_NAME  =>  'MW_PROC_CONTROL')  =   'STOP'
        THEN
            RETURN;
        END IF;

        FOR rec IN c_step_instance
        LOOP
    
            IF  CAHCO_ETL_MW_UTIL_PKG.get_corp_etl_control_string(p_NAME  =>  'MW_PROC_CONTROL')  =   'STOP'
            THEN
                RETURN;
            END IF;

            INSERT
              INTO  STEP_INSTANCE_STG 
                    (
                        step_instance_id,
                        status,
                        create_ts,
                        completed_ts, 
                        escalated_ind,
                        step_due_ts,
                        forwarded_ind,
                        group_id,
                        team_id,
                        ref_id,
                        ref_type,
                        step_definition_id,
                        created_by,
                        escalate_to,
                        forwarded_by,
                        owner,
                        suspended_ts,
                        step_instance_history_id,
                        hist_status,
                        hist_create_ts,
                        hist_create_by,
                        mw_processed,
                        mib_processed,
                        stage_create_ts,
                        case_id,
                        client_id,
                        priority,
                        process_id,
                        process_instance_id,
                        claimed_ts
                    )
             VALUES (
                        rec.step_instance_id,
                        rec.status,
                        rec.create_ts,
                        rec.completed_ts, 
                        rec.escalated_ind,
                        rec.step_due_ts,
                        rec.forwarded_ind,
                        rec.group_id,
                        rec.team_id,
                        rec.ref_id,
                        rec.ref_type,
                        rec.step_definition_id,
                        rec.created_by,
                        rec.escalate_to,
                        rec.forwarded_by,
                        rec.owner,
                        rec.suspended_ts,
                        rec.step_instance_history_id,
                        rec.hist_status,
                        rec.hist_create_ts,
                        rec.hist_create_by,
                        rec.mw_processed,
                        rec.mib_processed,
                        rec.stage_create_ts,
                        rec.case_id,
                        rec.client_id,
                        rec.priority,
                        rec.process_id,
                        rec.process_instance_id,
                        rec.claimed_ts
                    );
    
            COMMIT;
        
        END LOOP;
        
    END         ins_step_instance_stg;
    /*****************************************************************************************************************************************************************

        NAME:           get_dcn_date
        DESCRIPTION:    Get the date from the DCN.
        
        WHO                     WHEN                    WHAT
        ===                     ====                    ====
        TAM                     01/29/2019              Created procedure.

    *****************************************************************************************************************************************************************/
    FUNCTION    get_dcn_date
                (
                    p_DCN                               IN                      D_HCO_PROCESS_INSTANCE.dcn%TYPE
                )
    RETURN                                                                      DATE
    IS
        l_dcn_date                                                              DATE;
    BEGIN
                
        BEGIN
        
            SELECT  TO_DATE(SUBSTR(p_DCN, 1, 5), 'YYDDD')
              INTO  l_dcn_date
              FROM  DUAL;

        EXCEPTION
        
            WHEN    OTHERS
            THEN    NULL;
                
        END;
    
        RETURN  l_dcn_date;
        
    END         get_dcn_date;
                
END CAHCO_ETL_MW_PKG;
/