  CREATE OR REPLACE FORCE EDITIONABLE VIEW D_BPM_ENTITY_INSTANCE_SV AS
  SELECT
    ENTITY_INSTANCE_ID
    , ei.ENTITY_ID
    , ei.ENTITY_TYPE_ID
    , ei.PROCESS_INSTANCE_ID
    , ei.ENTITY_NAME
    , ei.ENTITY_DESCRIPTION
    , ti.TASK_ID
    , ti.AGE_IN_BUSINESS_DAYS     
    , ei.START_DATE
    , ei.COMPLETE_DATE
    , ei.TIMELINESS_STATUS
    , NVL(ei.complete_date, SYSDATE) - pi.process_start_date        AS  CYCLE_TIME
    , ei.IS_ACTIVE
    , ei.IS_STARTING_ENTITY
    , ei.IS_TERMINATING_ENTITY
FROM  D_BPM_ENTITY_INSTANCE                     ei,
      D_MW_TASK_INSTANCE                        ti,
      D_BPM_PROCESS_INSTANCE                    pi
WHERE ei.entity_instance_id                 =   ti.task_id  
  AND ei.process_instance_id                =   pi.process_instance_id
WITH read only;

GRANT SELECT ON D_BPM_ENTITY_INSTANCE_SV TO MAXDAT_READ_ONLY;
GRANT SELECT, INSERT, UPDATE ON D_BPM_ENTITY_INSTANCE_SV TO MAXDAT_OLTP_SIU;
GRANT SELECT, INSERT, UPDATE, DELETE ON D_BPM_ENTITY_INSTANCE_SV TO MAXDAT_OLTP_SIUD;