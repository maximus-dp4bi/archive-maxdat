CREATE OR REPLACE FORCE EDITIONABLE VIEW D_HCO_TASK_INSTANCE_SV AS
SELECT  mw_ti.*,
        mw_ti.task_type_id                                  AS  ACTIVITY_ID,
        pi.process_start_date,
        hco_pi.dcn,
        CAHCO_ETL_MW_PKG.get_dcn_date(p_DCN => hco_pi.dcn)  AS DOCUMENT_RECEIVED_DATE
  FROM  D_MW_TASK_INSTANCE_SV                       mw_ti,
        D_BPM_PROCESS_INSTANCE                      pi,
        D_HCO_PROCESS_INSTANCE                      hco_pi
 WHERE  mw_ti.source_process_instance_id        =   pi.process_instance_id
   AND  mw_ti.source_process_instance_id        =   hco_pi.hco_process_instance_id
WITH READ ONLY;

GRANT SELECT ON D_HCO_TASK_INSTANCE_SV TO MAXDAT_READ_ONLY;
GRANT SELECT, INSERT, UPDATE ON D_HCO_TASK_INSTANCE_SV TO MAXDAT_OLTP_SIU;
GRANT SELECT, INSERT, UPDATE, DELETE ON D_HCO_TASK_INSTANCE_SV TO MAXDAT_OLTP_SIUD;