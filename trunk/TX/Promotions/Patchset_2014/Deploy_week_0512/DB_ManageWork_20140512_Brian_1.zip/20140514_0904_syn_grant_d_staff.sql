create or replace public synonym D_STAFF for D_STAFF;
grant select on D_STAFF to MAXDAT_READ_ONLY;
