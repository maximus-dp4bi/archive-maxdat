#! /bin/ksh
#Cron file to Contact Center
# Do not edit these four SVN_* variable values.  They are populated when you commit code to SVN
#     and used later to identify deployed code.
# $URL: svn://rcmxapp1d.maximus.com/maxdat/trunk/TX/cron_files/cron_tx_run_contcent.sh $
# $Revision: 11819 $
# $Date: 2014-09-05 17:04:44 -0400 (Fri, 05 Sep 2014) $
# $Author: sk51922 $
. ~/.profile

 $MAXDAT_ETL_PATH/ContactCenter/implementation/TXEB/bin/manage_scheduled_contact_center_jobs.sh  >> $MAXDAT_ETL_LOGS/tx_run_bpm.cron.log &

