#! /bin/ksh
#Cron file to Contact Center
# Do not edit these four SVN_* variable values.  They are populated when you commit code to SVN
#     and used later to identify deployed code.
# $URL: svn://rcmxapp1d.maximus.com/maxdat/trunk/TX/cron_files/cron_tx_run_contcent.sh $
# $Revision: 11101 $
# $Date: 2014-07-24 16:49:32 -0400 (Thu, 24 Jul 2014) $
# $Author: sk51922 $
. /tpxe4t/3rdparty/.profile

 /ptxe4t/ETL_Scripts/scripts/ContactCenter/implementation/TXEB/bin/manage_scheduled_contact_center_jobs.sh  >> $MAXDAT_ETL_LOGS/tx_run_bpm.cron.log &

