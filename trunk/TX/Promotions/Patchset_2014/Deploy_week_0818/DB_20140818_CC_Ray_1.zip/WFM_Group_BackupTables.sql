--Create Backups
CREATE TABLE cc_c_contact_queue_backup
AS
SELECT *
  FROM cc_c_contact_queue;

CREATE OR REPLACE PUBLIC SYNONYM cc_c_contact_queue_backup for cc_c_contact_queue_backup;
  
CREATE TABLE cc_c_unit_of_work_backup
AS
SELECT *
  FROM cc_c_unit_of_work;  

CREATE OR REPLACE PUBLIC SYNONYM cc_c_unit_of_work_backup for cc_c_unit_of_work_backup;
  
CREATE TABLE cc_d_unit_of_work_backup
AS
SELECT *
  FROM cc_d_unit_of_work;

 CREATE OR REPLACE PUBLIC SYNONYM cc_d_unit_of_work_backup for cc_d_unit_of_work_backup;

  
CREATE TABLE cc_d_contact_queue_backup
AS
SELECT *
  FROM cc_d_contact_queue;  

CREATE OR REPLACE PUBLIC SYNONYM cc_d_contact_queue_backup for cc_d_contact_queue_backup;  

  
CREATE TABLE cc_f_actuals_queue_intrvl_bkup
AS
SELECT *
  FROM cc_f_actuals_queue_interval; 

CREATE OR REPLACE PUBLIC SYNONYM cc_f_actuals_queue_intrvl_bkup for cc_f_actuals_queue_intrvl_bkup;    
  
CREATE TABLE cc_s_contact_queue_backup
AS
SELECT *
  FROM cc_s_contact_queue;  

CREATE OR REPLACE PUBLIC SYNONYM cc_s_contact_queue_backup for cc_s_contact_queue_backup;    
  
CREATE TABLE cc_s_fcst_interval_backup
AS
SELECT *
  FROM cc_s_fcst_interval;

CREATE OR REPLACE PUBLIC SYNONYM cc_s_fcst_interval_backup for cc_s_fcst_interval_backup;    
  
commit;

/  
