/*--Create Backups
CREATE TABLE cc_c_contact_queue_backup
AS
SELECT *
  FROM cc_c_contact_queue;
  
CREATE TABLE cc_c_unit_of_work_backup
AS
SELECT *
  FROM cc_c_unit_of_work;  
  
CREATE TABLE cc_d_unit_of_work_backup
AS
SELECT *
  FROM cc_d_unit_of_work;
  
CREATE TABLE cc_d_contact_queue_backup
AS
SELECT *
  FROM cc_d_contact_queue;  
  
CREATE TABLE cc_f_actuals_queue_intrvl_bkup
AS
SELECT *
  FROM cc_f_actuals_queue_interval; 
  
CREATE TABLE cc_s_contact_queue_backup
AS
SELECT *
  FROM cc_s_contact_queue;  
  
CREATE TABLE cc_s_fcst_interval_backup
AS
SELECT *
  FROM cc_s_fcst_interval;  */  

--Create WFM Group
create table CC_C_CONTACT_QUEUE_WFM_GROUP
(
  C_CONTACT_QUEUE_ID             NUMBER(19) not null,
  WFM_GROUP_NAME                 VARCHAR2(50) not null,  
  CREATE_DATE                    DATE DEFAULT SYSDATE not null,
  LAST_MODIFIED_DATE             DATE DEFAULT SYSDATE  not null
);
alter table CC_C_CONTACT_QUEUE_WFM_GROUP
  add constraint CC_C_CONTACT_Q_WFM_GROUP_PK primary key (C_CONTACT_QUEUE_ID, WFM_GROUP_NAME);
  
CREATE OR REPLACE TRIGGER BIU_cc_c_c_queue_wfm_group 
    BEFORE INSERT OR UPDATE ON cc_c_contact_queue_wfm_group 
    FOR EACH ROW 
    ENABLE 
BEGIN 
IF INSERTING THEN 
          :NEW.CREATE_DATE := SYSDATE;
END IF;
:NEW.LAST_MODIFIED_DATE := SYSDATE;
END; 
/

create table CC_D_CONTACT_QUEUE_WFM_GROUP
(
  D_CONTACT_QUEUE_ID             NUMBER(19) not null,
  WFM_GROUP_NAME                 VARCHAR2(50) not null,  
  CREATE_DATE                    DATE DEFAULT SYSDATE not null,
  LAST_MODIFIED_DATE             DATE DEFAULT SYSDATE  not null
);
alter table CC_D_CONTACT_QUEUE_WFM_GROUP
  add constraint CC_D_CONTACT_Q_WFM_GROUP_PK primary key (D_CONTACT_QUEUE_ID, WFM_GROUP_NAME);
  
CREATE OR REPLACE TRIGGER BIU_cc_d_c_queue_wfm_group 
    BEFORE INSERT OR UPDATE ON cc_d_contact_queue_wfm_group 
    FOR EACH ROW 
    ENABLE 
BEGIN 
IF INSERTING THEN 
          :NEW.CREATE_DATE := SYSDATE;
END IF;
:NEW.LAST_MODIFIED_DATE := SYSDATE;
END; 
/


--Clean up duplicate contact queues
delete from cc_c_contact_queue
where queue_number in (6978,6979)
and unit_of_work_name in ('EB FREW ENG', 'EB FREW SPN')
;

--Populate WFM Group w/old UOW records
Insert into cc_c_contact_queue_wfm_group
  select cq.c_contact_queue_id, uow.unit_of_work_name, sysdate, sysdate
    from cc_c_unit_of_work_backup uow
   right join cc_c_contact_queue_backup cq
      on cq.unit_of_work_name = uow.unit_of_work_name;
      
Insert into cc_d_contact_queue_wfm_group      
select x.d_contact_queue_id, x.unit_of_work_name, sysdate, sysdate
  from cc_d_unit_of_work_backup duow
 inner join cc_c_unit_of_work_backup cuow
    on cuow.unit_of_work_name = duow.unit_of_work_name
 inner join (select dcq.d_contact_queue_id,
                    dcq.queue_number,
                    dcq.queue_name,
                    ccq.unit_of_work_name
               from cc_d_contact_queue_backup dcq
              inner join cc_c_contact_queue_backup ccq
                 on ccq.queue_number = dcq.queue_number) x
    on x.unit_of_work_name = duow.unit_of_work_name;      
      
--Update C UOW      
update cc_c_unit_of_work set record_end_dt = trunc(sysdate-1) where unit_of_work_name <> 'N/A';

insert into cc_c_unit_of_work (UNIT_OF_WORK_ID, UNIT_OF_WORK_NAME, RECORD_EFF_DT, RECORD_END_DT)
values (SEQ_CC_C_UNIT_OF_WORK.Nextval, 'EB FREW', to_date('01-01-1900', 'dd-mm-yyyy'), to_date('31-12-2999', 'dd-mm-yyyy'));
insert into cc_c_unit_of_work (UNIT_OF_WORK_ID, UNIT_OF_WORK_NAME, RECORD_EFF_DT, RECORD_END_DT)
values (SEQ_CC_C_UNIT_OF_WORK.Nextval, 'EB Non FREW', to_date('01-01-1900', 'dd-mm-yyyy'), to_date('31-12-2999', 'dd-mm-yyyy'));
insert into cc_c_unit_of_work (UNIT_OF_WORK_ID, UNIT_OF_WORK_NAME, RECORD_EFF_DT, RECORD_END_DT)
values (SEQ_CC_C_UNIT_OF_WORK.Nextval, 'CHIP', to_date('01-01-1900', 'dd-mm-yyyy'), to_date('31-12-2999', 'dd-mm-yyyy'));
insert into cc_c_unit_of_work (UNIT_OF_WORK_ID, UNIT_OF_WORK_NAME, RECORD_EFF_DT, RECORD_END_DT)
values (SEQ_CC_C_UNIT_OF_WORK.Nextval, 'THS', to_date('01-01-1900', 'dd-mm-yyyy'), to_date('31-12-2999', 'dd-mm-yyyy'));    

--Update C Contact Queue w/
update cc_c_contact_queue set unit_of_work_name = 'N/A' where unit_of_work_name = 'Unknown';
update cc_c_contact_queue set unit_of_work_name = 'N/A' where unit_of_work_name <> 'N/A' and queue_number not in (6821, 6853, 6890, 6894, 5145, 5146, 6695, 6698, 5094, 5102, 6683, 6684, 5050, 5055, 6718, 6721);

update cc_c_contact_queue set unit_of_work_name = 'EB FREW' where queue_number in (6821, 6853, 6890, 6894);
update cc_c_contact_queue set unit_of_work_name = 'EB Non FREW' where queue_number in (5145, 5146, 6695, 6698);
update cc_c_contact_queue set unit_of_work_name = 'CHIP' where queue_number in (5094, 5102, 6683, 6684);
update cc_c_contact_queue set unit_of_work_name = 'THS' where queue_number in (5050, 5055, 6718, 6721);

--Update D UOW 
insert into maxdat.cc_d_unit_of_work (uow_id, unit_of_work_name, production_plan_id, hourly_flag, handle_time_unit)
values (SEQ_CC_D_UNIT_OF_WORK.Nextval, 'EB FREW', 0, 'N', 'Seconds');
insert into maxdat.cc_d_unit_of_work (uow_id, unit_of_work_name, production_plan_id, hourly_flag, handle_time_unit)
values (SEQ_CC_D_UNIT_OF_WORK.Nextval, 'EB Non FREW', 0, 'N', 'Seconds');
insert into maxdat.cc_d_unit_of_work (uow_id, unit_of_work_name, production_plan_id, hourly_flag, handle_time_unit)
values (SEQ_CC_D_UNIT_OF_WORK.Nextval, 'CHIP', 0, 'N', 'Seconds');
insert into maxdat.cc_d_unit_of_work (uow_id, unit_of_work_name, production_plan_id, hourly_flag, handle_time_unit)
values (SEQ_CC_D_UNIT_OF_WORK.Nextval, 'THS', 0, 'N', 'Seconds');

--select * from cc_s_contact_queue where queue_number in (6821, 6853, 6890, 6894, 5145, 5146, 6695, 6698, 5094, 5102, 6683, 6684, 5050, 5055, 6718, 6721);
update cc_s_contact_queue set unit_of_work_id = (select unit_of_work_id from cc_c_unit_of_work where unit_of_work_name = 'EB FREW') where queue_number in (6821, 6853, 6890, 6894);
update cc_s_contact_queue set unit_of_work_id = (select unit_of_work_id from cc_c_unit_of_work where unit_of_work_name = 'EB Non FREW') where queue_number in (5145, 5146, 6695, 6698);
update cc_s_contact_queue set unit_of_work_id = (select unit_of_work_id from cc_c_unit_of_work where unit_of_work_name = 'CHIP') where queue_number in (5094, 5102, 6683, 6684);
update cc_s_contact_queue set unit_of_work_id = (select unit_of_work_id from cc_c_unit_of_work where unit_of_work_name = 'THS') where queue_number in (5050, 5055, 6718, 6721);
update cc_s_contact_queue set unit_of_work_id = (select unit_of_work_id from cc_c_unit_of_work where unit_of_work_name = 'N/A') where queue_number not in (6821, 6853, 6890, 6894, 5145, 5146, 6695, 6698, 5094, 5102, 6683, 6684, 5050, 5055, 6718, 6721);

--Update F Actuals Queue Interval w/new UOW Id's
update cc_f_actuals_queue_interval
   set d_unit_of_work_id =
       (select uow_id
          from cc_d_unit_of_work
         where unit_of_work_name = 'EB FREW')
 where f_call_center_actls_intrvl_id in
       (select f_call_center_actls_intrvl_id
          from cc_f_actuals_queue_interval
         where d_contact_queue_id in
               (select d_contact_queue_id
                  from cc_d_contact_queue
                 where queue_number in (6821, 6853, 6890, 6894)));
                 
update cc_f_actuals_queue_interval
   set d_unit_of_work_id =
       (select uow_id
          from cc_d_unit_of_work
         where unit_of_work_name = 'EB Non FREW')
 where f_call_center_actls_intrvl_id in
       (select f_call_center_actls_intrvl_id
          from cc_f_actuals_queue_interval
         where d_contact_queue_id in
               (select d_contact_queue_id
                  from cc_d_contact_queue
                 where queue_number in (5145, 5146, 6695, 6698)));
                 
update cc_f_actuals_queue_interval
   set d_unit_of_work_id =
       (select uow_id
          from cc_d_unit_of_work
         where unit_of_work_name = 'CHIP')
 where f_call_center_actls_intrvl_id in
       (select f_call_center_actls_intrvl_id
          from cc_f_actuals_queue_interval
         where d_contact_queue_id in
               (select d_contact_queue_id
                  from cc_d_contact_queue
                 where queue_number in (5094, 5102, 6683, 6684)));
                 
update cc_f_actuals_queue_interval
   set d_unit_of_work_id =
       (select uow_id
          from cc_d_unit_of_work
         where unit_of_work_name = 'THS')
 where f_call_center_actls_intrvl_id in
       (select f_call_center_actls_intrvl_id
          from cc_f_actuals_queue_interval
         where d_contact_queue_id in
               (select d_contact_queue_id
                  from cc_d_contact_queue
                 where queue_number in (5050, 5055, 6718, 6721))); 

DELETE CC_F_ACTUALS_QUEUE_INTERVAL F
WHERE F_CALL_CENTER_ACTLS_INTRVL_ID IN (
  SELECT MIN(F_CALL_CENTER_ACTLS_INTRVL_ID)
  FROM CC_F_ACTUALS_QUEUE_INTERVAL I_F
  GROUP BY D_DATE_ID, D_PROJECT_ID,D_PROGRAM_ID,D_GEOGRAPHY_MASTER_ID,D_INTERVAL_ID,D_CONTACT_QUEUE_ID,D_AGENT_ID
  HAVING COUNT(*) > 1
);
                 
update cc_f_actuals_queue_interval
   set d_unit_of_work_id =
       (select uow_id
          from cc_d_unit_of_work
         where unit_of_work_name = 'N/A')
 where f_call_center_actls_intrvl_id in
       (select f_call_center_actls_intrvl_id
          from cc_f_actuals_queue_interval
         where d_contact_queue_id in
               (select d_contact_queue_id
                  from cc_d_contact_queue
                 where queue_number not in (6821, 6853, 6890, 6894, 5145, 5146, 6695, 6698,5094, 5102, 6683, 6684, 5050, 5055, 6718, 6721))); 
                 
--Clean up old cc_d_unit_of_work            
delete from cc_d_unit_of_work where unit_of_work_name not in ('N/A','EB FREW','EB Non FREW','CHIP','THS');                 
                 
commit;                   
                 
/      
