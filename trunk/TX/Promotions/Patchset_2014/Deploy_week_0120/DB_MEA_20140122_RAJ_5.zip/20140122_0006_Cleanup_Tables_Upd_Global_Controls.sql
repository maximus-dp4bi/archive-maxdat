/*
Created on 21-Jan-2014 by Raj A.
Project: TXEB
Process: Manage Enrollment Activity.

Description:
TXEB MEA has not run for many days in prod. Using this script we are loading enrollment data starting from 1-Dec-2013.
*/
truncate table corp_etl_Manage_enroll;
truncate table corp_etl_Manage_enroll_oltp;
truncate table corp_etl_Manage_enroll_wip;

DELETE BPM_UPDATE_EVENT_QUEUE WHERE BSL_ID = 14;
DELETE BPM_INSTANCE_ATTRIBUTE where bi_id in (select bi_id from BPM_INSTANCE where bsl_id = 14);

truncate table f_me_by_date;

truncate table D_ME_CURRENT ;
DELETE BPM_UPDATE_EVENT_QUEUE_ARCHIVE WHERE BSL_ID = 14;
DELETE BPM_UPDATE_EVENT where bi_id in (select bi_id from BPM_INSTANCE where bsl_id = 14);
DELETE BPM_INSTANCE WHERE BSL_ID = 14;
COMMIT;

update corp_etl_control
  set value = 53
 where name = 'MANAGEENROLL_CDC_DAYS_BACK';

update corp_etl_control
  set value = 16272108
 where name = 'MANAGEENROLL_LAST_CLNT_ENRL_STAT_ID';

update corp_etl_control
  set value = to_char(to_date('2013/12/01 00:00:01','yyyy/MM/dd hh24:mi:ss'),'yyyy/MM/dd HH24:mm:ss')  
 where name = 'MANAGEENRL_MAX_UPDATE_TS_LETTER_STG_EMI';

update corp_etl_control
  set value = to_char(to_date('2013/12/01 00:00:01','yyyy/MM/dd hh24:mi:ss'),'yyyy/MM/dd HH24:mm:ss')
 where name = 'MANAGEENRL_MAX_UPDATE_TS_LETTER_STG_HPC';

update corp_etl_control
  set value = to_char(to_date('2013/12/01 00:00:01','yyyy/MM/dd hh24:mi:ss'),'yyyy/MM/dd HH24:mm:ss')
 where name = 'MANAGEENRL_MAX_UPDATE_TS_COST_SHARE_DTLS';

update corp_etl_control
  set value = to_char(to_date('2013/12/01 00:00:01','yyyy/MM/dd hh24:mi:ss'),'yyyy/MM/dd HH24:mm:ss')
 where name = 'MANAGEENRL_MAX_UPDATE_TS_CLNT_ENRL_STAT';

update corp_etl_control
  set value = to_char(to_date('2013/12/01 00 :00:01','yyyy/MM/dd hh24:mi:ss'),'yyyy/MM/dd HH24:mm:ss')
 where name = 'MANAGEENRL_MAX_UPDATE_TS_SELECTION_TXN';

update corp_etl_control
  set value = 'Y'
 where name = 'MANAGEENRL_NULL_COLUMNS_ONE_TIME';
commit;