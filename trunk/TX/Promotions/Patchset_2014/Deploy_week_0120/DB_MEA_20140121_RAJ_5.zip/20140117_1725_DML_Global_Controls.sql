/*
Created on 17-Jan-2014 by Raj A.
Project: TXEB
Process: Manage Enrollment Activity.

Description:
TXEB MEA has not run for many days in prod. Also, MAXDAT UAT data is not in a usable condition. This script will set the global controls so the gard-coded clients
will be inserted into the BPM stage for testing in UAT.

*/
update corp_etl_control
  set value = 90
 where name = 'MANAGEENROLL_CDC_DAYS_BACK';

update corp_etl_control
  set value = 16272108
 where name = 'MANAGEENROLL_LAST_CLNT_ENRL_STAT_ID';

update corp_etl_control
  set value = to_char(to_date('2013/08/01 01:00:00','yyyy/MM/dd hh24:mi:ss'),'yyyy/MM/dd HH24:mm:ss')  
 where name = 'MANAGEENRL_MAX_UPDATE_TS_LETTER_STG_EMI';

update corp_etl_control
  set value = to_char(to_date('2013/08/01 01:00:00','yyyy/MM/dd hh24:mi:ss'),'yyyy/MM/dd HH24:mm:ss')
 where name = 'MANAGEENRL_MAX_UPDATE_TS_LETTER_STG_HPC';

update corp_etl_control
  set value = to_char(to_date('2013/08/01 01:00:00','yyyy/MM/dd hh24:mi:ss'),'yyyy/MM/dd HH24:mm:ss')
 where name = 'MANAGEENRL_MAX_UPDATE_TS_COST_SHARE_DTLS';

update corp_etl_control
  set value = to_char(to_date('2013/08/01 01:00:00','yyyy/MM/dd hh24:mi:ss'),'yyyy/MM/dd HH24:mm:ss')
 where name = 'MANAGEENRL_MAX_UPDATE_TS_CLNT_ENRL_STAT';

update corp_etl_control
  set value = to_char(to_date('2013/08/01 01:00:00','yyyy/MM/dd hh24:mi:ss'),'yyyy/MM/dd HH24:mm:ss')
 where name = 'MANAGEENRL_MAX_UPDATE_TS_SELECTION_TXN';

update corp_etl_control
  set value = 'Y'
 where name = 'MANAGEENRL_NULL_COLUMNS_ONE_TIME';
commit;