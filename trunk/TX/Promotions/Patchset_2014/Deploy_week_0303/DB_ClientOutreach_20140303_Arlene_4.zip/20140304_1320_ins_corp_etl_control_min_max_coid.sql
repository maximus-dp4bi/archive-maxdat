Insert into CORP_ETL_CONTROL (NAME,VALUE_TYPE,VALUE,DESCRIPTION,CREATED_TS,UPDATED_TS) 
values ('CO_MIN_UPD_OUTREACH_ID','N','0','Used to fetch a range of data to process the update rules',SYSDATE,SYSDATE);

Insert into CORP_ETL_CONTROL (NAME,VALUE_TYPE,VALUE,DESCRIPTION,CREATED_TS,UPDATED_TS) 
values ('CO_MAX_UPD_OUTREACH_ID','N','0','Used to fetch a range of data to process the update rules',SYSDATE,SYSDATE);

commit;

