alter table  STEP_INSTANCE_STG add
(process_id		NUMBER
,process_instance_id	NUMBER
);