#! /bin/ksh
#Cron file to run tx_run_emrs
# Do not edit these four SVN_* variable values.  They are populated when you commit code to SVN
#     and used later to identify deployed code.
# $URL: svn://rcmxapp1d.maximus.com/maxdat/trunk/TX/cron_files/cron_tx_run_emrs_medenrl.sh $
# $Revision: 9435 $
# $Date: 2014-04-10 15:45:10 -0700 (Thu, 10 Apr 2014) $
# $Author: aa24065 $
. /tpxe4t/3rdparty/.profile

nohup $MAXDAT_ETL_PATH/tx_emrs_load_enrl_adhoc_medicaid.sh > $MAXDAT_ETL_LOGS/tx_emrs_load_enrl_adhoc_medicaid.cron.log &

