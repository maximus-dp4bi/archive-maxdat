update BPM_D_OPS_GROUP_TASK set ops_group = 'Outreach' where task_type in ('DFPS Home Visit','Parenting Teen Home Visit');
update BPM_D_OPS_GROUP_TASK set ops_group = 'Special Services Unit' where task_type in ('Provider Referral Follow-up','SSU Research Review Task');
commit;
