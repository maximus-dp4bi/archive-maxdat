update CC_S_PRODUCTION_PLAN
set project_name='TX Enrollment Broker'
where project_name='Enrollment Broker';

commit;