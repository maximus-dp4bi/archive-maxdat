/*
select * from cc_c_activity_type;
select * from cc_c_contact_queue;
select * from cc_c_filter;
select * from cc_c_lookup;
select * from cc_s_production_plan;
select * from cc_c_project_config;
select * from cc_c_unit_of_work;

select * from cc_d_interval;
*/

delete cc_s_acd_interval;
delete cc_s_acd_agent_activity;
delete cc_s_agent_absence;
delete cc_s_agent_supervisor;
delete cc_s_agent_work_day;
delete cc_s_call_detail;
delete cc_s_wfm_agent_activity;
delete cc_s_wfm_interval;
delete cc_s_timezoneam;
delete cc_s_ivr_interval;

delete cc_s_interval;
delete cc_c_activity_type;
delete cc_c_contact_queue;
delete cc_c_filter;
delete cc_c_lookup;
delete cc_s_production_plan;
delete cc_s_contact_queue;
delete cc_s_acd_interval_period;
delete cc_s_agent;
delete cc_c_unit_of_work;
delete cc_c_project_config;