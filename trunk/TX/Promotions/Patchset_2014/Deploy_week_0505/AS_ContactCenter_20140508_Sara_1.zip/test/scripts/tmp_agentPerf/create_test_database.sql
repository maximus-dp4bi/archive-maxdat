
@@ create_test_tablespace.sql;
@@ create_test_role.sql;
@@ create_test_user.sql;

@@ create_test_staging_tables.sql;
@@ create_test_dimensional_tables.sql;

COMMIT;