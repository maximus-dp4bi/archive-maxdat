ALTER TABLE CC_F_AGENT_BY_DATE
DISABLE CONSTRAINT CC_F_AGENT_BY_DATE__UN;

ALTER TABLE CC_F_AGENT_ACTIVITY_BY_DATE
DISABLE CONSTRAINT F_AGENT_ACT_BY_DATE__UN;

DROP INDEX CC_F_AGENT_BY_DATE__UN;

DROP INDEX F_AGENT_ACT_BY_DATE__UN;

delete cc_f_agent_by_date f
where f_agent_by_date_id in (
  select min(f_agent_by_date_id)
  from cc_f_agent_by_date i_f
  inner join cc_d_agent da on i_f.d_agent_id = da.d_agent_id
  group by d_date_id, login_id, handle_calls_count
  having count(*) > 1
);

delete cc_f_agent_activity_by_date f
where f_agent_activity_by_date_id in (
  select min(f_agent_activity_by_date_id)
  from cc_f_agent_activity_by_date i_f
  inner join cc_d_agent da on i_f.d_agent_id = da.d_agent_id
  inner join cc_d_activity_type dat on i_f.d_activity_type_id = dat.d_activity_type_id
  group by d_date_id, i_f.d_activity_type_id, login_id
  having count(*) > 1
);	

MERGE INTO CC_D_AGENT ag
using
(
select rowid as r_id,
row_number() over (partition by login_id order by record_eff_dt) as new_version
from CC_D_AGENT
)ag2
on (ag.ROWID=ag2.r_id)
WHEN MATCHED THEN UPDATE
SET ag.version=ag2.new_version;

ALTER TABLE CC_F_AGENT_BY_DATE
ENABLE CONSTRAINT CC_F_AGENT_BY_DATE__UN;

ALTER TABLE CC_F_AGENT_ACTIVITY_BY_DATE
ENABLE CONSTRAINT F_AGENT_ACT_BY_DATE__UN;


INSERT INTO CC_L_PATCH_LOG ( PATCH_VERSION , SCRIPT_SEQUENCE , SCRIPT_NAME)
VALUES ('1.3.1','112','112_TXEB_DUPLICATED_AGENT_CLEANUP_112');

COMMIT;