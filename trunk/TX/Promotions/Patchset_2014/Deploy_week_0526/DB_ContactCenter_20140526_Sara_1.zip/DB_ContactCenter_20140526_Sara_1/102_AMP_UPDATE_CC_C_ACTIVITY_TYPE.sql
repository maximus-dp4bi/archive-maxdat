update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Working Contact'
,IS_PAID_FLAG=1
,IS_AVAILABLE_FLAG=1
,IS_READY_FLAG=1
where ACTIVITY_TYPE_NAME='ACW';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Working Contact'
where ACTIVITY_TYPE_NAME='ACW (Cisco Code 32)';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Working Contact'
where ACTIVITY_TYPE_NAME='After Call Work';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Scheduled PTO'
where ACTIVITY_TYPE_NAME='Bereavement';

update CC_C_ACTIVITY_TYPE
set IS_AVAILABLE_FLAG=0
where ACTIVITY_TYPE_NAME='Blended';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Lunch and Break'
where ACTIVITY_TYPE_NAME='Break (Cisco Code 1)';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Working Contact'
,IS_PAID_FLAG=1
,IS_AVAILABLE_FLAG=1
,IS_READY_FLAG=1
where ACTIVITY_TYPE_NAME='CHIP Outbound Project';

update CC_C_ACTIVITY_TYPE
set IS_AVAILABLE_FLAG=0
where ACTIVITY_TYPE_NAME='Deferred';

update CC_C_ACTIVITY_TYPE
set IS_AVAILABLE_FLAG=0
where ACTIVITY_TYPE_NAME='Deleted Timeline';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Working Contact'
,IS_READY_FLAG=1
where ACTIVITY_TYPE_NAME='EB Tech On Call';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Available'
where ACTIVITY_TYPE_NAME='EB Tech Ready';

update CC_C_ACTIVITY_TYPE
set IS_AVAILABLE_FLAG=0
where ACTIVITY_TYPE_NAME='EB Tech Sup Queue';

update CC_C_ACTIVITY_TYPE
set IS_AVAILABLE_FLAG=0
where ACTIVITY_TYPE_NAME='EB VM Special Projects (Cisco Code 6)';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Available'
where ACTIVITY_TYPE_NAME='EB WFM Ready';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Working Contact'
where ACTIVITY_TYPE_NAME='ES CHIP Outbound';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Other Not Ready'
,IS_AVAILABLE_FLAG=0
,IS_READY_FLAG=0
where ACTIVITY_TYPE_NAME='Extra Hours';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Unscheduled PTO'
where ACTIVITY_TYPE_NAME='FLMA Pending';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Scheduled PTO'
where ACTIVITY_TYPE_NAME='FMLA';

update CC_C_ACTIVITY_TYPE
set IS_AVAILABLE_FLAG=0
where ACTIVITY_TYPE_NAME='General Absence';

update CC_C_ACTIVITY_TYPE
set IS_AVAILABLE_FLAG=0
where ACTIVITY_TYPE_NAME='Generic Non-Work Activity';

update CC_C_ACTIVITY_TYPE
set IS_AVAILABLE_FLAG=0
where ACTIVITY_TYPE_NAME='Generic Work Activity';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Working Contact'
,IS_PAID_FLAG=1
,IS_AVAILABLE_FLAG=1
,IS_READY_FLAG=1
where ACTIVITY_TYPE_NAME='Hold';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Scheduled PTO'
where ACTIVITY_TYPE_NAME='Jury Duty';

update CC_C_ACTIVITY_TYPE
set IS_AVAILABLE_FLAG=0
where ACTIVITY_TYPE_NAME='Learning';

update CC_C_ACTIVITY_TYPE
set IS_AVAILABLE_FLAG=0
where ACTIVITY_TYPE_NAME='Learning Break';

update CC_C_ACTIVITY_TYPE
set IS_AVAILABLE_FLAG=0
where ACTIVITY_TYPE_NAME='Learning End';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Scheduled PTO'
where ACTIVITY_TYPE_NAME='Leave Without Pay';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Scheduled PTO'
where ACTIVITY_TYPE_NAME='LOA';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Lunch and Break'
where ACTIVITY_TYPE_NAME='Lunch (Cisco Code 3)';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Scheduled PTO'
where ACTIVITY_TYPE_NAME='Military Leave';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Unscheduled PTO'
where ACTIVITY_TYPE_NAME='NCNS';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Other Not Ready'
where ACTIVITY_TYPE_NAME='No Activity';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Other Not Ready'
where ACTIVITY_TYPE_NAME='Not ready';

update CC_C_ACTIVITY_TYPE
set IS_READY_FLAG=1
where ACTIVITY_TYPE_NAME='Outbound';

update CC_C_ACTIVITY_TYPE
set IS_READY_FLAG=1
where ACTIVITY_TYPE_NAME='Outreach Surveys';

update CC_C_ACTIVITY_TYPE
set IS_AVAILABLE_FLAG=0
where ACTIVITY_TYPE_NAME='Password Reset';

update CC_C_ACTIVITY_TYPE
set IS_AVAILABLE_FLAG=0
where ACTIVITY_TYPE_NAME='Pending Logout';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Other Not Ready'
where ACTIVITY_TYPE_NAME='Personal - Restroom (Cisco Code 30)';

update CC_C_ACTIVITY_TYPE
set IS_AVAILABLE_FLAG=1
,IS_READY_FLAG=1
where ACTIVITY_TYPE_NAME='Predictive Dialer';

update CC_C_ACTIVITY_TYPE
set IS_AVAILABLE_FLAG=0
where ACTIVITY_TYPE_NAME='QC Escalation';


update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Available'
where ACTIVITY_TYPE_NAME='Ready';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Other Not Ready'
where ACTIVITY_TYPE_NAME='Records Merge Activity';

update CC_C_ACTIVITY_TYPE
set IS_AVAILABLE_FLAG=0
where ACTIVITY_TYPE_NAME='S.M.E./Manager Relief (Cisco Code 7)';

update CC_C_ACTIVITY_TYPE
set IS_PAID_FLAG=1
where ACTIVITY_TYPE_NAME='Scheduled One on One';

update CC_C_ACTIVITY_TYPE
set IS_AVAILABLE_FLAG=0
where ACTIVITY_TYPE_NAME='Shift/Overtime Gap';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Other Not Ready'
where ACTIVITY_TYPE_NAME='Special Projects (Cisco Code 6)';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Meeting'
where ACTIVITY_TYPE_NAME='Supervisor Meeting (Cisco Code 2)';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Meeting'
where ACTIVITY_TYPE_NAME='Supervisor Meeting (Cisco Code 22)';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Working Contact'
where ACTIVITY_TYPE_NAME='Talking';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Unscheduled PTO'
where ACTIVITY_TYPE_NAME='Tardy';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Other Not Ready'
where ACTIVITY_TYPE_NAME='Technical Problems (Cisco Code 31)';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Other Not Ready'
where ACTIVITY_TYPE_NAME='Technical Problems (IT) (Cisco Code 11)';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Other Not Ready'
,IS_PAID_FLAG=1
where ACTIVITY_TYPE_NAME='Technical-Problems (IT) (Cisco Code 11)';

update CC_C_ACTIVITY_TYPE
set IS_AVAILABLE_FLAG=0
where ACTIVITY_TYPE_NAME='THS VM Special Projects (Cisco Code 6)';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Unscheduled PTO'
where ACTIVITY_TYPE_NAME='Unscheduled Absenc';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Unscheduled PTO'
where ACTIVITY_TYPE_NAME='Unscheduled CRITICAL Absence';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Unscheduled PTO'
where ACTIVITY_TYPE_NAME='Unscheduled HALF Absence';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Scheduled PTO'
where ACTIVITY_TYPE_NAME='Vacation/PTO';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Scheduled PTO'
,IS_PAID_FLAG=1
where ACTIVITY_TYPE_NAME='Voluntary Time Off';

update CC_C_ACTIVITY_TYPE
set ACTIVITY_TYPE_CATEGORY='Other Not Ready'
where ACTIVITY_TYPE_NAME='zPending Logout';

INSERT INTO CC_L_PATCH_LOG ( PATCH_VERSION , SCRIPT_SEQUENCE , SCRIPT_NAME) 
VALUES ('0.2.1','102','102_AMP_UPDATE_CC_C_ACTIVITY_TYPE');

commit;