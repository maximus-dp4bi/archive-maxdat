/*
Created on 17-MAR-2014 by Raj A.
*/
create index IDX_WIP_Upd_flg          on corp_etl_manage_enroll_wip (UPDATE_FLG);