update CORP_ETL_CONTROL
set value = 1
where name = 'ACTIVITY_UPDATE_DAY';
commit;