Insert into CORP_ETL_CONTROL (NAME,VALUE_TYPE,VALUE,DESCRIPTION,CREATED_TS,UPDATED_TS) 
values ('CO_MAX_OUTREACH_ID','N',28541501,'Used to fetch a range of data from OLTP for Client Outreach Adhoc process',SYSDATE,SYSDATE);

Insert into CORP_ETL_CONTROL (NAME,VALUE_TYPE,VALUE,DESCRIPTION,CREATED_TS,UPDATED_TS) 
values ('CO_RUN_START_TIME','V','23:59:58','Start Time for Client Outreach process to run',SYSDATE,SYSDATE);

Insert into CORP_ETL_CONTROL (NAME,VALUE_TYPE,VALUE,DESCRIPTION,CREATED_TS,UPDATED_TS) 
values ('CO_RUN_END_TIME','V','23:59:59','End Time for Client Outreach process to run',SYSDATE,SYSDATE);

COMMIT;