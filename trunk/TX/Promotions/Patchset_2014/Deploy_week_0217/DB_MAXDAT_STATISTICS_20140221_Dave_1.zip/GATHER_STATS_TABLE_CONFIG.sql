create table GATHER_STATS_TABLE_CONFIG
(
  TABLE_NAME                VARCHAR2(30) not null,
  GATHER_STATS_PERIODICALLY VARCHAR2(1) not null
);
/
alter table GATHER_STATS_TABLE_CONFIG
  add constraint GATHER_STATS_PER_CHECK
  check (GATHER_STATS_PERIODICALLY IN ('Y','N'));
/