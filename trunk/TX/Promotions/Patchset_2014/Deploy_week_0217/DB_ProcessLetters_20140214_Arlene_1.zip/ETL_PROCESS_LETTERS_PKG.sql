alter session set plsql_code_type = native;

create or replace package ETL_PROCESS_LETTERS_PKG as

  -- Do not edit these four SVN_* variable values.  They are populated when you commit code to SVN and used later to identify deployed code.

  SVN_FILE_URL varchar2(200) := '$URL: svn://rcmxapp1d.maximus.com/maxdat/BPM/TXEB/ProcessLetters/createdb/ETL_PROCESS_LETTERS_PKG.sql $'; 
  SVN_REVISION varchar2(20) := '$Revision: 3567 $'; 
  SVN_REVISION_DATE varchar2(60) := '$Date: 2014-13-02 15:26:32 -0700 (Mon, 01 Jul 2013) $'; 
  SVN_REVISION_AUTHOR varchar2(20) := '$Author: aa24065 $';
  
  procedure COPY_LETTERS_TO_TEMP;
  
end;
/    

create or replace package body ETL_PROCESS_LETTERS_PKG as

PROCEDURE COPY_LETTERS_TO_TEMP AS

 CURSOR letters_cur IS
   SELECT cepn_id,letter_request_id,create_dt,create_by,
          request_dt,letter_type,program,case_id,
          county_code,zip_code,language,reprint,
          request_driver_type,request_driver_table,status,status_dt,
          sent_dt,print_dt,mailed_dt,return_dt,
          return_reason,reject_reason,error_reason,transmit_file_name,
          transmit_file_dt,letter_resp_file_name,letter_resp_file_dt,last_update_dt,
          last_update_by_name,newborn_flag,task_id,cancel_dt,
          cancel_by,cancel_reason,cancel_method,complete_dt,
          instance_status,assd_process_letter_req,ased_process_letter_req,assd_transmit,
          ased_transmit,assd_receive_confirmation,ased_receive_confirmation,assd_create_route_work,
          ased_create_route_work,asf_process_letter_req,asf_transmit,asf_receive_confirmation,
          asf_create_route_work,gwf_valid,gwf_outcome,gwf_work_required,
          stg_extract_date,stg_last_update_date,stage_done_date
 FROM corp_etl_proc_letters
   WHERE complete_dt IS NULL;
   
   TYPE t_letter_tab IS TABLE OF letters_cur%ROWTYPE INDEX BY PLS_INTEGER;
    letter_tab t_letter_tab;
    v_bulk_limit NUMBER := 500;    
    v_step VARCHAR2(100);
    v_err_code VARCHAR2(30);
    v_err_msg VARCHAR2(240);
BEGIN
   v_step := 'Truncate temp tables';   
   EXECUTE IMMEDIATE 'truncate table CORP_ETL_PROC_LETTERS_WIP_T';
   EXECUTE IMMEDIATE 'truncate table CORP_ETL_PROC_LETTERS_WIP_BPM';
   EXECUTE IMMEDIATE 'truncate table CORP_ETL_PROC_LETTERS_OLTP_T';
   EXECUTE IMMEDIATE 'truncate table CORP_ETL_PROC_LETTERS_OLTP';
   
   OPEN letters_cur;
   LOOP
     FETCH letters_cur BULK COLLECT INTO letter_tab LIMIT v_bulk_limit;
     EXIT WHEN letter_tab.COUNT = 0; -- Exit when missing rows

     FOR indx IN 1 .. letter_tab.COUNT LOOP    
       BEGIN
        v_step := 'Error inserting into WIP_T';
        INSERT INTO corp_etl_proc_letters_wip_t	(
          cepn_id,letter_request_id,create_dt,create_by,
          request_dt,letter_type,program,case_id,
          county_code,zip_code,language,reprint,
          request_driver_type,request_driver_table,status,status_dt,
          sent_dt,print_dt,mailed_dt,return_dt,
          return_reason,reject_reason,error_reason,transmit_file_name,
          transmit_file_dt,letter_resp_file_name,letter_resp_file_dt,last_update_dt,
          last_update_by_name,newborn_flag,task_id,cancel_dt,
          cancel_by,cancel_reason,cancel_method,complete_dt,
          instance_status,assd_process_letter_req,ased_process_letter_req,assd_transmit,
          ased_transmit,assd_receive_confirmation,ased_receive_confirmation,assd_create_route_work,
          ased_create_route_work,asf_process_letter_req,asf_transmit,asf_receive_confirmation,
          asf_create_route_work,gwf_valid,gwf_outcome,gwf_work_required,
          stg_extract_date,stg_last_update_date,stage_done_date	)
         VALUES (letter_tab(indx).cepn_id,letter_tab(indx).letter_request_id,letter_tab(indx).create_dt,letter_tab(indx).create_by,
          letter_tab(indx).request_dt,letter_tab(indx).letter_type,letter_tab(indx).program,letter_tab(indx).case_id,
          letter_tab(indx).county_code,letter_tab(indx).zip_code,letter_tab(indx).language,letter_tab(indx).reprint,
          letter_tab(indx).request_driver_type,letter_tab(indx).request_driver_table,letter_tab(indx).status,letter_tab(indx).status_dt,
          letter_tab(indx).sent_dt,letter_tab(indx).print_dt,letter_tab(indx).mailed_dt,letter_tab(indx).return_dt,
          letter_tab(indx).return_reason,letter_tab(indx).reject_reason,letter_tab(indx).error_reason,letter_tab(indx).transmit_file_name,
          letter_tab(indx).transmit_file_dt,letter_tab(indx).letter_resp_file_name,letter_tab(indx).letter_resp_file_dt,letter_tab(indx).last_update_dt,
          letter_tab(indx).last_update_by_name,letter_tab(indx).newborn_flag,letter_tab(indx).task_id,letter_tab(indx).cancel_dt,
          letter_tab(indx).cancel_by,letter_tab(indx).cancel_reason,letter_tab(indx).cancel_method,letter_tab(indx).complete_dt,
          letter_tab(indx).instance_status,letter_tab(indx).assd_process_letter_req,letter_tab(indx).ased_process_letter_req,letter_tab(indx).assd_transmit,
          letter_tab(indx).ased_transmit,letter_tab(indx).assd_receive_confirmation,letter_tab(indx).ased_receive_confirmation,letter_tab(indx).assd_create_route_work,
          letter_tab(indx).ased_create_route_work,letter_tab(indx).asf_process_letter_req,letter_tab(indx).asf_transmit,letter_tab(indx).asf_receive_confirmation,
          letter_tab(indx).asf_create_route_work,letter_tab(indx).gwf_valid,letter_tab(indx).gwf_outcome,letter_tab(indx).gwf_work_required,
          letter_tab(indx).stg_extract_date,letter_tab(indx).stg_last_update_date,letter_tab(indx).stage_done_date);	   
        
        v_step := 'Error inserting into WIP_BPM';
        INSERT INTO corp_etl_proc_letters_wip_bpm	(
          cepn_id,letter_request_id,create_dt,create_by,
          request_dt,letter_type,program,case_id,
          county_code,zip_code,language,reprint,
          request_driver_type,request_driver_table,status,status_dt,
          sent_dt,print_dt,mailed_dt,return_dt,
          return_reason,reject_reason,error_reason,transmit_file_name,
          transmit_file_dt,letter_resp_file_name,letter_resp_file_dt,last_update_dt,
          last_update_by_name,newborn_flag,task_id,cancel_dt,
          cancel_by,cancel_reason,cancel_method,complete_dt,
          instance_status,assd_process_letter_req,ased_process_letter_req,assd_transmit,
          ased_transmit,assd_receive_confirmation,ased_receive_confirmation,assd_create_route_work,
          ased_create_route_work,asf_process_letter_req,asf_transmit,asf_receive_confirmation,
          asf_create_route_work,gwf_valid,gwf_outcome,gwf_work_required,
          stg_extract_date,stg_last_update_date,stage_done_date	)
         VALUES (letter_tab(indx).cepn_id,letter_tab(indx).letter_request_id,letter_tab(indx).create_dt,letter_tab(indx).create_by,
          letter_tab(indx).request_dt,letter_tab(indx).letter_type,letter_tab(indx).program,letter_tab(indx).case_id,
          letter_tab(indx).county_code,letter_tab(indx).zip_code,letter_tab(indx).language,letter_tab(indx).reprint,
          letter_tab(indx).request_driver_type,letter_tab(indx).request_driver_table,letter_tab(indx).status,letter_tab(indx).status_dt,
          letter_tab(indx).sent_dt,letter_tab(indx).print_dt,letter_tab(indx).mailed_dt,letter_tab(indx).return_dt,
          letter_tab(indx).return_reason,letter_tab(indx).reject_reason,letter_tab(indx).error_reason,letter_tab(indx).transmit_file_name,
          letter_tab(indx).transmit_file_dt,letter_tab(indx).letter_resp_file_name,letter_tab(indx).letter_resp_file_dt,letter_tab(indx).last_update_dt,
          letter_tab(indx).last_update_by_name,letter_tab(indx).newborn_flag,letter_tab(indx).task_id,letter_tab(indx).cancel_dt,
          letter_tab(indx).cancel_by,letter_tab(indx).cancel_reason,letter_tab(indx).cancel_method,letter_tab(indx).complete_dt,
          letter_tab(indx).instance_status,letter_tab(indx).assd_process_letter_req,letter_tab(indx).ased_process_letter_req,letter_tab(indx).assd_transmit,
          letter_tab(indx).ased_transmit,letter_tab(indx).assd_receive_confirmation,letter_tab(indx).ased_receive_confirmation,letter_tab(indx).assd_create_route_work,
          letter_tab(indx).ased_create_route_work,letter_tab(indx).asf_process_letter_req,letter_tab(indx).asf_transmit,letter_tab(indx).asf_receive_confirmation,
          letter_tab(indx).asf_create_route_work,letter_tab(indx).gwf_valid,letter_tab(indx).gwf_outcome,letter_tab(indx).gwf_work_required,
          letter_tab(indx).stg_extract_date,letter_tab(indx).stg_last_update_date,letter_tab(indx).stage_done_date);	      

         v_step := 'Error inserting into OLTP';
         INSERT INTO corp_etl_proc_letters_oltp	(
          cepn_id,letter_request_id,create_dt,create_by,
          request_dt,letter_type,program,case_id,
          county_code,zip_code,language,reprint,
          request_driver_type,request_driver_table,status,status_dt,
          sent_dt,print_dt,mailed_dt,return_dt,
          return_reason,reject_reason,error_reason,transmit_file_name,
          transmit_file_dt,letter_resp_file_name,letter_resp_file_dt,last_update_dt,
          last_update_by_name,newborn_flag,task_id,cancel_dt,
          cancel_by,cancel_reason,cancel_method,complete_dt,
          instance_status,assd_process_letter_req,ased_process_letter_req,assd_transmit,
          ased_transmit,assd_receive_confirmation,ased_receive_confirmation,assd_create_route_work,
          ased_create_route_work,asf_process_letter_req,asf_transmit,asf_receive_confirmation,
          asf_create_route_work,gwf_valid,gwf_outcome,gwf_work_required,
          stg_extract_date,stg_last_update_date,stage_done_date	)
         VALUES (letter_tab(indx).cepn_id,letter_tab(indx).letter_request_id,letter_tab(indx).create_dt,letter_tab(indx).create_by,
          letter_tab(indx).request_dt,letter_tab(indx).letter_type,letter_tab(indx).program,letter_tab(indx).case_id,
          letter_tab(indx).county_code,letter_tab(indx).zip_code,letter_tab(indx).language,letter_tab(indx).reprint,
          letter_tab(indx).request_driver_type,letter_tab(indx).request_driver_table,letter_tab(indx).status,letter_tab(indx).status_dt,
          letter_tab(indx).sent_dt,letter_tab(indx).print_dt,letter_tab(indx).mailed_dt,letter_tab(indx).return_dt,
          letter_tab(indx).return_reason,letter_tab(indx).reject_reason,letter_tab(indx).error_reason,letter_tab(indx).transmit_file_name,
          letter_tab(indx).transmit_file_dt,letter_tab(indx).letter_resp_file_name,letter_tab(indx).letter_resp_file_dt,letter_tab(indx).last_update_dt,
          letter_tab(indx).last_update_by_name,letter_tab(indx).newborn_flag,letter_tab(indx).task_id,letter_tab(indx).cancel_dt,
          letter_tab(indx).cancel_by,letter_tab(indx).cancel_reason,letter_tab(indx).cancel_method,letter_tab(indx).complete_dt,
          letter_tab(indx).instance_status,letter_tab(indx).assd_process_letter_req,letter_tab(indx).ased_process_letter_req,letter_tab(indx).assd_transmit,
          letter_tab(indx).ased_transmit,letter_tab(indx).assd_receive_confirmation,letter_tab(indx).ased_receive_confirmation,letter_tab(indx).assd_create_route_work,
          letter_tab(indx).ased_create_route_work,letter_tab(indx).asf_process_letter_req,letter_tab(indx).asf_transmit,letter_tab(indx).asf_receive_confirmation,
          letter_tab(indx).asf_create_route_work,letter_tab(indx).gwf_valid,letter_tab(indx).gwf_outcome,letter_tab(indx).gwf_work_required,
          letter_tab(indx).stg_extract_date,letter_tab(indx).stg_last_update_date,letter_tab(indx).stage_done_date);	      

         v_step := 'Error inserting into OLTP_T';
         INSERT INTO corp_etl_proc_letters_oltp_t	(
          cepn_id,letter_request_id,create_dt,create_by,
          request_dt,letter_type,program,case_id,
          county_code,zip_code,language,reprint,
          request_driver_type,request_driver_table,status,status_dt,
          sent_dt,print_dt,mailed_dt,return_dt,
          return_reason,reject_reason,error_reason,transmit_file_name,
          transmit_file_dt,letter_resp_file_name,letter_resp_file_dt,last_update_dt,
          last_update_by_name,newborn_flag,task_id,cancel_dt,
          cancel_by,cancel_reason,cancel_method,complete_dt,
          instance_status,assd_process_letter_req,ased_process_letter_req,assd_transmit,
          ased_transmit,assd_receive_confirmation,ased_receive_confirmation,assd_create_route_work,
          ased_create_route_work,asf_process_letter_req,asf_transmit,asf_receive_confirmation,
          asf_create_route_work,gwf_valid,gwf_outcome,gwf_work_required,
          stg_extract_date,stg_last_update_date,stage_done_date	)
         VALUES (letter_tab(indx).cepn_id,letter_tab(indx).letter_request_id,letter_tab(indx).create_dt,letter_tab(indx).create_by,
          letter_tab(indx).request_dt,letter_tab(indx).letter_type,letter_tab(indx).program,letter_tab(indx).case_id,
          letter_tab(indx).county_code,letter_tab(indx).zip_code,letter_tab(indx).language,letter_tab(indx).reprint,
          letter_tab(indx).request_driver_type,letter_tab(indx).request_driver_table,letter_tab(indx).status,letter_tab(indx).status_dt,
          letter_tab(indx).sent_dt,letter_tab(indx).print_dt,letter_tab(indx).mailed_dt,letter_tab(indx).return_dt,
          letter_tab(indx).return_reason,letter_tab(indx).reject_reason,letter_tab(indx).error_reason,letter_tab(indx).transmit_file_name,
          letter_tab(indx).transmit_file_dt,letter_tab(indx).letter_resp_file_name,letter_tab(indx).letter_resp_file_dt,letter_tab(indx).last_update_dt,
          letter_tab(indx).last_update_by_name,letter_tab(indx).newborn_flag,letter_tab(indx).task_id,letter_tab(indx).cancel_dt,
          letter_tab(indx).cancel_by,letter_tab(indx).cancel_reason,letter_tab(indx).cancel_method,letter_tab(indx).complete_dt,
          letter_tab(indx).instance_status,letter_tab(indx).assd_process_letter_req,letter_tab(indx).ased_process_letter_req,letter_tab(indx).assd_transmit,
          letter_tab(indx).ased_transmit,letter_tab(indx).assd_receive_confirmation,letter_tab(indx).ased_receive_confirmation,letter_tab(indx).assd_create_route_work,
          letter_tab(indx).ased_create_route_work,letter_tab(indx).asf_process_letter_req,letter_tab(indx).asf_transmit,letter_tab(indx).asf_receive_confirmation,
          letter_tab(indx).asf_create_route_work,letter_tab(indx).gwf_valid,letter_tab(indx).gwf_outcome,letter_tab(indx).gwf_work_required,
          letter_tab(indx).stg_extract_date,letter_tab(indx).stg_last_update_date,letter_tab(indx).stage_done_date);	      
       EXCEPTION                      
         WHEN OTHERS THEN
           v_err_code := SQLCODE;
           v_err_msg := SUBSTR(SQLERRM, 1, 200);
            insert into corp_etl_error_log values(
                SEQ_CEEL_ID.nextval,--CEEL_ID
                sysdate,--ERR_DATE
                'CRITICAL',--ERR_LEVEL
                'LETTERS',--PROCESS_NAME
                'COPY_LETTERS_TO_TEMP',--JOB_NAME
                '1',--NR_OF_ERROR
                v_step||' '||v_err_msg,--ERROR_DESC
                null,--ERROR_FIELD
                v_err_code,--ERROR_CODES
                sysdate,--CREATE_TS
                sysdate,--UPDATE_TS
                'CORP_ETL_PROC_LETTERS_OLTP',--DRIVER_TABLE_NAME
                letter_tab(indx).letter_request_id);--DRIVER_KEY_NUMBER
       END;  
     END LOOP;
     COMMIT;
  END LOOP;
  COMMIT;
  CLOSE letters_cur;
END;

END ETL_PROCESS_LETTERS_PKG;
/

alter session set plsql_code_type = interpreted;
