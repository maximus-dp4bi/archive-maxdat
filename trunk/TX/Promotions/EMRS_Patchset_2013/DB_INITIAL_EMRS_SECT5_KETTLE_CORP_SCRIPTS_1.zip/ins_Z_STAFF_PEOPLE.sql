INSERT INTO emrs_d_staff_people
(DEPT_NAME 
 ,FIRST_NAME 
 ,LAST_NAME
 ,LOGIN_ID
 ,MANAGED_CARE_PROGRAM
 ,MANAGER_STAFF_ID  
 ,SOURCE_RECORD_ID
 ,STAFF_ID)
VALUES( 'Unknown'
       , 'Unknown'
       , 'Unknown'       
       , 'Unknown'       
       , 'Unknown'       
       , 0
       , 0
       , 0
       );