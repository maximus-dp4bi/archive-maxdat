--------------------------------------------------------
--  File created - Friday-July-19-2013  
--  Sequences for EMRS Semantic views
--------------------------------------------------------
@@EMRS_Semantic_Views.sql
@@EMRS_Semantic_Views_Synonyms.sql
@@EMRS_Semantic_Views_Grants.sql