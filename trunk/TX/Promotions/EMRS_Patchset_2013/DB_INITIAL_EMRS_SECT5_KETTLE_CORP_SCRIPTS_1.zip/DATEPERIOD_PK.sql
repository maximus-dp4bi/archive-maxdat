--------------------------------------------------------
--  DDL for Index DATEPERIOD_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "DATEPERIOD_PK" ON "EMRS_D_DATE_PERIOD" ("DATE_PERIOD_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  TABLESPACE "MAXDAT_INDX" ;
