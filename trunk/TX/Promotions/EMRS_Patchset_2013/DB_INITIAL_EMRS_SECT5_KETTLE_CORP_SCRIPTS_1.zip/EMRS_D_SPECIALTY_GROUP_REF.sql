--------------------------------------------------------
--  DDL for Table EMRS_D_SPECIALTY_GROUP_REF
--------------------------------------------------------

  CREATE TABLE "EMRS_D_SPECIALTY_GROUP_REF" 
   (	"SPECIALTY_GROUP_ID" NUMBER(22,0)
   ) ;
