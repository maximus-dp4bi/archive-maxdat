--------------------------------------------------------
--  DDL for Index SELECTIONMIPK
--------------------------------------------------------

  CREATE UNIQUE INDEX "SELECTIONMIPK" ON "EMRS_D_SELECTION_MISSING_INFO" ("SELECTION_MISSING_INFO_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  TABLESPACE "MAXDAT_INDX" ;
