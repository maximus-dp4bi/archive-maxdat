--------------------------------------------------------
--  DDL for Index SPECIALTY_GROUP_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "SPECIALTY_GROUP_PK" ON "EMRS_D_SPECIALTY_GROUP" ("SPECIALTY_GROUP_ID", "PROVIDER_SPECIALTY_CODE_ID") 
  ;
