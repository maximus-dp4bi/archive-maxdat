--------------------------------------------------------
--  DDL for Table EMRS_D_SPECIALTY_GROUP
--------------------------------------------------------

  CREATE TABLE "EMRS_D_SPECIALTY_GROUP" 
   (	"SPECIALTY_GROUP_ID" NUMBER(22,0), 
	"PROVIDER_SPECIALTY_CODE_ID" NUMBER(22,0), 
	"MINIMUM_ROW_ID" NUMBER(22,0), 
	"GROUP_COUNT" NUMBER(22,0)
   ) ;
