--------------------------------------------------------
--  DDL for Index SELECTIONTRANSHISTPK
--------------------------------------------------------

  CREATE UNIQUE INDEX "SELECTIONTRANSHISTPK" ON "EMRS_D_SELECTION_TRANS_HISTORY" ("SELECTION_TRANS_HISTORY_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  TABLESPACE "MAXDAT_INDX" ;
