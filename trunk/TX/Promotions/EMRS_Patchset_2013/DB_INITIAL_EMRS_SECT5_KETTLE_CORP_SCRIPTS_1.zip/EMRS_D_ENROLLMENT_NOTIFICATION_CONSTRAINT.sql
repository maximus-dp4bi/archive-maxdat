--------------------------------------------------------
--  Constraints for Table EMRS_D_ENROLLMENT_NOTIFICATION
--------------------------------------------------------

  ALTER TABLE "EMRS_D_ENROLLMENT_NOTIFICATION" MODIFY ("NOTIFICATION_ID" NOT NULL ENABLE);
  ALTER TABLE "EMRS_D_ENROLLMENT_NOTIFICATION" MODIFY ("ENROLLMENT_GROUP_ID" NOT NULL ENABLE);
