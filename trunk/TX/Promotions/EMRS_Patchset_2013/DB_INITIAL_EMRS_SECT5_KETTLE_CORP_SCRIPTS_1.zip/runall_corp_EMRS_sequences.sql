--------------------------------------------------------
--  File created - Friday-July-19-2013  
--  Sequences for EMRS Tables
--------------------------------------------------------
@@emrs_sequences.sqs
@@emrs_sequence_grants.grt