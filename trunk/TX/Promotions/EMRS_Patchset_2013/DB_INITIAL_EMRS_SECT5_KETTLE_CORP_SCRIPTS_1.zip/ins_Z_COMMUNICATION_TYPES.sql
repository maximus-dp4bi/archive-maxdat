
insert into emrs_d_communication_type
   (CREATED_BY
   , DATE_CREATED          
   , DATE_OF_VALIDITY_END
   , DATE_OF_VALIDITY_START
   , DATE_UPDATED
   , COMMUNICATION_TYPE_CODE   
   , COMMUNICATION_TYPE_DESCRIPTION
   , COMMUNICATION_TYPE_NAME
   , COMMUNICATION_TYPE_ID
   , MANAGED_CARE_PROGRAM
   , UPDATED_BY
   , VERSION   
 )
   VALUES
   ('AANTONIO'
   , SYSDATE
   , '31-DEC-2050'
   , '01-JAN-1995'   
   , NULL
   , 0
   , 'Unknown'
   , 'Unknown'
   , 0
   , 'Unknown'
   , NULL
   , 0   
);