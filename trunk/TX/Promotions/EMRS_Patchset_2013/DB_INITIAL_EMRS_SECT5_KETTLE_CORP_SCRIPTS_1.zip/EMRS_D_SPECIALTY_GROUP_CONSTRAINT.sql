--------------------------------------------------------
--  Constraints for Table EMRS_D_SPECIALTY_GROUP
--------------------------------------------------------

  ALTER TABLE "EMRS_D_SPECIALTY_GROUP" ADD CONSTRAINT "SPECIALTY_GROUP_PK" PRIMARY KEY ("SPECIALTY_GROUP_ID", "PROVIDER_SPECIALTY_CODE_ID") ENABLE;
