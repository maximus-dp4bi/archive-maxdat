--------------------------------------------------------
--  DDL for Index SPECGROUP_UK
--------------------------------------------------------

  CREATE UNIQUE INDEX "SPECGROUP_UK" ON "EMRS_D_SPECIALTY_GROUP_REF" ("SPECIALTY_GROUP_ID") 
  ;
