--------------------------------------------------------
--  DDL for Index ENROLL_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "ENROLL_PK" ON "EMRS_F_ENROLLMENT" ("ENROLLMENT_ID") 
  PCTFREE 10 INITRANS 2 MAXTRANS 255 COMPUTE STATISTICS 
  TABLESPACE "MAXDAT_INDX" ;
