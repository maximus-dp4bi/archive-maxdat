/* truncate_data_model_CLIENT_INQUIRY.sql
 Date: 5/21/13

 From truncate_data_model_Manage_Jobs.sql
 steps:
 1. Deleting BPM Event Queue and archive.
 2. Deleting Semantic layer.
 3. Deleting BPM Events.
 BEM_id needs to be hard-coded for the process at 3 places and bsl_id at 2 places
 4. per Gary, delete ETL instances. 20130528_0110_fix_populate_lkup script to reset global control.
 */


-- *** Step 1a: event queue
DELETE FROM BPM_UPDATE_EVENT_QUEUE WHERE bsl_id=13;
COMMIT;


-- *** Step 1b: event queue archive
-- OK if this drop table fails because table does not exist.
drop table BUEQ_ARCHIVE_TEMP;

create table BUEQ_ARCHIVE_TEMP
  (BUEQ_ID number not null,
   BSL_ID number not null,
   BIL_ID number not null,
   IDENTIFIER varchar2(35) not null,
   EVENT_DATE date not null,
   QUEUE_DATE date not null,
   PROCESS_BUEQ_ID number,
   BUE_ID number,
   WROTE_BPM_EVENT_DATE date,
   WROTE_BPM_SEMANTIC_DATE date, 
   DATA_VERSION number not null,
   OLD_DATA xmltype,
   NEW_DATA xmltype not null)
xmltype column OLD_DATA store as binary xml
xmltype column NEW_DATA store as binary xml
partition by range (BSL_ID)
interval (1) (partition PT_BUEQ_LT_0 values less than (0)) 
parallel;

insert into BUEQ_ARCHIVE_TEMP
select * from BPM_UPDATE_EVENT_QUEUE_ARCHIVE 
where BSL_ID != 13 and EVENT_DATE >= trunc(sysdate - 7);

drop table BPM_UPDATE_EVENT_QUEUE_ARCHIVE;
alter table BUEQ_ARCHIVE_TEMP rename to BPM_UPDATE_EVENT_QUEUE_ARCHIVE; 
alter table BPM_UPDATE_EVENT_QUEUE_ARCHIVE add constraint BUEQA_PK primary key (BUEQ_ID);
alter index BUEQA_PK rebuild tablespace MAXDAT_INDX parallel;


-- *** Step 2: Remove BPM Semantic layer
truncate table F_SCI_BY_DATE;
alter table F_SCI_BY_DATE drop constraint FSCIBD_DSCICUR_FK;

truncate table D_SCI_CURRENT;
alter table F_SCI_BY_DATE add constraint FSCIBD_DSCICUR_FK foreign key (SCI_BI_ID) references D_SCI_CURRENT(SCI_BI_ID);


-- *** Step 3: Remove BPM Event
-- OK if this drop table fails because table does not exist.
drop table BPM_INSTANCE_ATTRIBUTE_TEMP;

create table BPM_INSTANCE_ATTRIBUTE_TEMP
  (BIA_ID       number not null,
   BI_ID        number not null,
   BA_ID        number not null,
   VALUE_NUMBER number,
   VALUE_DATE   date,
   VALUE_CHAR   varchar2(100),
   START_DATE   date not null,
   END_DATE     date,
   BUE_ID       number not null)
partition by range (BA_ID)
interval(1)
  (partition PT_BIA_BA_LT_0 values less than (0))
tablespace MAXDAT_DATA parallel;

insert into BPM_INSTANCE_ATTRIBUTE_TEMP
select * 
from BPM_INSTANCE_ATTRIBUTE 
where BA_ID in
  (select BA_ID
   from BPM_ATTRIBUTE 
   where BEM_ID != 13);
   
commit;

alter table BPM_INSTANCE_ATTRIBUTE drop constraint BIA_BA_FK;
alter table BPM_INSTANCE_ATTRIBUTE drop constraint BIA_BI_FK;
alter table BPM_INSTANCE_ATTRIBUTE drop constraint BIA_BUE_FK;
alter table BPM_INSTANCE_ATTRIBUTE drop constraint BPM_INSTANCE_ATTRIBUTE_PK;

drop index BPM_INSTANCE_ATTRIBUTE_UNK1;
drop index BPM_INSTANCE_ATTRIBUTE_IX1;
drop index BPM_INSTANCE_ATTRIBUTE_IX2;
drop index BPM_INSTANCE_ATTRIBUTE_LX1;

drop table BIA_BACKUP;
alter table BPM_INSTANCE_ATTRIBUTE rename to BIA_BACKUP;
alter table BPM_INSTANCE_ATTRIBUTE_TEMP rename to BPM_INSTANCE_ATTRIBUTE;

alter table BPM_INSTANCE_ATTRIBUTE add constraint BPM_INSTANCE_ATTRIBUTE_PK primary key (BIA_ID);
alter index BPM_INSTANCE_ATTRIBUTE_PK rebuild tablespace MAXDAT_INDX parallel;

create unique index BPM_INSTANCE_ATTRIBUTE_UNK1 on BPM_INSTANCE_ATTRIBUTE (BI_ID,BA_ID,START_DATE,END_DATE,BUE_ID) online tablespace MAXDAT_INDX parallel compute statistics; 
create index BPM_INSTANCE_ATTRIBUTE_IX1 on BPM_INSTANCE_ATTRIBUTE (BI_ID,BA_ID,END_DATE) online tablespace MAXDAT_INDX parallel compute statistics; 
create index BPM_INSTANCE_ATTRIBUTE_IX2 on BPM_INSTANCE_ATTRIBUTE (BUE_ID) online tablespace MAXDAT_INDX parallel compute statistics; 
create index BPM_INSTANCE_ATTRIBUTE_LX1 on BPM_INSTANCE_ATTRIBUTE (BI_ID) online tablespace MAXDAT_INDX parallel compute statistics;

alter table BPM_INSTANCE_ATTRIBUTE add constraint BIA_BA_FK foreign key (BA_ID) references BPM_ATTRIBUTE (BA_ID);

-- OK if this drop table fails because table does not exist.
drop table BPM_UPDATE_EVENT_TEMP;

create table BPM_UPDATE_EVENT_TEMP as
select * 
from BPM_UPDATE_EVENT 
where BI_ID in 
  (select BI_ID
   from BPM_INSTANCE
   where BEM_ID != 13);

commit;

alter table BPM_UPDATE_EVENT_QUEUE drop constraint BUEQ_BUE_ID_FK;

alter table BPM_UPDATE_EVENT drop constraint BPM_UPDATE_EVENT_PK;
alter table BPM_UPDATE_EVENT drop constraint BUE_BI_FK;
alter table BPM_UPDATE_EVENT drop constraint BUE_BUTL_FK;

drop index BUE_IX1;

drop table BPM_UPDATE_EVENT_BACKUP;

alter table BPM_UPDATE_EVENT rename to BPM_UPDATE_EVENT_BACKUP;
alter table BPM_UPDATE_EVENT_TEMP rename to BPM_UPDATE_EVENT;

--Creating PK and index on BPM_UPDATE_EVENT_BACKUP.BUE_ID
alter table BPM_UPDATE_EVENT add constraint BPM_UPDATE_EVENT_PK primary key (BUE_ID);
alter index BPM_UPDATE_EVENT_PK rebuild tablespace MAXDAT_INDX parallel;

alter table BPM_INSTANCE_ATTRIBUTE add constraint BIA_BUE_FK foreign key (BUE_ID) references BPM_UPDATE_EVENT (BUE_ID);

create index BUE_IX1 on BPM_UPDATE_EVENT (BI_ID) tablespace MAXDAT_INDX parallel compute statistics;

alter table BPM_UPDATE_EVENT add constraint BUE_BI_FK foreign key (BI_ID) references BPM_INSTANCE (BI_ID);
alter table BPM_UPDATE_EVENT add constraint BUE_BUTL_FK foreign key (BUTL_ID) references BPM_UPDATE_TYPE_LKUP (BUTL_ID);
alter table BPM_UPDATE_EVENT_QUEUE add constraint BUEQ_BUE_ID_FK foreign key (BUE_ID) references BPM_UPDATE_EVENT (BUE_ID);

delete from BPM_INSTANCE where BEM_ID = 13;
commit;

alter table BPM_INSTANCE_ATTRIBUTE add constraint BIA_BI_FK foreign key (BI_ID) references BPM_INSTANCE (BI_ID);




-- *** Step 4: Remove ETL instances
/* 6/4/13 Not needed
TRUNCATE TABLE corp_etl_client_inquiry;
TRUNCATE TABLE corp_etl_client_inquiry_dtl;
TRUNCATE TABLE corp_etl_client_inquiry_event;
*/






