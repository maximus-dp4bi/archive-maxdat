alter session set plsql_code_type = native;

create or replace package BPM_COMMON as

  SVN_FILE_URL varchar2(200) := '$URL: svn://rcmxapp1d.maximus.com/maxdat/BPM/Core/createdb/BPM_COMMON_pkg.sql $';
  SVN_REVISION varchar2(20) := '$Revision: 3968 $';
  SVN_REVISION_DATE varchar2(60) := '$Date: 2013-07-23 11:36:07 -0500 (Tue, 23 Jul 2013) $';
  SVN_REVISION_AUTHOR varchar2(20) := '$Author: rk50472 $';

  DATE_FMT varchar2(21) := 'YYYY-MM-DD HH24:MI:SS';
  MAX_DATE date := to_date('2077-07-07 00:00:00',DATE_FMT);
  
  LOG_LEVEL_SEVERE  varchar2(6) := 'SEVERE';
  LOG_LEVEL_WARNING varchar2(7) := 'WARNING';
  LOG_LEVEL_INFO    varchar2(4) := 'INFO';
  LOG_LEVEL_CONFIG  varchar2(6) := 'CONFIG';
  LOG_LEVEL_FINE    varchar2(4) := 'FINE';
  LOG_LEVEL_FINER   varchar2(5) := 'FINER';
  LOG_LEVEL_FINEST  varchar2(6) := 'FINEST';
  
  function BUS_DAYS_BETWEEN
    (p_start_date in date,
     p_end_date in date)
    return integer;
     
  function CLEAN_PARAMETER
    (p_parameter_value in varchar2)
    return varchar2;

  function GET_DATE_FMT return varchar2;
     
  function GET_MAX_DATE return date;
   
  function GET_WEEKDAY
    (p_start_date in date, 
     p_days2add in number := 0) 
    return date;
     
  function GET_BUS_DATE
    (p_start_date in date,
     p_number_days in number := 0)
    return date;
    
  procedure LOGGER
    (p_log_level varchar2,
     p_pbqj_id number,
     p_run_data_object varchar2,
     p_bsl_id number,
     p_bil_id number,
     p_identifier varchar2,
     p_bi_id number,
     p_ba_id number,
     p_log_message clob,
     p_error_number number);
  
end;
/


create or replace package body BPM_COMMON as
 
  -- Calculates the age in business days.
  function BUS_DAYS_BETWEEN
    (p_start_date in date,
     p_end_date in date)
    return integer
  as
  begin
    return ETL_COMMON.BUS_DAYS_BETWEEN(p_start_date,p_end_date);
  end;
  
  
  -- Output log message to BPM_LOGGING table and dbms_output.
  procedure LOGGER
    (p_log_level varchar2,
     p_pbqj_id number,
     p_run_data_object varchar2,
     p_bsl_id number,
     p_bil_id number,
     p_identifier varchar2,
     p_bi_id number,
     p_ba_id number,
     p_log_message clob,
     p_error_number number)
     
  as
  
    pragma autonomous_transaction;
     
  begin

    insert into BPM_LOGGING
      (BL_ID,LOG_DATE,LOG_LEVEL,PBQJ_ID,RUN_DATA_OBJECT,BSL_ID,BIL_ID,IDENTIFIER,BI_ID,BA_ID,MESSAGE,ERROR_NUMBER,BACKTRACE)
    values 
      (SEQ_BL_ID.nextval,sysdate,p_log_level,p_pbqj_id,p_run_data_object,p_bsl_id,p_bil_id,p_identifier,p_bi_id,p_ba_id,
       p_log_message,p_error_number,dbms_utility.format_error_backtrace);

    commit;
    
    dbms_output.put_line(p_log_level || ': ' || p_log_message);
    
  end;


  -- Clean parameter to avoid SQL injection.
  function CLEAN_PARAMETER
    (p_parameter_value in varchar2)
    return varchar2
  as
    v_procedure_name varchar2(61) := $$PLSQL_UNIT || '.' || 'CLEAN_PARAMETER';
    v_sql_code number := null;
    v_log_message clob := null;
    v_parameter_value_clean varchar2(100) := null;
  begin
    
    if p_parameter_value is null then
       v_parameter_value_clean := p_parameter_value;
    else
      v_parameter_value_clean := regexp_replace(p_parameter_value,'[[:space:]]','');  -- Remove any spaces to avoid SQL injections  
      v_parameter_value_clean := regexp_replace(v_parameter_value_clean,'[;]','');  -- Remove any semicolon to avoid SQL injections
    end if;
    
    return v_parameter_value_clean;
    
  exception
    when others then
      v_sql_code := SQLCODE;
      v_log_message := 'Unable to clean parameter value "' || p_parameter_value || '".  ' || SQLERRM;
      BPM_COMMON.LOGGER(BPM_COMMON.LOG_LEVEL_SEVERE,null,v_procedure_name,null,null,null,null,null,v_log_message,v_sql_code);
      raise;
  end;
  

  -- Get standard data format.
  function GET_DATE_FMT return varchar2
  as
  begin
    return DATE_FMT;
  end;


  -- Get maximum date for BPM Event data.
  function GET_MAX_DATE return date
  as
  begin
    return MAX_DATE;
  end;


  -- Get weekday.
  function GET_WEEKDAY
    (p_start_date in date, 
     p_days2add in number) 
    return date
  as
  begin
    return ETL_COMMON.GET_WEEKDAY(p_start_date,p_days2add);
  end;


  -- Get business date.
  function GET_BUS_DATE
    (p_start_date in date,
     p_number_days in number)
    return date
  as
  begin
    return ETL_COMMON.GET_BUS_DATE(p_start_date,p_number_days);
  end;
  

end;
/


alter session set plsql_code_type = interpreted;