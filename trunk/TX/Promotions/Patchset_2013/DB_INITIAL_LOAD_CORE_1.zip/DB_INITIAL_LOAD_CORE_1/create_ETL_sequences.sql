-- Create ETL sequences.

create sequence CELL_HISTORY_SEQ;
create or replace public synonym CELL_HISTORY_SEQ for CELL_HISTORY_SEQ;

create sequence SEQ_CEC;
create or replace public synonym SEQ_CEC for SEQ_CEC;
grant select on SEQ_CEC to MAXDAT_READ_ONLY; 

create sequence SEQ_CECT_ID;
create or replace public synonym SEQ_CECT_ID for SEQ_CECT_ID;

create sequence SEQ_CECT_HS_ID;
create or replace public synonym SEQ_CECT_HS_ID for SEQ_CECT_HS_ID;

create sequence SEQ_CEEL_ID;
create or replace public synonym SEQ_CEEL_ID for SEQ_CEEL_ID;

create sequence SEQ_CELL_ID;
create or replace public synonym SEQ_CELL_ID for SEQ_CELL_ID;
grant select on SEQ_CELL_ID to MAXDAT_READ_ONLY; 

create sequence SEQ_CICT_ID;
create or replace public synonym SEQ_CICT_ID for SEQ_CICT_ID;

create sequence SEQ_HOLIDAY_ID;
create or replace public synonym SEQ_HOLIDAY_ID for SEQ_HOLIDAY_ID;
grant select on SEQ_HOLIDAY_ID to MAXDAT_READ_ONLY; 

create sequence SEQ_JOB_ID;
create or replace public synonym SEQ_JOB_ID for SEQ_JOB_ID;
