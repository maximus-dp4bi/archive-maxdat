update bpm_update_event_queue
set process_bueq_id=null
where bsl_id=10;

commit;