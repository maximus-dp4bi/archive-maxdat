update BPM_ATTRIBUTE_STAGING_TABLE
set BA_ID = 1679
where
  BSL_ID = 13
  and BA_ID = 47;
  
commit;
