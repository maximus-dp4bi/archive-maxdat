insert into BPM_PROJECT_LKUP (BPRJ_ID,NAME) values (2,'Texas Enrollment');

commit;