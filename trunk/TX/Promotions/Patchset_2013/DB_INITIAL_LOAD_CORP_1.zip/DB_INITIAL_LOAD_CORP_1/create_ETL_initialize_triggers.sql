alter session set plsql_code_type = native;

/*
Created on 11-Apr-2013 by Raj A.
Description:
This trigger populates stage_create_ts(in case :NEW.stage_create_ts is null) and stage_update_ts although the Stage_create_ts gets 
populated by the KTR, ManageWork_Capture_OLTP.ktr
*/
-- Trigger previously named step_instance_stg_TRG
CREATE OR REPLACE TRIGGER TRG_BIU_STEP_INSTANCE_STG
BEFORE INSERT OR UPDATE ON STEP_INSTANCE_STG
FOR EACH ROW
BEGIN
  IF INSERTING and :NEW.stage_create_ts IS NULL THEN
	     :NEW.stage_create_ts := SYSDATE;    
  END IF;

  :NEW.stage_update_ts := SYSDATE;
END;
/

alter session set plsql_code_type = interpreted;