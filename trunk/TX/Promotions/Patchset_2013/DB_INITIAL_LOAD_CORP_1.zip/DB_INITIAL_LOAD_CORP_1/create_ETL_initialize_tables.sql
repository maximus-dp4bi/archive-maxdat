-- Create  Common tables for run initialization 
create table GROUPS_STG
(
  group_id            NUMBER(18) not null,
  group_name          VARCHAR2(80),
  description         VARCHAR2(1000),
  parent_group_id     NUMBER(18),
  deployment_name     VARCHAR2(32),
  start_date          DATE,
  end_date            DATE,
  type_cd             VARCHAR2(20),
  supervisor_staff_id NUMBER(18),
  created_by          VARCHAR2(80),
  create_ts           DATE,
  updated_by          VARCHAR2(80),
  update_ts           DATE
)
tablespace MAXDAT_DATA;

alter table GROUPS_STG add constraint GROUP_PK primary key (GROUP_ID)
using index tablespace MAXDAT_INDX;

create or replace public synonym GROUPS_STG for GROUPS_STG;

Grant select on groups_stg to MAXDAT_READ_ONLY;

create table STAFF_STG
(
  staff_id               NUMBER(18) not null,
  ext_staff_number       VARCHAR2(80),
  dob                    DATE,
  ssn                    VARCHAR2(30),
  first_name             VARCHAR2(50),
  first_name_canon       VARCHAR2(50),
  first_name_sound_like  VARCHAR2(64),
  gender_cd              VARCHAR2(32),
  start_date             DATE,
  end_date               DATE,
  phone_number           VARCHAR2(20),
  last_name              VARCHAR2(50),
  last_name_canon        VARCHAR2(50),
  last_name_sound_like   VARCHAR2(64),
  created_by             VARCHAR2(80),
  create_ts              DATE,
  updated_by             VARCHAR2(80),
  update_ts              DATE,
  middle_name            VARCHAR2(25),
  middle_name_canon      VARCHAR2(20),
  middle_name_sound_like VARCHAR2(64),
  email                  VARCHAR2(80),
  fax_number             VARCHAR2(32),
  note_refid             NUMBER(18),
  deployment_staff_num   VARCHAR2(80),
  default_group_id       NUMBER(18),
  staff_type_cd          VARCHAR2(20),
  unique_staff_id        VARCHAR2(80),
  void_ind               NUMBER(1) default 0
)
tablespace MAXDAT_DATA;
  
  alter table STAFF_STG add constraint STAFF_STG_PK primary key (STAFF_ID)
  using index tablespace MAXDAT_INDX;
  
create or replace public synonym STAFF_STG for STAFF_STG;

Grant select on staff_stg to MAXDAT_READ_ONLY;

create table STEP_DEFINITION_STG
(
  step_definition_id  NUMBER(18) not null,
  name                VARCHAR2(100),
  description         VARCHAR2(4000),
  time_to_complete    NUMBER(9),
  time_unit_cd        VARCHAR2(32),
  forwarding_rule_cd  VARCHAR2(32),
  escalation_rule_cd  VARCHAR2(32),
  priority_cd         VARCHAR2(32),
  perform_timeout_ind NUMBER(1),
  step_type_cd        VARCHAR2(32),
  created_by          VARCHAR2(80),
  create_ts           DATE,
  updated_by          VARCHAR2(80),
  update_ts           DATE,
  manual_task_ind     NUMBER(1),
  spring_bean         VARCHAR2(256),
  correlation_parts   VARCHAR2(4000)
)
tablespace MAXDAT_DATA;

alter table STEP_DEFINITION_STG
  add constraint XPKSTEP_DEFINITION_STG primary key (STEP_DEFINITION_ID)
  using index tablespace MAXDAT_INDX;
  
create or replace public synonym STEP_DEFINITION_STG for STEP_DEFINITION_STG;  

Grant select on step_definition_stg to MAXDAT_READ_ONLY;

create table  STEP_INSTANCE_STG
(
  step_instance_id         NUMBER not null,
  step_instance_history_id NUMBER not null,
  status                   VARCHAR2(32),
  hist_status              VARCHAR2(32),
  create_ts                DATE,
  completed_ts             DATE,
  escalated_ind            NUMBER,
  hist_escalated_ind       NUMBER,
  step_due_ts              DATE,
  forwarded_ind            NUMBER,
  hist_forwarded_ind       NUMBER,
  group_id                 NUMBER,
  hist_group_id            NUMBER,
  team_id                  NUMBER,
  hist_team_id             NUMBER,
  ref_id                   NUMBER,
  ref_type                 VARCHAR2(64),
  step_definition_id       NUMBER,
  created_by               VARCHAR2(80),
  hist_create_by           VARCHAR2(80),
  escalate_to              VARCHAR2(80),
  hist_escalate_to         VARCHAR2(80),
  forwarded_by             VARCHAR2(80),
  hist_forwarded_by        VARCHAR2(80),
  owner                    VARCHAR2(80),
  hist_owner               VARCHAR2(80),
  suspended_ts             DATE,
  hist_create_ts           DATE,
  mw_processed             VARCHAR2(1) default 'N',
  ap_processed             VARCHAR2(1) default 'N',
  mib_processed            VARCHAR2(1) default 'N',
  all_proc_done_date       DATE,
  stage_create_ts          DATE,
  mi_processed             VARCHAR2(1) default 'N',
  sr_processed             VARCHAR2(1) default 'N',
  tp_processed             VARCHAR2(1) default 'N',
  ir_processed             VARCHAR2(1) default 'N',
  case_id                  NUMBER(18),
  client_id                NUMBER(18),
  priority                 VARCHAR2(50),
  stage_update_ts          DATE
)
tablespace MAXDAT_DATA;

create index  STEP_INS_INDX1             on STEP_INSTANCE_STG (REF_ID, REF_TYPE, STATUS) TABLESPACE MAXDAT_INDX;
create index  STEP_INS_INDX2             on STEP_INSTANCE_STG (STEP_INSTANCE_ID)         TABLESPACE MAXDAT_INDX;
create index  STEP_INS_INDX3             on STEP_INSTANCE_STG (STEP_INSTANCE_HISTORY_ID) TABLESPACE MAXDAT_INDX;
create index IDX_STEP_INST_STG_case_id   on STEP_INSTANCE_STG (case_id)                  TABLESPACE MAXDAT_INDX;
create index IDX_STEP_INST_STG_client_id on STEP_INSTANCE_STG (client_id)                TABLESPACE MAXDAT_INDX;

alter table  STEP_INSTANCE_STG
  add constraint STEP_INSTANCE_STG_PK primary key (STEP_INSTANCE_ID, STEP_INSTANCE_HISTORY_ID)
  using index tablespace MAXDAT_INDX;


create or replace public synonym STEP_INSTANCE_STG for STEP_INSTANCE_STG;  

Grant select on step_instance_stg to MAXDAT_READ_ONLY; 

CREATE TABLE GROUP_STEP_DEFINITION_STG
(
  GROUP_STEP_DEFINITION_ID NUMBER(18, 0) NOT NULL 
, EFFECTIVE_START_TS DATE 
, EFFECTIVE_END_TS DATE 
, FORWARDING_RULE_CD VARCHAR2(32 BYTE) 
, ESCALATION_RULE_CD VARCHAR2(32 BYTE) 
, GROUP_ID NUMBER(18, 0) 
, STEP_DEFINITION_ID NUMBER(18, 0) 
, CREATED_BY VARCHAR2(80 BYTE) 
, CREATE_TS DATE 
, UPDATED_BY VARCHAR2(80 BYTE) 
, UPDATE_TS DATE 
)
tablespace MAXDAT_DATA;

alter table  GROUP_STEP_DEFINITION_STG
  add constraint XPKGROUP_STEP_DEFINITION primary key (GROUP_STEP_DEFINITION_ID)
  using index tablespace MAXDAT_INDX;

create or replace public synonym GROUP_STEP_DEFINITION_STG for GROUP_STEP_DEFINITION_STG;

Grant select on GROUP_STEP_DEFINITION_STG to MAXDAT_READ_ONLY; 

CREATE TABLE GROUP_STEP_DEFN_DEFAULT_STG
(
GROUP_STEP_DEFN_DEFAULT_ID NUMBER(18, 0) NOT NULL
, EFFECTIVE_START_TS DATE
, EFFECTIVE_END_TS DATE
, STEP_DEFINITION_ID NUMBER(18, 0)
, GROUP_STEP_DEFINITION_ID NUMBER(18, 0)
)
tablespace MAXDAT_DATA;

alter table  GROUP_STEP_DEFN_DEFAULT_STG
  add constraint XPKGROUP_STEP_DEFN_DEFAULT primary key (GROUP_STEP_DEFN_DEFAULT_ID)
  using index tablespace MAXDAT_INDX;

create or replace public synonym GROUP_STEP_DEFN_DEFAULT_STG for GROUP_STEP_DEFN_DEFAULT_STG;
Grant select on GROUP_STEP_DEFN_DEFAULT_STG to MAXDAT_READ_ONLY; 

Grant select on groups_stg to MAXDAT_READ_ONLY;
Grant select on staff_stg to MAXDAT_READ_ONLY;


CREATE TABLE LETTERS_STG 
   (	LETTER_ID NUMBER(18,0) NOT NULL ENABLE, 
	LETTER_REQUESTED_ON DATE, 
	LETTER_STATUS_CD VARCHAR2(32 BYTE), 
	LETTER_STATUS VARCHAR2(256 BYTE), 
	LETTER_CREATE_TS DATE, 
	LETTER_UPDATE_TS DATE, 
	LETTER_SENT_ON DATE, 
	PROGRAM_CODE VARCHAR2(32 BYTE), 
	PROGRAM VARCHAR2(50 BYTE), 
	DRIVER_TABLE_NAME VARCHAR2(60 BYTE), 
	LETTER_MAILED_DATE DATE, 
	LETTER_REJECT_REASON_CD VARCHAR2(32 BYTE), 
	LETTER_REJECT_REASON VARCHAR2(100 BYTE), 
	LETTER_PRINTED_ON DATE, 
	LETTER_ERROR_CODES VARCHAR2(4000 BYTE), 
	RESIDENCE_COUNTY VARCHAR2(64 BYTE), 
	RESIDENCE_ZIP_CODE VARCHAR2(32 BYTE), 
	LETTER_CASE_ID NUMBER(18,0), 
	LETTER_PARENT_LMREQ_ID NUMBER(18,0), 
	LETTER_REF_TYPE VARCHAR2(40 BYTE), 
	LETTER_TYPE_CD VARCHAR2(40 BYTE), 
	LETTER_TYPE VARCHAR2(100 BYTE), 
	LETTER_REQUEST_TYPE VARCHAR2(2 BYTE), 
	LETTER_LANG_CD VARCHAR2(32 BYTE), 
	LANGUAGE VARCHAR2(20 BYTE), 
	LETTER_DRIVER_TYPE VARCHAR2(4 BYTE), 
	LET_MATERIAL_REQUEST_ID NUMBER(18,0), 
	LETTER_CREATED_BY VARCHAR2(80 BYTE), 
	LETTER_RETURN_REASON_CD VARCHAR2(32 BYTE), 
	RETURN_REASON VARCHAR2(100 BYTE), 
	LETTER_UPDATED_BY VARCHAR2(80 BYTE), 
	LETTER_RETURN_DATE DATE
   )
tablespace MAXDAT_DATA;


CREATE INDEX LETTERS_ID_STG_IDX            ON LETTERS_STG (LETTER_ID)                 TABLESPACE MAXDAT_INDX;
CREATE INDEX LETTERS_REQUEST_TYPE_STG_IDX  ON LETTERS_STG (LETTER_REQUEST_TYPE)       TABLESPACE MAXDAT_INDX;
CREATE INDEX LETTERS_SENT_ON_STG_IDX       ON LETTERS_STG (LETTER_SENT_ON)            TABLESPACE MAXDAT_INDX;
CREATE INDEX LETTERS_STG_IDX               ON LETTERS_STG (LETTER_TYPE_CD, LETTER_ID) TABLESPACE MAXDAT_INDX;
CREATE INDEX LETTERS_TYPE_CD_STG_IDX       ON LETTERS_STG (LETTER_TYPE_CD)            TABLESPACE MAXDAT_INDX;


create or replace public synonym LETTERS_STG for LETTERS_STG;  

Grant select on LETTERS_STG to MAXDAT_READ_ONLY;

