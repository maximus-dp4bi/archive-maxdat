-- Corp Client Inquiry

insert into BPM_PROCESS_LKUP (BPROL_ID,NAME,DESCRIPTION) values (13,'Client Inquiry','Client Inbound contacts including web chats (not implemented yet).');

INSERT INTO bpm_source_type_lkup(bstl_id,name) VALUES (9,'MAXEB ETL');

insert into BPM_SOURCE_LKUP (BSL_ID,NAME,BSTL_ID) values (13,'CORP_ETL_CLIENT_INQUIRY',9);

insert into PROCESS_BPM_QUEUE_JOB_CONFIG (PBQJC_ID,BSL_ID,BDM_ID,ENABLED) values (SEQ_PBQJC_ID.nextval,13,1,'Y');
insert into PROCESS_BPM_QUEUE_JOB_CONFIG (PBQJC_ID,BSL_ID,BDM_ID,ENABLED) values (SEQ_PBQJC_ID.nextval,13,2,'Y');

-- For triggers
INSERT INTO bpm_identifier_type_lkup (bil_id,name) VALUES (13, 'Call Record ID');

commit;