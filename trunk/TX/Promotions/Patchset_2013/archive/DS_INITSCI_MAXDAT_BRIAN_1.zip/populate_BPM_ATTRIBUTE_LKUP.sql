/* Corp Client Inquiry attribute lookup
BDL_ID	DATATYPE
1	NUMBER
2	VARCHAR
3	DATE
*/

INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (650,1,'CECI ID','ETL Table primary key');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (651,1,'Contact Record ID','The unique identifier defined by the source system assigned to call / webchat record.');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (652,2,'Supp Contact Type Cd','Non-monitoring supplementary attribute: Contact Type Code');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (653,2,'Contact Type','Identifies how the contact was initiated (e.g., inbound, outbound or web chat). Identifies how the contact was initiated (e.g., inbound, outbound or web chat). ');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (654,1,'Parent Contact Record ID','The contact record ID of a distinct but related contact record used to link the records together (typcially results from call transfers).  ');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (655,2,'Tracking Number','Reference number that an individual can provide the agent upon contact to expedite lookup. ');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (656,1,'Supp Worker ID','Non-monitoring supplementary attribute: Worker ID');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (657,2,'Supp Worker Name','Non-monitoring supplementary attribute: Woker Name');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (658,2,'Supp Created By','Non-monitoring supplementary attribute: Created By');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (662,3,'Contact Start Time','Date and time that the individual and agent/staff first made contact');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (663,3,'Contact End Time','Date and time that the individual and agent/staff concluded the call/web chat ending contact.');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (664,2,'Supp Contact Group Cd','Non-monitoring supplementary attribute: Contact Group Code');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (665,2,'Contact Group','Categorizes individuals into groups  (e.g., participant, provider, community based organization,etc) ');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (666,2,'Supp Language Cd','Non-monitoring supplementary attribute: Lanuage Code');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (668,2,'Translation Required','Indicates if a translator was needed for the contact.');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (669,2,'External Telephony Reference','External reference field for data passed through IVR/ACD.');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (670,1,'Supp Latest Note ID','Non-monitoring supplementary attribute: Latest Note ID');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (671,2,'Note Category','The category of the note created for the contact, if any.');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (672,2,'Note Type','The note type created for the contact, if any.');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (673,2,'Note Source','The source of the note record created for the contact (the module or function that created the note).');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (674,2,'Note Present','Indentifies whether an associated Call Record Note exists');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (675,2,'Contact Record Field 1','Call Center Module provides project-configurable fields for the Call Record often used to capture non-standard information from the caller per project requirements).   Open Request for Project configurations.');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (676,2,'Contact Record Field 2','Call Center Module provides project-configurable fields for the Call Record often used to capture non-standard information from the caller per project requirements).   Open Request for Project configurations.');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (677,2,'Contact Record Field 3','Call Center Module provides project-configurable fields for the Call Record often used to capture non-standard information from the caller per project requirements).   Open Request for Project configurations.');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (678,2,'Contact Record Field 4','Call Center Module provides project-configurable fields for the Call Record often used to capture non-standard information from the caller per project requirements).   Open Request for Project configurations.');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (679,2,'Contact Record Field 5','Call Center Module provides project-configurable fields for the Call Record often used to capture non-standard information from the caller per project requirements).   Open Request for Project configurations.');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (685,2,'Supp Updated By','Non-monitoring supplementary attribute: Updated By');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (686,2,'Last Update By Name ','The person or potentially a "system" job name that updated the contact record.');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (687,3,'Last Update Date ','The date/timestamp when the Contact Record was last updated.');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (688,3,'ASSD Handle Contact','Date and time the individual and agent/staff first made contact.set to contact_start_dt.');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (689,3,'ASED Handle Contact','The date/time that handle call/webchat activity step ended. Set to contact_end_dt.');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (690,2,'ASPB Handle Contact','The name of the person/system that completed the Handle Call/Web Chat activity step.');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (691,3,'ASSD Create Route Work','The date/time that the Create and Route Work activity step began.');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (692,3,'ASED Create Route Work','The date/time that the Create and Route Work activity step ended.  Set to the task ID create date. ');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (693,2,'ASF Handle Contact','This step is complete when the staff member completes the call/webchat and marks the contact record complete.');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (694,2,'ASF Create Route Work','This step is complete when the appropriate work has been created and routed by the source system.');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (695,2,'ASF Cancel Contact','A skipped activity step; no rule');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (696,2,'GWF Work Identified','Set when ased_handle_contact is NOT null and gwf_work_identified is null. ');
--INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (697,3,'Cancel_Date','Indicates the date the ETL discovered that the contact record was cancelled or otherwise deleted.');
--INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (698,3,'Stage Update Date','Date ETL instance was last updated');
--INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (699,3,'Stage Extract Date','Date ETL instance was extracted/inserted');
-- TXEB 7/2/13
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (800,2,'Cancel By Unit','The business unit that the staff member who created the contact is assigned to.  ');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (802,2,'Cancel By Role','The default role that the staff member who created the contact is assigned to.');


/* 5/16/13 Since children table are not queued, no lookup required.
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (701,1,'CECID ID','Client DTL primary key');
--INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (702,1,'CECI ID','Foreign key to Client Inquiry');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (703,1,'Contact Record Link ID','The unique identifier of the contact record link assigned to each record linked to the contact id in the source system.');

INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (708,1,'CECIE ID','Client event primary key');
--INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (709,1,'CECI ID','Foreign key to Client Inquiry');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (710,1,'Event ID','The unique identifier for an event associated with the contact Record. ');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (711,2,'Supp Event Created By','The user/system name that created the Event.');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (712,2,'Event Created by Name','The user/system name that created the Event.');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (713,3,'Event Create Date','The date/time when the Event was created.');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (714,2,'Supp Event Type CD','Non-monitoring supplementary attribute: Event Type Code');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (715,2,'Supp Event Context','Non-monitoring supplementary attribute: Event Context');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (716,2,'Event Action','A description (in business terms) of the action that was taken during the call/web chat.  Each EVENT ID can have a corresponding Event Action, but it is not required.');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (717,2,'Manual Action Category','Groups similar Manual Actions. A Manual Action Category will exist for each event where EVENT ACTION = ''MANUAL ACTION''.');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (718,2,'Event Context','The Context field captures additional data related to the Event Action. (i.e. a Task Type, Manual Call Action, etc.)');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (719,1,'Event Reference ID','The primary key / reference ID for the event.');
INSERT INTO bpm_attribute_lkup (BAL_ID,BDL_ID,NAME,PURPOSE)  VALUES (720,2,'Event Reference Type ','The name of the entity whose primary key / reference ID is specified in Event Reference ID');
*/

COMMIT;