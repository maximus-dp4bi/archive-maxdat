--TX PROCESS LETTERS
CREATE TABLE D_PL_CURRENT
  (
    PL_BI_ID                       NUMBER,
    LETTER_REQUEST_ID                   NUMBER NOT NULL,
	CREATE_DATE							DATE NOT NULL,
	CREATED_BY							VARCHAR2(50),
	REQUEST_DATE						DATE,
	INSTANCE_STATUS						VARCHAR2(10) NOT NULL,
	LETTER_TYPE							VARCHAR2(64),
	PROGRAM								VARCHAR2(50),
	CASE_ID								NUMBER,
	COUNTY_CODE							VARCHAR2(10),
	ZIP_CODE							NUMBER,
	LANGUAGE							VARCHAR2(32),
	REPRINT								VARCHAR2(1),
	REQUEST_DRIVER_TYPE					VARCHAR2(10),
	REQUEST_DRIVER_TABLE				VARCHAR2(32),
	LETTER_STATUS				        VARCHAR2(32) NOT NULL,     --history
	LETTER_STATUS_DATE					DATE NOT NULL,             --history
	SENT_DATE							DATE,
	PRINT_DATE							DATE,
	MAILED_DATE							DATE,
	RETURN_DATE							DATE,
	RETURN_REASON						VARCHAR2(100),
	REJECTION_REASON					VARCHAR2(100),
	REQUEST_ERROR_REASON				VARCHAR2(100),
	TRANSMITTED_FILE_NAME				VARCHAR2(100),
	TRANSMITTED_FILE_DATE				DATE,
	LETTER_RESPONSE_FILE_NAME			VARCHAR2(100),
	LETTER_RESPONSE_FILE_DATE			DATE,
	LAST_UPDATE_DATE					DATE,
	LAST_UPDATED_BY_NAME				VARCHAR2(50),
	NEWBORN_FLAG				        VARCHAR2(1) ,
	TASK_ID                   			NUMBER,
	CANCEL_DATE							DATE,
	CANCEL_BY							VARCHAR2(50),
  CANCEL_REASON	VARCHAR2(50 BYTE),
  CANCEL_METHOD	VARCHAR2(50 BYTE),
	COMPLETE_DATE						DATE,
	PROCESS_LTR_REQUEST_START_DATE		DATE,
	PROCESS_LTR_REQUEST_END_DATE		DATE,
	SEND_TO_MAIL_HOUSE_START_DATE		DATE,
	SEND_TO_MAIL_HOUSE_END_DATE			DATE,
	RECEIVE_CONFIRM_START_DATE		DATE,
	RECEIVE_CONFIRM_END_DATE		DATE,
	CREATE_ROUTE_WORK_START_DATE		DATE,
	CREATE_ROUTE_WORK_END_DATE			DATE,
	AGE_IN_BUSINESS_DAYS                NUMBER,
	AGE_IN_CALENDAR_DAYS                NUMBER,
	TIMELINESS_STATUS					VARCHAR2(20),
	JEOPARDY_STATUS				        VARCHAR2(1),
	SLA_CATEGORY				        VARCHAR2(32),
	SLA_DAYS                			VARCHAR2(20),
	SLA_DAYS_TYPE				        VARCHAR2(1),
	SLA_JEOPARDY_DATE					DATE,
	SLA_JEOPARDY_DAYS                	NUMBER,
	SLA_TARGET_DAYS                		NUMBER,
	VALIDATION_FLAG						VARCHAR2(1),
	OUTCOME_FLAG						VARCHAR2(1),
	WORK_REQUIRED_FLAG					VARCHAR2(1),
	PROCESS_LETTERS_FLAG				VARCHAR2(1) NOT NULL,
	TRANSMIT_FLAG			  			VARCHAR2(1) NOT NULL,
	CONFIRMATION_FLAG					VARCHAR2(1) NOT NULL,
	CREATE_ROUTE_WORK_FLAG				VARCHAR2(1) NOT NULL
  );
  
alter table D_PL_CURRENT add constraint DPLCUR_PK primary key (PL_BI_ID);
alter index DPLCUR_PK rebuild tablespace MAXDAT_INDX parallel;

create unique index DPLCUR_UIX1 on D_PL_CURRENT (LETTER_REQUEST_ID) online tablespace MAXDAT_INDX parallel compute statistics; 

create or replace view D_PL_CURRENT_SV as
select * from D_PL_CURRENT
with read only;

-----  D_PL_LETTER_STATUS    DPLLS_ID  
create sequence SEQ_DPLLS_ID
minvalue 1
maxvalue 999999999999999999999999999
start with 265
increment by 1
cache 20;

create table D_PL_LETTER_STATUS
   (
     DPLLS_ID number not null, 
     LETTER_STATUS 			VARCHAR2(50)
   ) parallel;

alter table D_PL_LETTER_STATUS add constraint DPLLS_PK primary key (DPLLS_ID);
alter index DPLLS_PK rebuild tablespace MAXDAT_INDX parallel;

create unique index DPLLS_UIX1 on D_PL_LETTER_STATUS (LETTER_STATUS) tablespace MAXDAT_INDX parallel compute statistics;    

create or replace view D_PL_LETTER_STATUS_SV as
select * from D_PL_LETTER_STATUS
with read only;

create or replace view D_PL_CLIENT_SUB_SV as
select * from CORP_ETL_PROC_LETTERS_CHD
with read only;

insert into D_PL_LETTER_STATUS (DPLLS_ID ,LETTER_STATUS) values (SEQ_DPLLS_ID.nextval,null);
commit;


create sequence SEQ_FPLBD_ID
minvalue 1
maxvalue 999999999999999999999999999
start with 265
increment by 1
cache 20;


  create table F_PL_BY_DATE 
  (FPLBD_ID number not null,
	 D_DATE date not null,
	 BUCKET_START_DATE date not null, 
	 BUCKET_END_DATE date not null,
	 PL_BI_ID number not null, 
	 DPLLS_ID  number not null,
	 INVENTORY_COUNT number,
	 CREATION_COUNT number,
	 COMPLETION_COUNT number,
	 LETTER_STATUS_DATE date)
partition by range (BUCKET_START_DATE)
interval (numtodsinterval(1,'day'))
(partition PT_BUCKET_START_DATE_LT_2012 values less than (to_date('20120101','YYYYMMDD')))   
tablespace MAXDAT_DATA parallel;

alter table F_PL_BY_DATE add constraint FPLBD_PK primary key (FPLBD_ID);
alter index FPLBD_PK rebuild  online tablespace MAXDAT_INDX parallel;

alter table F_PL_BY_DATE add constraint FPLBD_DPLLS_FK foreign key (DPLLS_ID) references D_PL_LETTER_STATUS(DPLLS_ID);
alter table F_PL_BY_DATE add constraint FPLBD_DPLCUR_FK foreign key (PL_BI_ID) references D_PL_CURRENT(PL_BI_ID);

create unique index FPLBD_UIX1 on F_PL_BY_DATE (PL_BI_ID,D_DATE) online tablespace MAXDAT_INDX parallel compute statistics; 
create unique index FPLBD_UIX2 on F_PL_BY_DATE (PL_BI_ID,BUCKET_START_DATE) online tablespace MAXDAT_INDX parallel compute statistics; 
create index FPLBD_IXL1 on F_PL_BY_DATE (BUCKET_END_DATE) local online tablespace MAXDAT_INDX parallel compute statistics;


commit;


create or replace view F_PL_BY_DATE_SV as
select
  FPLBD_ID,
  bdd.D_DATE,
  PL_BI_ID, 
  DPLLS_ID,
  case 
    when dense_rank() over (partition by PL_BI_ID order by PL_BI_ID asc, bdd.D_DATE asc) = 1 then 1
    else 0
    end CREATION_COUNT,
  INVENTORY_COUNT,	 
  COMPLETION_COUNT,
  LETTER_STATUS_DATE
from 
  BPM_D_DATES bdd,
  F_PL_BY_DATE fplbd
where
  bdd.D_DATE >= fplbd.BUCKET_START_DATE 
  and bdd.D_DATE < fplbd.BUCKET_END_DATE
union all
select
  FPLBD_ID,
  bdd.D_DATE,
  PL_BI_ID, 
  DPLLS_ID,
  CREATION_COUNT,
  INVENTORY_COUNT,
  COMPLETION_COUNT,
  LETTER_STATUS_DATE
from 
  BPM_D_DATES bdd,
  F_PL_BY_DATE fplbd
where
  bdd.D_DATE = fplbd.BUCKET_START_DATE 
  and bdd.D_DATE = fplbd.BUCKET_END_DATE
with read only;

commit;   


