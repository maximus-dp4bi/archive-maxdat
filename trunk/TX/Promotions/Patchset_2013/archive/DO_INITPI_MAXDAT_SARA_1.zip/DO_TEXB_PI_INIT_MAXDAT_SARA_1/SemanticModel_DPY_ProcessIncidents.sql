CREATE TABLE D_PI_CURRENT
  (
    "PI_BI_ID"                      NUMBER,
    "Incident ID"                   NUMBER,
    "Incident Tracking Number"      VARCHAR2(32),
    "Receipt Date"                  DATE,
    "Create Date"                   DATE,
    "Created By Group"              VARCHAR2(80),
    "Origin ID"                     NUMBER,
    CHANNEL                         VARCHAR2(80),
    "Age in Business Days"          NUMBER,
    "Age in Calendar Days"          NUMBER,
    "Process Client Notification ID" NUMBER,
    "Cur Instance Status"           VARCHAR2(10),
    "Cancel Date"                   DATE,
    "Incident Type"                 VARCHAR2(80),
    "Cur Incident About"            VARCHAR2(80),
    "Cur Incident Reason"           VARCHAR2(80),
   -- "Cur Incident Description"      VARCHAR2(4000), Removed as per Pulin's suggestion 06/05/13
    "About Provider ID"             NUMBER,
    "About Plan Code"               VARCHAR2(32),
    "Cur Incident Status"           VARCHAR2(80),
    "Cur Incident Status Date"      DATE,
    "Status Age in Business Days"   NUMBER,
    "Status Age in Calendar Days"   NUMBER,
    "Cur Jeopardy Status"           VARCHAR(2),
    "Jeopardy Status Date"          DATE,
    "Complete Date"                 DATE,
    "Reported By"                   VARCHAR2(80),
    "Reporter Relationship"         VARCHAR2(64),
    "Case ID"                       NUMBER,
    "Cur Enrollment Status"         VARCHAR2(32),
    PRIORITY                        VARCHAR2(256),
    PROGRAM                         VARCHAR2(32),
    "Sub-Program"                   VARCHAR2(32),
    "Cur Last Update Date"          DATE,
    "Cur Last Update By Name"       VARCHAR2(100),
    "Plan Code"                     VARCHAR2(32),
    "Provider ID"                   NUMBER,
    "Action Type"                   VARCHAR2(64),
    --"Action Comments"               CLOB,
    "Resolution Type"               VARCHAR2(64),
    --"Resolution Description"        varchar2(40000), ---Reported from a view
    "Notify Client Flag"            VARCHAR2(1),
    "Process Clnt Notify Start Dt"  DATE,
    "Process Clnt Notify End Dt"    DATE,
    "Process Clnt Notify Flag"      VARCHAR2(1),
    "Escalate Incident Flag"        VARCHAR2(1),
    "Escalate to State Dt"          DATE,
    "Cur Task ID"                   NUMBER,
    "State Received Appeal Date"    DATE,
    "Hearing Date"                  DATE,
    "Selection ID"                  NUMBER,
    "Timeliness Status"             VARCHAR2(20),
    "EB Follow-Up Needed Flag"      VARCHAR2(1),
    "Other Party Name"              VARCHAR2(80),
    "Research Incident St Dt"       DATE,
    "Research Incident End Dt"      DATE,
    "Process Incident St Dt"        DATE,
    "Process Incident End Dt"       DATE,
    "Process Incident Flag"         VARCHAR2(1),
    "Return Incident Flag"          VARCHAR2(1),
    "Complete Incident St Dt"       DATE,
    "Complete Incident End Dt"      DATE,
    "Complete Incident Flag"        VARCHAR2(1),
    "Return to MMS Dt"              DATE,
    "Created By Name"               VARCHAR2(100),
    "Generic Field 1"              VARCHAR2(50),
    "Generic Field 2"              VARCHAR2(50),
    "Generic Field 3"              VARCHAR2(50),
    "Generic Field 4"              VARCHAR2(50),
    "Generic Field 5"              VARCHAR2(50),
    "Enrollee RIN"                VARCHAR2(30),
    "Reporter Name"               VARCHAR2(80),
    "Research Incident Flag"      VARCHAR2(1),
    CANCEL_BY                     VARCHAR2(80),
    CANCEL_METHOD                 VARCHAR2(80),
    CANCEL_REASON                 VARCHAR2(80)
  );
  
alter table D_PI_CURRENT add constraint DPICUR_PK primary key (PI_BI_ID);
alter index DPICUR_PK rebuild tablespace MAXDAT_INDX parallel;

create unique index DPICUR_UIX1 on D_PI_CURRENT ("Incident ID") online tablespace MAXDAT_INDX parallel compute statistics; 

create or replace view D_PI_CURRENT_SV as
select * from D_PI_CURRENT
with read only;

--D_PI_INSTANCE_STATUS    DPIIS_ID  "Instance Status"           VARCHAR2(10),
create sequence SEQ_DPIIS_ID
minvalue 1
maxvalue 999999999999999999999999999
start with 265
increment by 1
cache 20;

create table D_PI_INSTANCE_STATUS 
  (DPIIS_ID number, 
	 "Instance Status"           VARCHAR2(10))
tablespace MAXDAT_DATA parallel;

alter table D_PI_INSTANCE_STATUS add constraint DPIIS_PK primary key (DPIIS_ID);
alter index DPIIS_PK rebuild tablespace MAXDAT_INDX parallel;

create unique index DPIIS_UIX1 on D_PI_INSTANCE_STATUS ("Instance Status") online tablespace MAXDAT_INDX parallel compute statistics; 

create or replace view D_PI_INSTANCE_STATUS_SV as
select * from D_PI_INSTANCE_STATUS
with read only;

insert into D_PI_INSTANCE_STATUS (DPIIS_ID ,"Instance Status") values (SEQ_DPIIS_ID.nextval,null);
commit;

--D_PI_INCIDENT_ABOUT     DPIIA_ID  "Incident About"            VARCHAR2(80),
create sequence SEQ_DPIIA_ID
minvalue 1
maxvalue 999999999999999999999999999
start with 265
increment by 1
cache 20;

create table D_PI_INCIDENT_ABOUT 
  (DPIIA_ID number, 
	 "Incident About"            VARCHAR2(80))
tablespace MAXDAT_DATA parallel;

alter table D_PI_INCIDENT_ABOUT add constraint DPIIA_PK primary key (DPIIA_ID);
alter index DPIIA_PK rebuild tablespace MAXDAT_INDX parallel;

create unique index DPIIA_UIX1 on D_PI_INCIDENT_ABOUT ("Incident About") online tablespace MAXDAT_INDX parallel compute statistics; 

create or replace view D_PI_INCIDENT_ABOUT_SV as
select * from D_PI_INCIDENT_ABOUT
with read only;

insert into D_PI_INCIDENT_ABOUT (DPIIA_ID ,"Incident About") values (SEQ_DPIIA_ID.nextval,null);
commit;

--D_PI_INCIDENT_REASON    DPIIR_ID  "Incident Reason"           VARCHAR2(80),
create sequence SEQ_DPIIR_ID
minvalue 1
maxvalue 999999999999999999999999999
start with 265
increment by 1
cache 20;

create table D_PI_INCIDENT_REASON 
  (DPIIR_ID number, 
	 "Incident Reason"           VARCHAR2(80))
tablespace MAXDAT_DATA parallel;

alter table D_PI_INCIDENT_REASON add constraint DPIIR_PK primary key (DPIIR_ID);
alter index DPIIR_PK rebuild tablespace MAXDAT_INDX parallel;

create unique index DPIIR_UIX1 on D_PI_INCIDENT_REASON ("Incident Reason") online tablespace MAXDAT_INDX parallel compute statistics; 

create or replace view D_PI_INCIDENT_REASON_SV as
select * from D_PI_INCIDENT_REASON
with read only;

insert into D_PI_INCIDENT_REASON (DPIIR_ID ,"Incident Reason") values (SEQ_DPIIR_ID.nextval,null);
commit;

--D_PI_INCIDENT_DESC      DPIID_ID  "Incident Description"      VARCHAR2(4000),
create sequence SEQ_DPIID_ID
minvalue 1
maxvalue 999999999999999999999999999
start with 265
increment by 1
cache 20;

/* create table D_PI_INCIDENT_DESC 
  (DPIID_ID number, 
	 "Incident Description"      VARCHAR2(4000))
tablespace MAXDAT_DATA parallel;

alter table D_PI_INCIDENT_DESC add constraint DPIID_PK primary key (DPIID_ID);
alter index DPIID_PK rebuild tablespace MAXDAT_INDX parallel;

--create unique index DPIID_UIX1 on D_PI_INCIDENT_DESC ("Incident Description") online tablespace MAXDAT_INDX parallel compute statistics; 

create or replace view D_PI_INCIDENT_DESC_SV as
select * from D_PI_INCIDENT_DESC
with read only;

insert into D_PI_INCIDENT_DESC (DPIID_ID ,"Incident Description") values (SEQ_DPIID_ID.nextval,null);
commit; */

--D_PI_INCIDENT_STATUS    DPIISS_ID  "Incident Status"           VARCHAR2(80),
create sequence SEQ_DPIISS_ID
minvalue 1
maxvalue 999999999999999999999999999
start with 265
increment by 1
cache 20;

create table D_PI_INCIDENT_STATUS 
  (DPIISS_ID number, 
	 "Incident Status"           VARCHAR2(80))
tablespace MAXDAT_DATA parallel;

alter table D_PI_INCIDENT_STATUS add constraint DPIISS_PK primary key (DPIISS_ID);
alter index DPIISS_PK rebuild tablespace MAXDAT_INDX parallel;

create unique index DPIISS_UIX1 on D_PI_INCIDENT_STATUS ("Incident Status") online tablespace MAXDAT_INDX parallel compute statistics; 

create or replace view D_PI_INCIDENT_STATUS_SV as
select * from D_PI_INCIDENT_STATUS
with read only;

insert into D_PI_INCIDENT_STATUS (DPIISS_ID ,"Incident Status") values (SEQ_DPIISS_ID.nextval,null);
commit;

--D_PI_JEOPARDY_STATUS    DPIJS_ID  "Jeopardy Status"           VARCHAR(1),
create sequence SEQ_DPIJS_ID
minvalue 1
maxvalue 999999999999999999999999999
start with 265
increment by 1
cache 20;

create table D_PI_JEOPARDY_STATUS 
  (DPIJS_ID number, 
	 "Jeopardy Status"           VARCHAR(2))
tablespace MAXDAT_DATA parallel;

alter table D_PI_JEOPARDY_STATUS add constraint DPIJS_PK primary key (DPIJS_ID);
alter index DPIJS_PK rebuild tablespace MAXDAT_INDX parallel;

create unique index DPIJS_UIX1 on D_PI_JEOPARDY_STATUS ("Jeopardy Status") online tablespace MAXDAT_INDX parallel compute statistics; 

create or replace view D_PI_JEOPARDY_STATUS_SV as
select * from D_PI_JEOPARDY_STATUS
with read only;

insert into D_PI_JEOPARDY_STATUS (DPIJS_ID ,"Jeopardy Status") values (SEQ_DPIJS_ID.nextval,null);
commit;

--D_PI_ENROLLMENT_STATUS  DPIES_ID  "Enrollment Status"         VARCHAR2(32),
create sequence SEQ_DPIES_ID
minvalue 1
maxvalue 999999999999999999999999999
start with 265
increment by 1
cache 20;

create table D_PI_ENROLLMENT_STATUS 
  (DPIES_ID number, 
	 "Enrollment Status"         VARCHAR2(32))
tablespace MAXDAT_DATA parallel;

alter table D_PI_ENROLLMENT_STATUS add constraint DPIES_PK primary key (DPIES_ID);
alter index DPIES_PK rebuild tablespace MAXDAT_INDX parallel;

create unique index DPIES_UIX1 on D_PI_ENROLLMENT_STATUS ("Enrollment Status") online tablespace MAXDAT_INDX parallel compute statistics; 

create or replace view D_PI_ENROLLMENT_STATUS_SV as
select * from D_PI_ENROLLMENT_STATUS
with read only;

insert into D_PI_ENROLLMENT_STATUS (DPIES_ID ,"Enrollment Status") values (SEQ_DPIES_ID.nextval,null);
commit;

--D_PI_LAST_UPDATE_BY     DPIUB_ID  "Last Update By Name"       VARCHAR2(100),
create sequence SEQ_DPIUB_ID
minvalue 1
maxvalue 999999999999999999999999999
start with 265
increment by 1
cache 20;

create table D_PI_LAST_UPDATE_BY 
  (DPIUB_ID number, 
	 "Last Update By Name"       VARCHAR2(100))
tablespace MAXDAT_DATA parallel;

alter table D_PI_LAST_UPDATE_BY add constraint DPIUB_PK primary key (DPIUB_ID);
alter index DPIUB_PK rebuild tablespace MAXDAT_INDX parallel;

create unique index DPIUB_UIX1 on D_PI_LAST_UPDATE_BY ("Last Update By Name") online tablespace MAXDAT_INDX parallel compute statistics; 

create or replace view D_PI_LAST_UPDATE_BY_SV as
select * from D_PI_LAST_UPDATE_BY
with read only;

insert into D_PI_LAST_UPDATE_BY (DPIUB_ID ,"Last Update By Name") values (SEQ_DPIUB_ID.nextval,null);
commit;

--D_PI_TASK_ID            DPITI_ID  "Task ID"                   NUMBER,
create sequence SEQ_DPITI_ID
minvalue 1
maxvalue 999999999999999999999999999
start with 265
increment by 1
cache 20;

create table D_PI_TASK_ID 
  (DPITI_ID                    NUMBER, 
	 "Task ID"                   NUMBER)
tablespace MAXDAT_DATA parallel;

alter table D_PI_TASK_ID add constraint DPITI_PK primary key (DPITI_ID);
alter index DPITI_PK rebuild tablespace MAXDAT_INDX parallel;

create unique index DPITI_UIX1 on D_PI_TASK_ID ("Task ID") online tablespace MAXDAT_INDX parallel compute statistics; 

create or replace view D_PI_TASK_ID_SV as
select * from D_PI_TASK_ID
with read only;

insert into D_PI_TASK_ID (DPITI_ID ,"Task ID") values (SEQ_DPITI_ID.nextval,null);
commit;


create sequence SEQ_FPIBD_ID
minvalue 1
maxvalue 999999999999999999999999999
start with 265
increment by 1
cache 20;

--D_PI_INSTANCE_STATUS    DPIIS_ID  "Instance Status"           VARCHAR2(10),
--D_PI_INCIDENT_ABOUT     DPIIA_ID  "Incident About"            VARCHAR2(80),
--D_PI_INCIDENT_REASON    DPIIR_ID  "Incident Reason"           VARCHAR2(80),
--D_PI_INCIDENT_DESC      DPIID_ID  "Incident Description"      VARCHAR2(4000),
--D_PI_INCIDENT_STATUS    DPIISS_ID  "Incident Status"           VARCHAR2(80),
--    "Incident Status Date"      DATE,
--D_PI_JEOPARDY_STATUS    DPIJS_ID  "Jeopardy Status"           VARCHAR(1),
--D_PI_ENROLLMENT_STATUS  DPIES_ID  "Enrollment Status"         VARCHAR2(32),
--    "Last Update Date"          DATE,
--D_PI_LAST_UPDATE_BY     DPIUB_ID  "Last Update By Name"       VARCHAR2(100),
--D_PI_TASK_ID            DPITI_ID  "Task ID"                   NUMBER,
  create table F_PI_BY_DATE 
  (FPIBD_ID number not null,
	 D_DATE date not null,
	 BUCKET_START_DATE date not null, 
	 BUCKET_END_DATE date not null,
	 PI_BI_ID number not null, 
	 DPIIS_ID number not null, --D_PI_INSTANCE_STATUS    DPIIS_ID
	 DPIIA_ID number not null, --D_PI_INCIDENT_ABOUT     DPIIA_ID
	 DPIIR_ID number not null, --D_PI_INCIDENT_REASON    DPIIR_ID 
	-- DPIID_ID number not null, --D_PI_INCIDENT_DESC      DPIID_ID
   DPIISS_ID number not null, --D_PI_INCIDENT_STATUS    DPIISS_ID
   DPIJS_ID number not null, --D_PI_JEOPARDY_STATUS    DPIJS_ID
   DPIES_ID number not null, --D_PI_ENROLLMENT_STATUS  DPIES_ID 
   DPIUB_ID number not null, --D_PI_LAST_UPDATE_BY     DPIUB_ID 
   DPITI_ID number not null, --D_PI_TASK_ID            DPITI_ID 
	 INVENTORY_COUNT number,
	 CREATION_COUNT number,
	 COMPLETION_COUNT number,
	 "Incident Status Date" date,
	 "Last Update Date" date)
partition by range (BUCKET_START_DATE)
interval (numtodsinterval(1,'day'))
(partition PT_BUCKET_START_DATE_LT_2012 values less than (to_date('20120101','YYYYMMDD')))   
tablespace MAXDAT_DATA parallel;

alter table F_PI_BY_DATE add constraint FPIBD_PK primary key (FPIBD_ID);
alter index FPIBD_PK rebuild  online tablespace MAXDAT_INDX parallel;

create unique index FPIBD_UIX1 on F_PI_BY_DATE (PI_BI_ID,D_DATE) online tablespace MAXDAT_INDX parallel compute statistics; 
create unique index FPIBD_UIX2 on F_PI_BY_DATE (PI_BI_ID,BUCKET_START_DATE) online tablespace MAXDAT_INDX parallel compute statistics; 

create index FPIBD_IX1 on F_PI_BY_DATE ("Incident Status Date") online tablespace MAXDAT_INDX parallel compute statistics;
create index FPIBD_IX2 on F_PI_BY_DATE ("Last Update Date") online tablespace MAXDAT_INDX parallel compute statistics;

create index FPIBD_IXL1 on F_PI_BY_DATE (BUCKET_END_DATE) local online tablespace MAXDAT_INDX parallel compute statistics;

alter table F_PI_BY_DATE add constraint FPIBD_DPICUR_FK
foreign key (PI_BI_ID)references D_PI_CURRENT (PI_BI_ID);

--D_PI_INSTANCE_STATUS    DPIIS_ID  "Instance Status"           VARCHAR2(10),
alter table F_PI_BY_DATE add constraint FPIBD_DPIIS_FK
foreign key (DPIIS_ID) references D_PI_INSTANCE_STATUS (DPIIS_ID);

--D_PI_INCIDENT_ABOUT     DPIIA_ID  "Incident About"            VARCHAR2(80),
alter table F_PI_BY_DATE add constraint FPIBD_DPIIA_FK
foreign key (DPIIA_ID) references D_PI_INCIDENT_ABOUT (DPIIA_ID);

--D_PI_INCIDENT_REASON    DPIIR_ID  "Incident Reason"           VARCHAR2(80),
alter table F_PI_BY_DATE add constraint FPIBD_DPIIR_FK
foreign key (DPIIR_ID) references D_PI_INCIDENT_REASON (DPIIR_ID);

/* --D_PI_INCIDENT_DESC      DPIID_ID  "Incident Description"      VARCHAR2(4000),
alter table F_PI_BY_DATE add constraint FPIBD_DPIID_FK
foreign key (DPIID_ID) references D_PI_INCIDENT_DESC (DPIID_ID); */

--D_PI_INCIDENT_STATUS    DPIISS_ID  "Incident Status"           VARCHAR2(80),
alter table F_PI_BY_DATE add constraint FPIBD_DPIISS_FK
foreign key (DPIISS_ID) references D_PI_INCIDENT_STATUS (DPIISS_ID);

--    "Incident Status Date"      DATE,
--D_PI_JEOPARDY_STATUS    DPIJS_ID  "Jeopardy Status"           VARCHAR(1),
alter table F_PI_BY_DATE add constraint FPIBD_DPIJS_FK
foreign key (DPIJS_ID) references D_PI_JEOPARDY_STATUS (DPIJS_ID);

--D_PI_ENROLLMENT_STATUS  DPIES_ID  "Enrollment Status"         VARCHAR2(32),
alter table F_PI_BY_DATE add constraint FPIBD_DPIES_FK
foreign key (DPIES_ID) references D_PI_ENROLLMENT_STATUS (DPIES_ID);

--    "Last Update Date"          DATE,
--D_PI_LAST_UPDATE_BY     DPIUB_ID  "Last Update By Name"       VARCHAR2(100),
alter table F_PI_BY_DATE add constraint FPIBD_DPIUB_FK
foreign key (DPIUB_ID) references D_PI_LAST_UPDATE_BY (DPIUB_ID);

--D_PI_TASK_ID            DPITI_ID  "Task ID"                   NUMBER,
alter table F_PI_BY_DATE add constraint FPIBD_DPITI_FK
foreign key (DPITI_ID) references D_PI_TASK_ID (DPITI_ID);

create or replace view F_PI_BY_DATE_SV as
select
  FPIBD_ID,
  bdd.D_DATE,
  PI_BI_ID, 
  DPIIS_ID,
  DPIIA_ID,
  DPIIR_ID,
  DPIISS_ID,
  DPIJS_ID,
  DPIES_ID,
  DPIUB_ID,
  DPITI_ID,
  case 
    when dense_rank() over (partition by PI_BI_ID order by PI_BI_ID asc, bdd.D_DATE asc) = 1 then 1
    else 0
    end CREATION_COUNT,
  INVENTORY_COUNT,
  COMPLETION_COUNT, 
  "Incident Status Date",
  "Last Update Date"
from 
  BPM_D_DATES bdd,
  F_PI_BY_DATE fpibd
where
  bdd.D_DATE >= fpibd.BUCKET_START_DATE 
  and bdd.D_DATE < fpibd.BUCKET_END_DATE
union all
select
  FPIBD_ID,
  bdd.D_DATE,
  PI_BI_ID, 
  DPIIS_ID,
  DPIIA_ID,
  DPIIR_ID,
  DPIISS_ID,
  DPIJS_ID,
  DPIES_ID,
  DPIUB_ID,
  DPITI_ID, 
  CREATION_COUNT,
  INVENTORY_COUNT,
  COMPLETION_COUNT, 
  "Incident Status Date",
  "Last Update Date"
from 
  BPM_D_DATES bdd,
  F_PI_BY_DATE fpibd
where
  bdd.D_DATE = fpibd.BUCKET_START_DATE 
  and bdd.D_DATE = fpibd.BUCKET_END_DATE
with read only; 

create or replace view INCIDENT_DESC_SV as
select incident_id, incident_description from corp_etl_process_incidents
with read only;

create or replace view RESOLUTION_DESC_SV as
select incident_id, resolution_description from corp_etl_process_incidents
with read only;