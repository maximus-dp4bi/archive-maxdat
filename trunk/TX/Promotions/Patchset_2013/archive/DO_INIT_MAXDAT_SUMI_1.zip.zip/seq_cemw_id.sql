CREATE SEQUENCE Seq_cemw_Id
/


CREATE OR REPLACE PUBLIC SYNONYM Seq_cemw_Id FOR Seq_cemw_Id;


