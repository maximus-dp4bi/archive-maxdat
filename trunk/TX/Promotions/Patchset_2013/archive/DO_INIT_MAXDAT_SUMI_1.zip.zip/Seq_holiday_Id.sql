CREATE SEQUENCE Seq_holiday_Id
/

CREATE OR REPLACE PUBLIC SYNONYM Seq_holiday_Id FOR Seq_holiday_Id;

