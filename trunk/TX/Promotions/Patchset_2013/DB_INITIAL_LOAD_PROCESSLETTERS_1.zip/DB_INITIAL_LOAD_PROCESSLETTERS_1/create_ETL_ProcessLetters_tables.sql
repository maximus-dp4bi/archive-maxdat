--Process Letters tables

create table CORP_ETL_PROC_LETTERS 
   (	CEPN_ID number not null enable, 
	LETTER_REQUEST_ID number not null enable, 
	CREATE_DT date not null enable, 
	CREATE_BY varchar2(50 byte), 
	REQUEST_DT date, 
	LETTER_TYPE varchar2(100 byte), 
	program varchar2(50 byte), 
	CASE_ID number, 
	COUNTY_CODE varchar2(10 byte), 
	ZIP_CODE number, 
	LANGUAGE varchar2(32 byte), 
	REPRINT varchar2(1 byte), 
	REQUEST_DRIVER_TYPE varchar2(10 byte), 
	REQUEST_DRIVER_TABLE varchar2(32 byte), 
	STATUS varchar2(32 byte) not null enable, 
	STATUS_DT date not null enable, 
	SENT_DT date, 
	PRINT_DT date, 
	MAILED_DT date, 
	RETURN_DT date, 
	RETURN_REASON varchar2(100 byte), 
	REJECT_REASON varchar2(100 byte), 
	ERROR_REASON varchar2(4000 byte), 
	TRANSMIT_FILE_NAME varchar2(100 byte), 
	TRANSMIT_FILE_DT date, 
	LETTER_RESP_FILE_NAME varchar2(100 byte), 
	LETTER_RESP_FILE_DT date, 
	LAST_UPDATE_DT date, 
	LAST_UPDATE_BY_NAME varchar2(50 byte), 
	NEWBORN_FLAG varchar2(1 byte), 
	TASK_ID number, 
	CANCEL_DT date, 
	CANCEL_BY varchar2(50 byte), 
  CANCEL_REASON varchar2(50 byte), 
  CANCEL_METHOD varchar2(50 byte), 
	COMPLETE_DT date, 
	INSTANCE_STATUS varchar2(10 byte) not null enable, 
	ASSD_PROCESS_LETTER_REQ date, 
	ASED_PROCESS_LETTER_REQ date, 
	ASSD_TRANSMIT date, 
	ASED_TRANSMIT date, 
	ASSD_RECEIVE_CONFIRMATION date, 
	ASED_RECEIVE_CONFIRMATION date, 
	ASSD_CREATE_ROUTE_WORK date, 
	ASED_CREATE_ROUTE_WORK date, 
	ASF_PROCESS_LETTER_REQ varchar2(1 byte) not null enable, 
	ASF_TRANSMIT varchar2(1 byte) not null enable, 
	ASF_RECEIVE_CONFIRMATION varchar2(1 byte) not null enable, 
	ASF_CREATE_ROUTE_WORK varchar2(1 byte) not null enable, 
	GWF_VALID varchar2(1 byte), 
	GWF_OUTCOME varchar2(1 byte), 
	GWF_WORK_REQUIRED varchar2(1 byte), 
	STG_EXTRACT_DATE date not null enable, 
	STG_LAST_UPDATE_DATE date not null enable, 
	STAGE_DONE_DATE date) 
tablespace MAXDAT_DATA;
   
alter table CORP_ETL_PROC_LETTERS add constraint CORP_ETL_PROC_LETTERS_PK primary key (CEPN_ID);
alter table CORP_ETL_PROC_LETTERS add constraint CORP_ETL_PROC_LETTERS_ID unique (LETTER_REQUEST_ID);

create index CORP_ETL_PROC_LETTERS_CANC_DT on CORP_ETL_PROC_LETTERS (CANCEL_DT) tablespace MAXDAT_INDX;

create index CORP_ETL_PROC_LETTERS_COMP_DT on CORP_ETL_PROC_LETTERS (COMPLETE_DT) tablespace MAXDAT_INDX;

create index CORP_ETL_PROC_LETTERS_STAT on CORP_ETL_PROC_LETTERS (INSTANCE_STATUS) tablespace MAXDAT_INDX;
  
create or replace public synonym CORP_ETL_PROC_LETTERS for CORP_ETL_PROC_LETTERS;

grant select on CORP_ETL_PROC_LETTERS to MAXDAT_READ_ONLY;


--Process Letter child table 

 create table CORP_ETL_PROC_LETTERS_CHD 
   (	LETTER_REQUEST_ID number, 
	CREATE_DT date, 
	CLIENT_ID number, 
	SUB_PROGRAM varchar2(50 byte)
   ) tablespace MAXDAT_DATA;

create index CORP_ETL_PROC_LETTERS_CHD_IDX1 on CORP_ETL_PROC_LETTERS_CHD (LETTER_REQUEST_ID) tablespace MAXDAT_INDX;

create or replace public synonym CORP_ETL_PROC_LETTERS_CHD for CORP_ETL_PROC_LETTERS_CHD;

grant select on CORP_ETL_PROC_LETTERS_CHD to MAXDAT_READ_ONLY;


--Process Letters child tmp table
 create table CORP_ETL_PROC_LETTERS_CHD_TMP 
   (	LETTER_REQUEST_ID number, 
	CREATE_DT date, 
	CLIENT_ID number, 
	SUB_PROGRAM varchar2(50 byte), 
	REF_ID number
   ) 
  tablespace MAXDAT_DATA ;

  create index CORP_ETL_PROC_LTR_CHD_TMP_IDX1 on CORP_ETL_PROC_LETTERS_CHD_TMP (LETTER_REQUEST_ID) tablespace MAXDAT_INDX ;


create or replace public synonym CORP_ETL_PROC_LETTERS_CHD_TMP for CORP_ETL_PROC_LETTERS_CHD_TMP;

grant select on CORP_ETL_PROC_LETTERS_CHD_TMP to MAXDAT_READ_ONLY;


--Process Letters OLTP 


  create table CORP_ETL_PROC_LETTERS_OLTP 
   (	CEPN_ID number not null enable, 
	LETTER_REQUEST_ID number not null enable, 
	CREATE_DT date not null enable, 
	CREATE_BY varchar2(50 byte), 
	REQUEST_DT date, 
	LETTER_TYPE varchar2(100 byte), 
	program varchar2(50 byte), 
	CASE_ID number, 
	COUNTY_CODE varchar2(10 byte), 
	ZIP_CODE number, 
	LANGUAGE varchar2(32 byte), 
	REPRINT varchar2(1 byte), 
	REQUEST_DRIVER_TYPE varchar2(10 byte), 
	REQUEST_DRIVER_TABLE varchar2(32 byte), 
	STATUS varchar2(32 byte) not null enable, 
	STATUS_DT date not null enable, 
	SENT_DT date, 
	PRINT_DT date, 
	MAILED_DT date, 
	RETURN_DT date, 
	RETURN_REASON varchar2(100 byte), 
	REJECT_REASON varchar2(100 byte), 
	ERROR_REASON varchar2(4000 byte), 
	TRANSMIT_FILE_NAME varchar2(100 byte), 
	TRANSMIT_FILE_DT date, 
	LETTER_RESP_FILE_NAME varchar2(100 byte), 
	LETTER_RESP_FILE_DT date, 
	LAST_UPDATE_DT date, 
	LAST_UPDATE_BY_NAME varchar2(50 byte), 
	NEWBORN_FLAG varchar2(1 byte), 
	TASK_ID number, 
	CANCEL_DT date, 
	CANCEL_BY varchar2(50 byte), 
  CANCEL_REASON varchar2(50 byte), 
  CANCEL_METHOD varchar2(50 byte), 
	COMPLETE_DT date, 
	INSTANCE_STATUS varchar2(10 byte) not null enable, 
	ASSD_PROCESS_LETTER_REQ date, 
	ASED_PROCESS_LETTER_REQ date, 
	ASSD_TRANSMIT date, 
	ASED_TRANSMIT date, 
	ASSD_RECEIVE_CONFIRMATION date, 
	ASED_RECEIVE_CONFIRMATION date, 
	ASSD_CREATE_ROUTE_WORK date, 
	ASED_CREATE_ROUTE_WORK date, 
	ASF_PROCESS_LETTER_REQ varchar2(1 byte) not null enable, 
	ASF_TRANSMIT varchar2(1 byte) not null enable, 
	ASF_RECEIVE_CONFIRMATION varchar2(1 byte) not null enable, 
	ASF_CREATE_ROUTE_WORK varchar2(1 byte) not null enable, 
	GWF_VALID varchar2(1 byte), 
	GWF_OUTCOME varchar2(1 byte), 
	GWF_WORK_REQUIRED varchar2(1 byte), 
	STG_EXTRACT_DATE date not null enable, 
	STG_LAST_UPDATE_DATE date not null enable, 
	STAGE_DONE_DATE date, 
	ERROR_DATE date, 
	STEP_DEFINITION_ID number, 
	TASK_CREATE_DT date)
tablespace MAXDAT_DATA ;

alter table CORP_ETL_PROC_LETTERS_OLTP add constraint CORP_ETL_PROC_LETTERS_OLT_PK primary key (CEPN_ID); 
alter table CORP_ETL_PROC_LETTERS_OLTP add constraint CORP_ETL_PROC_LETTERS_OLTP_ID unique (LETTER_REQUEST_ID);

create or replace public synonym CORP_ETL_PROC_LETTERS_OLTP for CORP_ETL_PROC_LETTERS_OLTP;

grant select on CORP_ETL_PROC_LETTERS_OLTP to MAXDAT_READ_ONLY;


--Process Letters WIP BPM

create table CORP_ETL_PROC_LETTERS_WIP_BPM 
   (	CEPN_ID number not null enable, 
	LETTER_REQUEST_ID number not null enable, 
	CREATE_DT date not null enable, 
	CREATE_BY varchar2(50 byte), 
	REQUEST_DT date, 
	LETTER_TYPE varchar2(100 byte), 
	program varchar2(50 byte), 
	CASE_ID number, 
	COUNTY_CODE varchar2(10 byte), 
	ZIP_CODE number, 
	LANGUAGE varchar2(32 byte), 
	REPRINT varchar2(1 byte), 
	REQUEST_DRIVER_TYPE varchar2(10 byte), 
	REQUEST_DRIVER_TABLE varchar2(32 byte), 
	STATUS varchar2(32 byte) not null enable, 
	STATUS_DT date not null enable, 
	SENT_DT date, 
	PRINT_DT date, 
	MAILED_DT date, 
	RETURN_DT date, 
	RETURN_REASON varchar2(100 byte), 
	REJECT_REASON varchar2(100 byte), 
	ERROR_REASON varchar2(4000 byte), 
	TRANSMIT_FILE_NAME varchar2(100 byte), 
	TRANSMIT_FILE_DT date, 
	LETTER_RESP_FILE_NAME varchar2(100 byte), 
	LETTER_RESP_FILE_DT date, 
	LAST_UPDATE_DT date, 
	LAST_UPDATE_BY_NAME varchar2(50 byte), 
	NEWBORN_FLAG varchar2(1 byte), 
	TASK_ID number, 
	CANCEL_DT date, 
	CANCEL_BY varchar2(50 byte), 
  CANCEL_REASON varchar2(50 byte), 
  CANCEL_METHOD varchar2(50 byte), 
	COMPLETE_DT date, 
	INSTANCE_STATUS varchar2(10 byte) not null enable, 
	ASSD_PROCESS_LETTER_REQ date, 
	ASED_PROCESS_LETTER_REQ date, 
	ASSD_TRANSMIT date, 
	ASED_TRANSMIT date, 
	ASSD_RECEIVE_CONFIRMATION date, 
	ASED_RECEIVE_CONFIRMATION date, 
	ASSD_CREATE_ROUTE_WORK date, 
	ASED_CREATE_ROUTE_WORK date, 
	ASF_PROCESS_LETTER_REQ varchar2(1 byte) not null enable, 
	ASF_TRANSMIT varchar2(1 byte) not null enable, 
	ASF_RECEIVE_CONFIRMATION varchar2(1 byte) not null enable, 
	ASF_CREATE_ROUTE_WORK varchar2(1 byte) not null enable, 
	GWF_VALID varchar2(1 byte), 
	GWF_OUTCOME varchar2(1 byte), 
	GWF_WORK_REQUIRED varchar2(1 byte), 
	STG_EXTRACT_DATE date not null enable, 
	STG_LAST_UPDATE_DATE date not null enable, 
	STAGE_DONE_DATE date, 
	updated varchar2(1 byte))
tablespace MAXDAT_DATA  ;

alter table CORP_ETL_PROC_LETTERS_WIP_BPM add	constraint CORP_ETL_PROC_LETTERS_WIP_PK primary key (CEPN_ID); 
alter table CORP_ETL_PROC_LETTERS_WIP_BPM add constraint CORP_ETL_PROC_LTR_BPM_ID unique (LETTER_REQUEST_ID);

create or replace public synonym CORP_ETL_PROC_LETTERS_WIP_BPM for CORP_ETL_PROC_LETTERS_WIP_BPM;

grant select on CORP_ETL_PROC_LETTERS_WIP_BPM to MAXDAT_READ_ONLY;


