alter session set plsql_code_type = native;

create or replace package MANAGE_WORK as

  -- Do not edit these four SVN_* variable values.  They are populated when you commit code to SVN and used later to identify deployed code.
  SVN_FILE_URL varchar2(200) := '$URL: svn://rcmxapp1d.maximus.com/maxdat/BPM/Corp/ManageWork/createdb/MANAGE_WORK_pkg.sql $'; 
  SVN_REVISION varchar2(20) := '$Revision: 3579 $'; 
  SVN_REVISION_DATE varchar2(60) := '$Date: 2013-07-02 14:12:44 -0500 (Tue, 02 Jul 2013) $'; 
  SVN_REVISION_AUTHOR varchar2(20) := '$Author: mc34742 $';

  -- XML File Data Version
  -- 1 - original (not supported)
  -- 2 - add CDATA wrapper around all values
  -- 3 - CDATA wrapper only around varchar2 values, add STG_LAST_UPDATE_DATE element

  /* 
  select '     ' || 'CEMW_ID varchar2(100),' attr_element from dual  
  union 
  select '     ' || 'STG_LAST_UPDATE_DATE varchar2(19),' attr_element from dual  
  union 
  select 
    case 
      when atc.DATA_TYPE = 'DATE' then '     ' || atc.COLUMN_NAME || ' varchar2(19),'
      when atc.DATA_TYPE = 'VARCHAR2' then '     ' || atc.COLUMN_NAME || ' varchar2(' || atc.DATA_LENGTH || '),'
      else '     ' || atc.COLUMN_NAME || ' varchar2(100),' 
      end attr_element
  from BPM_ATTRIBUTE_STAGING_TABLE bast
  inner join ALL_TAB_COLUMNS atc on (bast.STAGING_TABLE_COLUMN = atc.COLUMN_NAME)
  where 
    bast.BSL_ID = 1
    and atc.TABLE_NAME = 'CORP_ETL_MANAGE_WORK'
  order by attr_element asc;
  */    
  type T_INS_MW_XML is record
    (
     AGE_IN_BUSINESS_DAYS varchar2(100),
     AGE_IN_CALENDAR_DAYS varchar2(100),
     CANCEL_BY varchar2(50),
     CANCEL_METHOD varchar2(50),
     CANCEL_REASON varchar2(256),
     CANCEL_WORK_DATE varchar2(19),
     CANCEL_WORK_FLAG varchar2(1),
     CASE_ID varchar2(100),
     CEMW_ID varchar2(100),
     CLIENT_ID varchar2(100),
     COMPLETE_DATE varchar2(19),
     COMPLETE_FLAG varchar2(1),
     CREATED_BY_NAME varchar2(100),
     CREATE_DATE varchar2(19),
     ESCALATED_FLAG varchar2(1),
     ESCALATED_TO_NAME varchar2(100),
     FORWARDED_BY_NAME varchar2(100),
     FORWARDED_FLAG varchar2(1),
     GROUP_NAME varchar2(100),
     GROUP_PARENT_NAME varchar2(100),
     GROUP_SUPERVISOR_NAME varchar2(100),
     JEOPARDY_FLAG varchar2(1),
     LAST_UPDATE_BY_NAME varchar2(100),
     LAST_UPDATE_DATE varchar2(19),
     OWNER_NAME varchar2(100),
     SLA_DAYS varchar2(100),
     SLA_DAYS_TYPE varchar2(1),
     SLA_JEOPARDY_DAYS varchar2(100),
     SLA_TARGET_DAYS varchar2(100),
     SOURCE_REFERENCE_ID varchar2(100),
     SOURCE_REFERENCE_TYPE varchar2(30),
     STATUS_AGE_IN_BUS_DAYS varchar2(100),
     STATUS_AGE_IN_CAL_DAYS varchar2(100),
     STATUS_DATE varchar2(19),
     STG_LAST_UPDATE_DATE varchar2(19),
     TASK_ID varchar2(100),
     TASK_PRIORITY varchar2(50),     
     TASK_STATUS varchar2(50),
     TASK_TYPE varchar2(100),
     TEAM_NAME varchar2(100),
     TEAM_PARENT_NAME varchar2(100),
     TEAM_SUPERVISOR_NAME varchar2(100),
     TIMELINESS_STATUS varchar2(20),
     UNIT_OF_WORK varchar2(30)
    );
      
  /*
  select '     ' || 'STG_LAST_UPDATE_DATE varchar2(19),' attr_element from dual
  union
  select 
    case 
      when atc.DATA_TYPE = 'DATE' then '     ' || atc.COLUMN_NAME || ' varchar2(19),'
      when atc.DATA_TYPE = 'VARCHAR2' then '     ' || atc.COLUMN_NAME || ' varchar2(' || atc.DATA_LENGTH || '),'
      else '     ' || atc.COLUMN_NAME || ' varchar2(100),' 
      end attr_element
    from BPM_ATTRIBUTE_STAGING_TABLE bast
    inner join ALL_TAB_COLUMNS atc on (bast.STAGING_TABLE_COLUMN = atc.COLUMN_NAME)
    where 
      bast.BSL_ID = 1
      and atc.TABLE_NAME = 'CORP_ETL_MANAGE_WORK' 
    order by attr_element asc;
  */
  type T_UPD_MW_XML is record
    (
     AGE_IN_BUSINESS_DAYS varchar2(100),
     AGE_IN_CALENDAR_DAYS varchar2(100),
     CANCEL_BY varchar2(50),
     CANCEL_METHOD varchar2(50),
     CANCEL_REASON varchar2(256),
     CANCEL_WORK_DATE varchar2(19),
     CANCEL_WORK_FLAG varchar2(1),
     CASE_ID varchar2(100),
     CLIENT_ID varchar2(100),
     COMPLETE_DATE varchar2(19),
     COMPLETE_FLAG varchar2(1),
     CREATED_BY_NAME varchar2(100),
     CREATE_DATE varchar2(19),
     ESCALATED_FLAG varchar2(1),
     ESCALATED_TO_NAME varchar2(100),
     FORWARDED_BY_NAME varchar2(100),
     FORWARDED_FLAG varchar2(1),
     GROUP_NAME varchar2(100),
     GROUP_PARENT_NAME varchar2(100),
     GROUP_SUPERVISOR_NAME varchar2(100),
     JEOPARDY_FLAG varchar2(1),
     LAST_UPDATE_BY_NAME varchar2(100),
     LAST_UPDATE_DATE varchar2(19),
     OWNER_NAME varchar2(100),
     SLA_DAYS varchar2(100),
     SLA_DAYS_TYPE varchar2(1),
     SLA_JEOPARDY_DAYS varchar2(100),
     SLA_TARGET_DAYS varchar2(100),
     SOURCE_REFERENCE_ID varchar2(100),
     SOURCE_REFERENCE_TYPE varchar2(30),
     STATUS_AGE_IN_BUS_DAYS varchar2(100),
     STATUS_AGE_IN_CAL_DAYS varchar2(100),
     STATUS_DATE varchar2(19),
     STG_LAST_UPDATE_DATE varchar2(19),
     TASK_ID varchar2(100),
     TASK_PRIORITY varchar2(50),     
     TASK_STATUS varchar2(50),
     TASK_TYPE varchar2(100),
     TEAM_NAME varchar2(100),
     TEAM_PARENT_NAME varchar2(100),
     TEAM_SUPERVISOR_NAME varchar2(100),
     TIMELINESS_STATUS varchar2(20),
     UNIT_OF_WORK varchar2(30)
    );
    
  procedure INSERT_BPM_EVENT
    (p_data_version in number,
     p_new_data_xml in xmltype,
     p_bue_id out number);
     
  procedure INSERT_BPM_SEMANTIC
    (p_data_version in number,
     p_new_data_xml in xmltype);
     
  procedure UPDATE_BPM_EVENT
    (p_data_version in number,
     p_old_data_xml in xmltype,
     p_new_data_xml in xmltype,
     p_bue_id out number);
     
  procedure UPDATE_BPM_SEMANTIC
    (p_data_version in number,
     p_old_data_xml in xmltype,
     p_new_data_xml in xmltype);
     
end;
/


create or replace package body MANAGE_WORK as

  v_bem_id number := 1; -- 'OPS Manage Work'
  v_bil_id number := 3; -- 'Task ID'
  v_bsl_id number := 1; -- 'CORP_ETL_MANAGE_WORK'
  v_butl_id number := 1; -- 'ETL'
  v_date_bucket_fmt varchar2(21) := 'YYYY-MM-DD';
 
  
  -- Get dimension ID for BPM Semantic model - Manage Work process - Escalated.
  procedure GET_DMWE_ID
    (p_identifier in varchar2,
     p_bi_id in number,
     p_escalated_flag in varchar2,
     p_escalated_to_name varchar2,
     p_dmwe_id out number)
  as
    v_procedure_name varchar2(61) := $$PLSQL_UNIT || '.' || 'GET_DMWE_ID';
    v_sql_code number := null;
    v_log_message clob := null;
  begin
    select DMWE_ID into p_dmwe_id
    from D_MW_ESCALATED
    where 
      ("Escalated Flag" = p_escalated_flag or ("Escalated Flag" is null and p_escalated_flag is null))
      and ("Escalated To Name" = p_escalated_to_name or ("Escalated To Name" is null and p_escalated_to_name is null));
  exception
    when NO_DATA_FOUND then
      p_dmwe_id := SEQ_DMWE_ID.nextval;
      begin
        insert into D_MW_ESCALATED (DMWE_ID,"Escalated Flag","Escalated To Name")
        values (p_dmwe_id,p_escalated_flag,p_escalated_to_name);
        commit;
      exception
        when DUP_VAL_ON_INDEX then
          select DMWE_ID into p_dmwe_id
          from D_MW_ESCALATED
          where 
            ("Escalated Flag" = p_escalated_flag or ("Escalated Flag" is null and p_escalated_flag is null))
            and ("Escalated To Name" = p_escalated_to_name or ("Escalated To Name" is null and p_escalated_to_name is null));
        when OTHERS then
          v_sql_code := SQLCODE;
          v_log_message := SQLERRM;
          BPM_COMMON.LOGGER(BPM_COMMON.LOG_LEVEL_SEVERE,null,v_procedure_name,v_bsl_id,v_bil_id,p_identifier,p_bi_id,null,v_log_message,v_sql_code); 
          raise;
      end;
    when OTHERS then
      v_sql_code := SQLCODE;
      v_log_message := SQLERRM;
      BPM_COMMON.LOGGER(BPM_COMMON.LOG_LEVEL_SEVERE,null,v_procedure_name,v_bsl_id,v_bil_id,p_identifier,p_bi_id,null,v_log_message,v_sql_code); 
      raise;
  end;
  

  -- Get dimension ID for BPM Semantic model - Manage Work process - Forwarded.
  procedure GET_DMWF_ID
    (p_identifier in varchar2,
     p_bi_id in number,
     p_forwarded_by_name in varchar2,
     p_forwarded_flag varchar2,
     p_dmwf_id out number)
  as
    v_procedure_name varchar2(61) := $$PLSQL_UNIT || '.' || 'GET_DMWF_ID';
    v_sql_code number := null;
    v_log_message clob := null;
  begin
    select DMWF_ID into p_dmwf_id
    from D_MW_FORWARDED
    where 
      ("Forwarded By Name" = p_forwarded_by_name or ("Forwarded By Name" is null and p_forwarded_by_name is null))
      and ("Forwarded Flag" = p_forwarded_flag or ("Forwarded Flag" is null and p_forwarded_flag is null));
  exception
    when NO_DATA_FOUND then
      p_dmwf_id := SEQ_DMWF_ID.nextval;
      begin
        insert into D_MW_FORWARDED (DMWF_ID,"Forwarded By Name","Forwarded Flag")
        values (p_dmwf_id,p_forwarded_by_name,p_forwarded_flag);
        commit;
      exception
        when DUP_VAL_ON_INDEX then
          select DMWF_ID into p_dmwf_id
          from D_MW_FORWARDED
          where 
            ("Forwarded By Name" = p_forwarded_by_name or ("Forwarded By Name" is null and p_forwarded_by_name is null))
            and ("Forwarded Flag" = p_forwarded_flag or ("Forwarded Flag" is null and p_forwarded_flag is null));
       when OTHERS then
         v_sql_code := SQLCODE;
         v_log_message := SQLERRM;
         BPM_COMMON.LOGGER(BPM_COMMON.LOG_LEVEL_SEVERE,null,v_procedure_name,v_bsl_id,v_bil_id,p_identifier,p_bi_id,null,v_log_message,v_sql_code); 
         raise;
      end;
    when OTHERS then
      v_sql_code := SQLCODE;
      v_log_message := SQLERRM;
      BPM_COMMON.LOGGER(BPM_COMMON.LOG_LEVEL_SEVERE,null,v_procedure_name,v_bsl_id,v_bil_id,p_identifier,p_bi_id,null,v_log_message,v_sql_code); 
      raise;
  end;
  
  
  -- Get dimension ID for BPM Semantic model - Manage Work process - Last Update By Name.
  procedure GET_DMWLUBN_ID
    (p_identifier in varchar2,
     p_bi_id in number,
     p_last_update_by_name in varchar2,
     p_dmwlubn_id out number)
  as
    v_procedure_name varchar2(61) := $$PLSQL_UNIT || '.' || 'GET_DMWLUBN_ID';
    v_sql_code number := null;
    v_log_message clob := null;
  begin
    select DMWLUBN_ID into p_dmwlubn_id
    from D_MW_LAST_UPDATE_BY_NAME
    where "Last Update By Name" = p_last_update_by_name or ("Last Update By Name" is null and p_last_update_by_name is null);
  exception
    when NO_DATA_FOUND then
      p_dmwlubn_id := SEQ_DMWLUBN_ID.nextval;
      begin
        insert into D_MW_LAST_UPDATE_BY_NAME (DMWLUBN_ID,"Last Update By Name")
        values (p_dmwlubn_id,p_last_update_by_name);
        commit;
      exception
        when DUP_VAL_ON_INDEX then
          select DMWLUBN_ID into p_dmwlubn_id
          from D_MW_LAST_UPDATE_BY_NAME
          where "Last Update By Name" = p_last_update_by_name or ("Last Update By Name" is null and p_last_update_by_name is null);
       when OTHERS then
        v_sql_code := SQLCODE;
        v_log_message := SQLERRM;
        BPM_COMMON.LOGGER(BPM_COMMON.LOG_LEVEL_SEVERE,null,v_procedure_name,v_bsl_id,v_bil_id,p_identifier,p_bi_id,null,v_log_message,v_sql_code); 
        raise;
      end;
    when OTHERS then
      v_sql_code := SQLCODE;
      v_log_message := SQLERRM;
      BPM_COMMON.LOGGER(BPM_COMMON.LOG_LEVEL_SEVERE,null,v_procedure_name,v_bsl_id,v_bil_id,p_identifier,p_bi_id,null,v_log_message,v_sql_code); 
      raise;
  end;

  
  -- Get dimension ID for BPM Semantic model - Manage Work process - Owner.
  procedure GET_DMWO_ID
    (p_identifier in varchar2,
     p_bi_id in number,
     p_owner_name in varchar2,
     p_dmwo_id out number)
  as
    v_procedure_name varchar2(61) := $$PLSQL_UNIT || '.' || 'GET_DMWO_ID';
    v_sql_code number := null;
    v_log_message clob := null;
  begin
    select DMWO_ID into p_dmwo_id
    from D_MW_OWNER
    where "Owner Name" = p_owner_name or ("Owner Name" is null and p_owner_name is null);
  exception
    when NO_DATA_FOUND then
      p_dmwo_id := SEQ_DMWO_ID.nextval;
      begin
        insert into D_MW_OWNER (DMWO_ID,"Owner Name")
        values (p_dmwo_id,p_owner_name);
        commit;
      exception
        when DUP_VAL_ON_INDEX then
          select DMWO_ID into p_dmwo_id
          from D_MW_OWNER
          where "Owner Name" = p_owner_name or ("Owner Name" is null and p_owner_name is null);
        when OTHERS then
         v_sql_code := SQLCODE;
         v_log_message := SQLERRM;
         BPM_COMMON.LOGGER(BPM_COMMON.LOG_LEVEL_SEVERE,null,v_procedure_name,v_bsl_id,v_bil_id,p_identifier,p_bi_id,null,v_log_message,v_sql_code); 
         raise;
      end;
    when OTHERS then
      v_sql_code := SQLCODE;
      v_log_message := SQLERRM;
      BPM_COMMON.LOGGER(BPM_COMMON.LOG_LEVEL_SEVERE,null,v_procedure_name,v_bsl_id,v_bil_id,p_identifier,p_bi_id,null,v_log_message,v_sql_code); 
      raise;
  end;
  
  
  -- Get dimension ID for  BPM Semantic model - Manage Work process - Task Status. 
   procedure GET_DMWTS_ID
    (p_identifier in varchar2,
     p_bi_id in number,
     p_task_status in varchar2,
     p_dmwts_id out number)
  as
    v_procedure_name varchar2(61) := $$PLSQL_UNIT || '.' || 'GET_DMWTS_ID';
    v_sql_code number := null;
    v_log_message clob := null;
  begin
    select DMWTS_ID into p_dmwts_id
    from D_MW_TASK_STATUS
    where "Task Status" = p_task_status or ("Task Status" is null and p_task_status is null);
  exception
    when NO_DATA_FOUND then
      p_dmwts_id := SEQ_DMWTS_ID.nextval;
      begin
        insert into D_MW_TASK_STATUS (DMWTS_ID,"Task Status")
        values (p_dmwts_id,p_task_status);
        commit;
      exception
        when DUP_VAL_ON_INDEX then
          select DMWTS_ID into p_dmwts_id
          from D_MW_TASK_STATUS
          where "Task Status" = p_task_status or ("Task Status" is null and p_task_status is null);       
        when OTHERS then
         v_sql_code := SQLCODE;
         v_log_message := SQLERRM;
         BPM_COMMON.LOGGER(BPM_COMMON.LOG_LEVEL_SEVERE,null,v_procedure_name,v_bsl_id,v_bil_id,p_identifier,p_bi_id,null,v_log_message,v_sql_code); 
         raise;
      end;
    when OTHERS then
      v_sql_code := SQLCODE;
      v_log_message := SQLERRM;
      BPM_COMMON.LOGGER(BPM_COMMON.LOG_LEVEL_SEVERE,null,v_procedure_name,v_bsl_id,v_bil_id,p_identifier,p_bi_id,null,v_log_message,v_sql_code); 
      raise;
  end;
  
  
  -- Get dimension ID for BPM Semantic model - Manage Work process - Task Type
  procedure GET_DMWTT_ID
    (p_identifier in varchar2,
     p_bi_id in number,
     p_group_name in varchar2,
     p_group_parent_name in varchar2,
     p_group_supervisor_name in varchar2,
     p_task_type in varchar2,
     p_team_name in varchar2,
     p_team_parent_name in varchar2,
     p_team_supervisor_name in varchar2,
     p_dmwtt_id out number)
  as
    v_procedure_name varchar2(61) := $$PLSQL_UNIT || '.' || 'GET_DMWTT_ID';
    v_sql_code number := null;
    v_log_message clob := null;
  begin
    select DMWTT_ID into p_dmwtt_id
    from D_MW_TASK_TYPE
    where 
      ("Group Name" = p_group_name or ("Group Name" is null and p_group_name is null))
      and ("Group Parent Name" = p_group_parent_name or ("Group Parent Name" is null and p_group_parent_name is null))
      and ("Group Supervisor Name" = p_group_supervisor_name or ("Group Supervisor Name" is null and p_group_supervisor_name is null))
      and ("Task Type" = p_task_type or ("Task Type" is null and p_task_type is null))
      and ("Team Name" = p_team_name or ("Team Name" is null and p_team_name is null))
      and ("Team Parent Name" = p_team_parent_name or ("Team Parent Name" is null and p_team_parent_name is null))
      and ("Team Supervisor Name" = p_team_supervisor_name or ("Team Supervisor Name" is null and p_team_supervisor_name is null));
  exception
    when NO_DATA_FOUND then
      p_dmwtt_id := SEQ_DMWTT_ID.nextval;
      begin
        insert into D_MW_TASK_TYPE 
          (DMWTT_ID,"Group Name","Group Parent Name","Group Supervisor Name",
           "Task Type","Team Name","Team Parent Name","Team Supervisor Name")
        values 
          (p_dmwtt_id,p_group_name,p_group_parent_name,p_group_supervisor_name,
           p_task_type,p_team_name,p_team_parent_name,p_team_supervisor_name);
        commit;
      exception
        when DUP_VAL_ON_INDEX then
          select DMWTT_ID into p_dmwtt_id
          from D_MW_TASK_TYPE
          where 
            ("Group Name" = p_group_name or ("Group Name" is null and p_group_name is null))
            and ("Group Parent Name" = p_group_parent_name or ("Group Parent Name" is null and p_group_parent_name is null))
            and ("Group Supervisor Name" = p_group_supervisor_name or ("Group Supervisor Name" is null and p_group_supervisor_name is null))
            and ("Task Type" = p_task_type or ("Task Type" is null and p_task_type is null))
            and ("Team Name" = p_team_name or ("Team Name" is null and p_team_name is null))
            and ("Team Parent Name" = p_team_parent_name or ("Team Parent Name" is null and p_team_parent_name is null))
            and ("Team Supervisor Name" = p_team_supervisor_name or ("Team Supervisor Name" is null and p_team_supervisor_name is null));
        when OTHERS then
         v_sql_code := SQLCODE;
         v_log_message := SQLERRM;
         BPM_COMMON.LOGGER(BPM_COMMON.LOG_LEVEL_SEVERE,null,v_procedure_name,v_bsl_id,v_bil_id,p_identifier,p_bi_id,null,v_log_message,v_sql_code); 
         raise;
      end;
    when OTHERS then
      v_sql_code := SQLCODE;
      v_log_message := SQLERRM;
      BPM_COMMON.LOGGER(BPM_COMMON.LOG_LEVEL_SEVERE,null,v_procedure_name,v_bsl_id,v_bil_id,p_identifier,p_bi_id,null,v_log_message,v_sql_code); 
      raise;
  end;


  -- Get record for Manage Work insert data.
  procedure GET_INS_MW_XML
    (p_data_xml in xmltype,
     p_data_record out T_INS_MW_XML)
  as
    v_procedure_name varchar2(61) := $$PLSQL_UNIT || '.' || 'GET_INS_MW_XML';
    v_sql_code number := null;
    v_log_message clob := null;
  begin

    /*
    select '        extractValue(p_data_xml,''/ROWSET/ROW/CEMW_ID'') "' || 'CEMW_ID'|| '",' attr_element from dual
    union
    select '        extractValue(p_data_xml,''/ROWSET/ROW/STG_LAST_UPDATE_DATE'') "' || 'STG_LAST_UPDATE_DATE'|| '",' attr_element from dual
    union 
    select '        extractValue(p_data_xml,''/ROWSET/ROW/' || atc.COLUMN_NAME || ''') "' || atc.COLUMN_NAME || '",' attr_element
    from BPM_ATTRIBUTE_STAGING_TABLE bast
    inner join ALL_TAB_COLUMNS atc on (bast.STAGING_TABLE_COLUMN = atc.COLUMN_NAME)
    where 
      bast.BSL_ID = 1
      and atc.TABLE_NAME = 'CORP_ETL_MANAGE_WORK'
    order by attr_element asc;
    */
    select
        extractValue(p_data_xml,'/ROWSET/ROW/AGE_IN_BUSINESS_DAYS') "AGE_IN_BUSINESS_DAYS",
        extractValue(p_data_xml,'/ROWSET/ROW/AGE_IN_CALENDAR_DAYS') "AGE_IN_CALENDAR_DAYS",
        extractValue(p_data_xml,'/ROWSET/ROW/CANCEL_BY') "CANCEL_BY",
        extractValue(p_data_xml,'/ROWSET/ROW/CANCEL_METHOD') "CANCEL_METHOD",
        extractValue(p_data_xml,'/ROWSET/ROW/CANCEL_REASON') "CANCEL_REASON",
        extractValue(p_data_xml,'/ROWSET/ROW/CANCEL_WORK_DATE') "CANCEL_WORK_DATE",
        extractValue(p_data_xml,'/ROWSET/ROW/CANCEL_WORK_FLAG') "CANCEL_WORK_FLAG",
        extractValue(p_data_xml,'/ROWSET/ROW/CASE_ID') "CASE_ID",
        extractValue(p_data_xml,'/ROWSET/ROW/CEMW_ID') "CEMW_ID",
        extractValue(p_data_xml,'/ROWSET/ROW/CLIENT_ID') "CLIENT_ID",
        extractValue(p_data_xml,'/ROWSET/ROW/COMPLETE_DATE') "COMPLETE_DATE",
        extractValue(p_data_xml,'/ROWSET/ROW/COMPLETE_FLAG') "COMPLETE_FLAG",
        extractValue(p_data_xml,'/ROWSET/ROW/CREATED_BY_NAME') "CREATED_BY_NAME",
        extractValue(p_data_xml,'/ROWSET/ROW/CREATE_DATE') "CREATE_DATE",
        extractValue(p_data_xml,'/ROWSET/ROW/ESCALATED_FLAG') "ESCALATED_FLAG",
        extractValue(p_data_xml,'/ROWSET/ROW/ESCALATED_TO_NAME') "ESCALATED_TO_NAME",
        extractValue(p_data_xml,'/ROWSET/ROW/FORWARDED_BY_NAME') "FORWARDED_BY_NAME",
        extractValue(p_data_xml,'/ROWSET/ROW/FORWARDED_FLAG') "FORWARDED_FLAG",
        extractValue(p_data_xml,'/ROWSET/ROW/GROUP_NAME') "GROUP_NAME",
        extractValue(p_data_xml,'/ROWSET/ROW/GROUP_PARENT_NAME') "GROUP_PARENT_NAME",
        extractValue(p_data_xml,'/ROWSET/ROW/GROUP_SUPERVISOR_NAME') "GROUP_SUPERVISOR_NAME",
        extractValue(p_data_xml,'/ROWSET/ROW/JEOPARDY_FLAG') "JEOPARDY_FLAG",
        extractValue(p_data_xml,'/ROWSET/ROW/LAST_UPDATE_BY_NAME') "LAST_UPDATE_BY_NAME",
        extractValue(p_data_xml,'/ROWSET/ROW/LAST_UPDATE_DATE') "LAST_UPDATE_DATE",
        extractValue(p_data_xml,'/ROWSET/ROW/OWNER_NAME') "OWNER_NAME",
        extractValue(p_data_xml,'/ROWSET/ROW/SLA_DAYS') "SLA_DAYS",
        extractValue(p_data_xml,'/ROWSET/ROW/SLA_DAYS_TYPE') "SLA_DAYS_TYPE",
        extractValue(p_data_xml,'/ROWSET/ROW/SLA_JEOPARDY_DAYS') "SLA_JEOPARDY_DAYS",
        extractValue(p_data_xml,'/ROWSET/ROW/SLA_TARGET_DAYS') "SLA_TARGET_DAYS",
        extractValue(p_data_xml,'/ROWSET/ROW/SOURCE_REFERENCE_ID') "SOURCE_REFERENCE_ID",
        extractValue(p_data_xml,'/ROWSET/ROW/SOURCE_REFERENCE_TYPE') "SOURCE_REFERENCE_TYPE",
        extractValue(p_data_xml,'/ROWSET/ROW/STATUS_AGE_IN_BUS_DAYS') "STATUS_AGE_IN_BUS_DAYS",
        extractValue(p_data_xml,'/ROWSET/ROW/STATUS_AGE_IN_CAL_DAYS') "STATUS_AGE_IN_CAL_DAYS",
        extractValue(p_data_xml,'/ROWSET/ROW/STATUS_DATE') "STATUS_DATE",
        extractValue(p_data_xml,'/ROWSET/ROW/STG_LAST_UPDATE_DATE') "STG_LAST_UPDATE_DATE",
        extractValue(p_data_xml,'/ROWSET/ROW/TASK_ID') "TASK_ID",
        extractValue(p_data_xml,'/ROWSET/ROW/TASK_PRIORITY') "TASK_PRIORITY",        
        extractValue(p_data_xml,'/ROWSET/ROW/TASK_STATUS') "TASK_STATUS",
        extractValue(p_data_xml,'/ROWSET/ROW/TASK_TYPE') "TASK_TYPE",
        extractValue(p_data_xml,'/ROWSET/ROW/TEAM_NAME') "TEAM_NAME",
        extractValue(p_data_xml,'/ROWSET/ROW/TEAM_PARENT_NAME') "TEAM_PARENT_NAME",
        extractValue(p_data_xml,'/ROWSET/ROW/TEAM_SUPERVISOR_NAME') "TEAM_SUPERVISOR_NAME",
        extractValue(p_data_xml,'/ROWSET/ROW/TIMELINESS_STATUS') "TIMELINESS_STATUS",
        extractValue(p_data_xml,'/ROWSET/ROW/UNIT_OF_WORK') "UNIT_OF_WORK"
    into p_data_record
    from dual;

  exception

    when OTHERS then
      v_sql_code := SQLCODE;
      v_log_message := SQLERRM;
     BPM_COMMON.LOGGER(BPM_COMMON.LOG_LEVEL_SEVERE,null,v_procedure_name,v_bsl_id,v_bil_id,null,null,null,v_log_message,v_sql_code);
      raise;
    
  end;
  

  -- Get record for Manage Work update data XML. 
  procedure GET_UPD_MW_XML
    (p_data_xml in xmltype,
     p_data_record out T_UPD_MW_XML)
  as
    v_procedure_name varchar2(61) := $$PLSQL_UNIT || '.' || 'GET_UPD_MW_XML';
    v_sql_code number := null;
    v_log_message clob := null;
  begin 
  
   /*
   select '      extractValue(p_data_xml,''/ROWSET/ROW/STG_LAST_UPDATE_DATE'') "' || 'STG_LAST_UPDATE_DATE'|| '",' attr_element from dual
   union 
   select '      extractValue(p_data_xml,''/ROWSET/ROW/' || atc.COLUMN_NAME || ''') "' || atc.COLUMN_NAME || '",'
   from BPM_ATTRIBUTE_STAGING_TABLE bast
   inner join ALL_TAB_COLUMNS atc on (bast.STAGING_TABLE_COLUMN = atc.COLUMN_NAME)
   where 
     bast.BSL_ID = 1
     and atc.TABLE_NAME = 'CORP_ETL_MANAGE_WORK' 
    order by attr_element asc;
   */
    select
      extractValue(p_data_xml,'/ROWSET/ROW/AGE_IN_BUSINESS_DAYS') "AGE_IN_BUSINESS_DAYS",
      extractValue(p_data_xml,'/ROWSET/ROW/AGE_IN_CALENDAR_DAYS') "AGE_IN_CALENDAR_DAYS",
      extractValue(p_data_xml,'/ROWSET/ROW/CANCEL_BY') "CANCEL_BY",
      extractValue(p_data_xml,'/ROWSET/ROW/CANCEL_METHOD') "CANCEL_METHOD",
      extractValue(p_data_xml,'/ROWSET/ROW/CANCEL_REASON') "CANCEL_REASON",
      extractValue(p_data_xml,'/ROWSET/ROW/CANCEL_WORK_DATE') "CANCEL_WORK_DATE",
      extractValue(p_data_xml,'/ROWSET/ROW/CANCEL_WORK_FLAG') "CANCEL_WORK_FLAG",
      extractValue(p_data_xml,'/ROWSET/ROW/CASE_ID') "CASE_ID",
      extractValue(p_data_xml,'/ROWSET/ROW/CLIENT_ID') "CLIENT_ID",
      extractValue(p_data_xml,'/ROWSET/ROW/COMPLETE_DATE') "COMPLETE_DATE",
      extractValue(p_data_xml,'/ROWSET/ROW/COMPLETE_FLAG') "COMPLETE_FLAG",
      extractValue(p_data_xml,'/ROWSET/ROW/CREATED_BY_NAME') "CREATED_BY_NAME",
      extractValue(p_data_xml,'/ROWSET/ROW/CREATE_DATE') "CREATE_DATE",
      extractValue(p_data_xml,'/ROWSET/ROW/ESCALATED_FLAG') "ESCALATED_FLAG",
      extractValue(p_data_xml,'/ROWSET/ROW/ESCALATED_TO_NAME') "ESCALATED_TO_NAME",
      extractValue(p_data_xml,'/ROWSET/ROW/FORWARDED_BY_NAME') "FORWARDED_BY_NAME",
      extractValue(p_data_xml,'/ROWSET/ROW/FORWARDED_FLAG') "FORWARDED_FLAG",
      extractValue(p_data_xml,'/ROWSET/ROW/GROUP_NAME') "GROUP_NAME",
      extractValue(p_data_xml,'/ROWSET/ROW/GROUP_PARENT_NAME') "GROUP_PARENT_NAME",
      extractValue(p_data_xml,'/ROWSET/ROW/GROUP_SUPERVISOR_NAME') "GROUP_SUPERVISOR_NAME",
      extractValue(p_data_xml,'/ROWSET/ROW/JEOPARDY_FLAG') "JEOPARDY_FLAG",
      extractValue(p_data_xml,'/ROWSET/ROW/LAST_UPDATE_BY_NAME') "LAST_UPDATE_BY_NAME",
      extractValue(p_data_xml,'/ROWSET/ROW/LAST_UPDATE_DATE') "LAST_UPDATE_DATE",
      extractValue(p_data_xml,'/ROWSET/ROW/OWNER_NAME') "OWNER_NAME",
      extractValue(p_data_xml,'/ROWSET/ROW/SLA_DAYS') "SLA_DAYS",
      extractValue(p_data_xml,'/ROWSET/ROW/SLA_DAYS_TYPE') "SLA_DAYS_TYPE",
      extractValue(p_data_xml,'/ROWSET/ROW/SLA_JEOPARDY_DAYS') "SLA_JEOPARDY_DAYS",
      extractValue(p_data_xml,'/ROWSET/ROW/SLA_TARGET_DAYS') "SLA_TARGET_DAYS",
      extractValue(p_data_xml,'/ROWSET/ROW/SOURCE_REFERENCE_ID') "SOURCE_REFERENCE_ID",
      extractValue(p_data_xml,'/ROWSET/ROW/SOURCE_REFERENCE_TYPE') "SOURCE_REFERENCE_TYPE",
      extractValue(p_data_xml,'/ROWSET/ROW/STATUS_AGE_IN_BUS_DAYS') "STATUS_AGE_IN_BUS_DAYS",
      extractValue(p_data_xml,'/ROWSET/ROW/STATUS_AGE_IN_CAL_DAYS') "STATUS_AGE_IN_CAL_DAYS",
      extractValue(p_data_xml,'/ROWSET/ROW/STATUS_DATE') "STATUS_DATE",
      extractValue(p_data_xml,'/ROWSET/ROW/STG_LAST_UPDATE_DATE') "STG_LAST_UPDATE_DATE",
      extractValue(p_data_xml,'/ROWSET/ROW/TASK_ID') "TASK_ID",
      extractValue(p_data_xml,'/ROWSET/ROW/TASK_PRIORITY') "TASK_PRIORITY",
      extractValue(p_data_xml,'/ROWSET/ROW/TASK_STATUS') "TASK_STATUS",
      extractValue(p_data_xml,'/ROWSET/ROW/TASK_TYPE') "TASK_TYPE",
      extractValue(p_data_xml,'/ROWSET/ROW/TEAM_NAME') "TEAM_NAME",
      extractValue(p_data_xml,'/ROWSET/ROW/TEAM_PARENT_NAME') "TEAM_PARENT_NAME",
      extractValue(p_data_xml,'/ROWSET/ROW/TEAM_SUPERVISOR_NAME') "TEAM_SUPERVISOR_NAME",
      extractValue(p_data_xml,'/ROWSET/ROW/TIMELINESS_STATUS') "TIMELINESS_STATUS",
      extractValue(p_data_xml,'/ROWSET/ROW/UNIT_OF_WORK') "UNIT_OF_WORK"
     into p_data_record
    from dual;

  exception

    when OTHERS then
      v_sql_code := SQLCODE;
      v_log_message := SQLERRM;
      BPM_COMMON.LOGGER(BPM_COMMON.LOG_LEVEL_SEVERE,null,v_procedure_name,v_bsl_id,v_bil_id,null,null,null,v_log_message,v_sql_code);
      raise;
  
  end;
  

  -- Insert fact for BPM Semantic model - Manage Work process. 
  procedure INS_FMWBD
    (p_identifier in varchar2,
     p_start_date in date,
     p_end_date in date,
     p_bi_id in number,
     p_dmwtt_id in number,
     p_dmwe_id in number,
     p_dmwf_id in number,
     p_dmwo_id in number,
     p_dmwts_id in number,
     p_dmwlubn_id in number,
     p_last_update_date in varchar2,
     p_status_date in varchar2,
     p_fmwbd_id out number)
  as
    v_procedure_name varchar2(61) := $$PLSQL_UNIT || '.' || 'INS_FMWBD';
    v_sql_code number := null;
    v_log_message clob := null;
    v_bucket_start_date date := null;
    v_bucket_end_date date := null;
    v_last_update_date date := null;
    v_status_date date := null;
  begin
    v_last_update_date := to_date(p_last_update_date,BPM_COMMON.DATE_FMT);
    v_status_date := to_date(p_status_date,BPM_COMMON.DATE_FMT);
    p_fmwbd_id := SEQ_FMWBD_ID.nextval;
    
    v_bucket_start_date := to_date(to_char(p_start_date,v_date_bucket_fmt),v_date_bucket_fmt);
    if p_end_date is null then
      v_bucket_end_date := to_date(to_char(BPM_COMMON.MAX_DATE,v_date_bucket_fmt),v_date_bucket_fmt);
    else 
      v_bucket_end_date := to_date(to_char(p_end_date,v_date_bucket_fmt),v_date_bucket_fmt);
    end if;
    
    -- Validate fact date ranges.
    if p_start_date < v_bucket_start_date
      or to_date(to_char(p_start_date,v_date_bucket_fmt),v_date_bucket_fmt) > v_bucket_end_date
      or v_bucket_start_date > v_bucket_end_date
      or v_bucket_end_date < v_bucket_start_date
    then
      v_sql_code := -20030;
      v_log_message := 'Attempted to insert invalid fact date range.  ' || 
        'D_DATE = ' || p_start_date || 
        ' BUCKET_START_DATE = ' || to_char(v_bucket_start_date,v_date_bucket_fmt) ||
        ' BUCKET_END_DATE = ' || to_char(v_bucket_end_date,v_date_bucket_fmt);
      BPM_COMMON.LOGGER(BPM_COMMON.LOG_LEVEL_SEVERE,null,v_procedure_name,v_bsl_id,v_bil_id,p_identifier,p_bi_id,null,v_log_message,v_sql_code);
      RAISE_APPLICATION_ERROR(v_sql_code,v_log_message);
    end if;
      
    insert into F_MW_BY_DATE
      (FMWBD_ID,
       D_DATE,
       BUCKET_START_DATE,
       BUCKET_END_DATE,
       MW_BI_ID,
       DMWTT_ID,
       DMWE_ID,
       DMWF_ID,
       DMWO_ID,
       DMWTS_ID,
       DMWLUBN_ID,
       "Last Update Date",
       "Status Date",
       CREATION_COUNT,
       INVENTORY_COUNT,
       COMPLETION_COUNT)
    values
      (p_fmwbd_id,
       p_start_date,
       v_bucket_start_date,
       v_bucket_end_date,
       p_bi_id,
       p_dmwtt_id,
       p_dmwe_id,
       p_dmwf_id,
       p_dmwo_id,
       p_dmwts_id,
       p_dmwlubn_id,
       v_last_update_date,
       v_status_date,
       1,
       case 
         when p_end_date is null then 1
         else 0
         end,
       case 
         when p_end_date is null then 0
         else 1
         end
      );
  exception
    when OTHERS then
      v_sql_code := SQLCODE;
      v_log_message := SQLERRM;
      BPM_COMMON.LOGGER(BPM_COMMON.LOG_LEVEL_SEVERE,null,v_procedure_name,v_bsl_id,v_bil_id,p_identifier,p_bi_id,null,v_log_message,v_sql_code);
      raise;
  end; 
  
  
  -- Insert BPM Event model data.
  procedure INSERT_BPM_EVENT
    (p_data_version in number,
     p_new_data_xml in xmltype,
     p_bue_id out number)
  as
  
    v_procedure_name varchar2(61) := $$PLSQL_UNIT || '.' || 'INSERT_BPM_EVENT';
    v_sql_code number := null;
    v_log_message clob := null;
    
    v_bi_id number := null;
    v_bue_id number := null;
  
    v_identifier varchar2(35) := null;

    v_last_update_date date := null;  
    v_stg_last_update_date date := null;
    v_event_date date := null;
    v_start_date date := null;
    v_end_date date := null;
    
    v_new_data T_INS_MW_XML := null;
    
  begin

    if p_data_version = 2 or p_data_version = 3 then
      GET_INS_MW_XML(p_new_data_xml,v_new_data);
    else
      v_log_message := 'Unsupported BPM_UPDATE_EVENT_QUEUE.DATA_VERSION value "' || p_data_version || '" for Manage Work in procedure ' || v_procedure_name || '.';
      RAISE_APPLICATION_ERROR(-20011,v_log_message);        
    end if;

    v_bi_id := SEQ_BI_ID.nextval;
    v_identifier := v_new_data.TASK_ID;
    v_start_date := to_date(v_new_data.CREATE_DATE,BPM_COMMON.DATE_FMT);
    v_end_date := to_date(coalesce(v_new_data.COMPLETE_DATE,v_new_data.CANCEL_WORK_DATE),BPM_COMMON.DATE_FMT);
    v_last_update_date := to_date(v_new_data.LAST_UPDATE_DATE,BPM_COMMON.DATE_FMT);
    v_stg_last_update_date := to_date(v_new_data.STG_LAST_UPDATE_DATE,BPM_COMMON.DATE_FMT);
    v_event_date := coalesce(v_stg_last_update_date,v_last_update_date);
  
    insert into BPM_INSTANCE 
      (BI_ID,BEM_ID,IDENTIFIER,BIL_ID,BSL_ID,
       START_DATE,END_DATE,SOURCE_ID,CREATION_DATE,LAST_UPDATE_DATE)
    values
      (v_bi_id,v_bem_id,v_identifier,v_bil_id,v_bsl_id,
       v_start_date,v_end_date,to_char(v_new_data.CEMW_ID),v_event_date,v_event_date);

    commit;
  
    v_bue_id := SEQ_BUE_ID.nextval;

    insert into BPM_UPDATE_EVENT
      (BUE_ID,BI_ID,BUTL_ID,EVENT_DATE,BPMS_PROCESSED)
    values
      (v_bue_id,v_bi_id,v_butl_id,v_event_date,'N');
      
       /*   select 'BPM_EVENT.INSERT_BIA(v_bi_id, '||b.ba_id || ','||bl.bdl_id || ',v_new_data.'|| stg.staging_table_column || ',v_start_date,v_bue_id);'
      from bpm_attribute b, bpm_attribute_lkup bl,MAXDAT.bpm_attribute_staging_table stg
      where b.bal_id = bl.bal_id
      and stg.ba_id = b.ba_id
      and b.when_populated in ('CREATE','BOTH')
      and b.bem_id = 1
      and bsl_id = 1
      order by b.ba_id*/
  
    BPM_EVENT.INSERT_BIA(v_bi_id, 1,1,v_new_data.AGE_IN_BUSINESS_DAYS,v_start_date,v_bue_id);
    BPM_EVENT.INSERT_BIA(v_bi_id, 3,3,v_new_data.CANCEL_WORK_DATE,v_start_date,v_bue_id);
    BPM_EVENT.INSERT_BIA(v_bi_id, 5,3,v_new_data.COMPLETE_DATE,v_start_date,v_bue_id);
    BPM_EVENT.INSERT_BIA(v_bi_id, 7,3,v_new_data.CREATE_DATE,v_start_date,v_bue_id);   
    BPM_EVENT.INSERT_BIA(v_bi_id, 8,2,v_new_data.CREATED_BY_NAME,v_start_date,v_bue_id); 
    BPM_EVENT.INSERT_BIA(v_bi_id, 9,2,v_new_data.ESCALATED_FLAG,v_start_date,v_bue_id);     
    BPM_EVENT.INSERT_BIA(v_bi_id,10,2,v_new_data.ESCALATED_TO_NAME,v_start_date,v_bue_id);  
    BPM_EVENT.INSERT_BIA(v_bi_id,11,2,v_new_data.FORWARDED_BY_NAME,v_start_date,v_bue_id);  
    BPM_EVENT.INSERT_BIA(v_bi_id,12,2,v_new_data.FORWARDED_FLAG,v_start_date,v_bue_id); 
    BPM_EVENT.INSERT_BIA(v_bi_id,13,2,v_new_data.GROUP_NAME,v_start_date,v_bue_id);
    BPM_EVENT.INSERT_BIA(v_bi_id,14,2,v_new_data.GROUP_PARENT_NAME,v_start_date,v_bue_id);
    BPM_EVENT.INSERT_BIA(v_bi_id,15,2,v_new_data.GROUP_SUPERVISOR_NAME,v_start_date,v_bue_id); 
    BPM_EVENT.INSERT_BIA(v_bi_id,17,2,v_new_data.LAST_UPDATE_BY_NAME,v_start_date,v_bue_id); 
    BPM_EVENT.INSERT_BIA(v_bi_id,18,3,v_new_data.LAST_UPDATE_DATE,v_start_date,v_bue_id);
    BPM_EVENT.INSERT_BIA(v_bi_id,19,2,v_new_data.OWNER_NAME,v_start_date,v_bue_id);
    BPM_EVENT.INSERT_BIA(v_bi_id,20,1,v_new_data.SLA_DAYS,v_start_date,v_bue_id);
    BPM_EVENT.INSERT_BIA(v_bi_id,21,2,v_new_data.SLA_DAYS_TYPE,v_start_date,v_bue_id);
    BPM_EVENT.INSERT_BIA(v_bi_id,22,1,v_new_data.SLA_JEOPARDY_DAYS,v_start_date,v_bue_id);
    BPM_EVENT.INSERT_BIA(v_bi_id,23,1,v_new_data.SLA_TARGET_DAYS,v_start_date,v_bue_id);  
    BPM_EVENT.INSERT_BIA(v_bi_id,24,1,v_new_data.SOURCE_REFERENCE_ID,v_start_date,v_bue_id);  
    BPM_EVENT.INSERT_BIA(v_bi_id,25,2,v_new_data.SOURCE_REFERENCE_TYPE,v_start_date,v_bue_id); 
    BPM_EVENT.INSERT_BIA(v_bi_id,26,1,v_new_data.STATUS_AGE_IN_BUS_DAYS,v_start_date,v_bue_id); 
    BPM_EVENT.INSERT_BIA(v_bi_id,28,3,v_new_data.STATUS_DATE,v_start_date,v_bue_id);
    BPM_EVENT.INSERT_BIA(v_bi_id,29,1,v_new_data.TASK_ID,v_start_date,v_bue_id);
    BPM_EVENT.INSERT_BIA(v_bi_id,30,2,v_new_data.TASK_STATUS,v_start_date,v_bue_id);
    BPM_EVENT.INSERT_BIA(v_bi_id,31,2,v_new_data.TASK_TYPE,v_start_date,v_bue_id);
    BPM_EVENT.INSERT_BIA(v_bi_id,32,2,v_new_data.TEAM_NAME,v_start_date,v_bue_id);
    BPM_EVENT.INSERT_BIA(v_bi_id,33,2,v_new_data.TEAM_PARENT_NAME,v_start_date,v_bue_id);
    BPM_EVENT.INSERT_BIA(v_bi_id,34,2,v_new_data.TEAM_SUPERVISOR_NAME,v_start_date,v_bue_id);
    BPM_EVENT.INSERT_BIA(v_bi_id,36,2,v_new_data.UNIT_OF_WORK,v_start_date,v_bue_id);

    BPM_EVENT.INSERT_BIA(v_bi_id,1686,1,v_new_data.CLIENT_ID,v_start_date,v_bue_id);
    BPM_EVENT.INSERT_BIA(v_bi_id,1687,1,v_new_data.CASE_ID,v_start_date,v_bue_id);
    
    BPM_EVENT.INSERT_BIA(v_bi_id, 1770,2,v_new_data.CANCEL_METHOD,v_start_date,v_bue_id);
    BPM_EVENT.INSERT_BIA(v_bi_id, 1771,2,v_new_data.CANCEL_REASON,v_start_date,v_bue_id);
    BPM_EVENT.INSERT_BIA(v_bi_id, 1772,2,v_new_data.CANCEL_BY,v_start_date,v_bue_id);
    BPM_EVENT.INSERT_BIA(v_bi_id, 1780,1,v_new_data.TASK_PRIORITY,v_start_date,v_bue_id);
  
    commit;
  
    p_bue_id := v_bue_id;
  
  exception
   
    when OTHERS then
      v_sql_code := SQLCODE;
      v_log_message := SQLERRM;
      BPM_COMMON.LOGGER(BPM_COMMON.LOG_LEVEL_SEVERE,null,v_procedure_name,v_bsl_id,v_bil_id,v_identifier,v_bi_id,null,v_log_message,v_sql_code);
  
  end;
  
  
  -- Insert or update dimension for BPM Semantic model - Manage Work process - Current.
  procedure SET_DMWCUR
      (p_set_type in varchar2,
       p_identifier in varchar2,
       p_bi_id in number,
       p_task_id in varchar2,
       p_age_in_business_days in varchar2,
       p_create_date in varchar2,
       p_complete_date in varchar2,
       p_sla_days in varchar2,
       p_sla_days_type in varchar2,
       p_sla_jeopardy_days in varchar2,
       p_sla_target_days in varchar2,
       p_cancel_work_date in varchar2,
       p_created_by_name in varchar2,
       p_source_reference_id in varchar2,
       p_source_reference_type in varchar2,
       p_status_age_in_bus_days in varchar2,
       p_unit_of_work in varchar2,
       p_cur_escalated_flag in varchar2,
       p_cur_escalated_to_name in varchar2,
       p_cur_forwarded_by_name in varchar2,
       p_cur_forwarded_flag in varchar2,
       p_cur_group_name in varchar2,
       p_cur_group_parent_name in varchar2,
       p_cur_group_supervisor_name in varchar2,
       p_cur_last_update_by_name in varchar2,
       p_cur_owner_name in varchar2,
       p_cur_task_status in varchar2,
       p_cur_task_type in varchar2,
       p_cur_team_name in varchar2,
       p_cur_team_parent_name in varchar2,
       p_cur_team_supervisor_name in varchar2,
       p_cur_last_update_date in varchar2,
       p_cur_status_date in varchar2,
       p_cur_client_id in varchar2,
       p_cur_case_id in varchar2,
       p_cancel_method in varchar2,
       p_cancel_reason in varchar2,
       p_cancel_by in varchar2,
       p_task_priority in varchar2)
  as

    v_procedure_name varchar2(61) := $$PLSQL_UNIT || '.' || 'SET_DMWCUR';
    v_sql_code number := null;
    v_log_message clob := null;
    r_dmwcur D_MW_CURRENT%rowtype := null;
    v_dmwcur_rows number := null;
    
  begin
  
    r_dmwcur."Complete Date" := to_date(p_complete_date,BPM_COMMON.DATE_FMT);
    r_dmwcur."Create Date" := to_date(p_create_date,BPM_COMMON.DATE_FMT);
    r_dmwcur."Current Status Date" := to_date(p_cur_status_date,BPM_COMMON.DATE_FMT);
    if r_dmwcur."Complete Date" is null then
      r_dmwcur."Complete Flag" := 'N';
    else
      r_dmwcur."Complete Flag" := 'Y';    
    end if;
    
    r_dmwcur.MW_BI_ID := p_bi_id;
    r_dmwcur."Task ID" := p_task_id; 
    r_dmwcur."Age in Business Days" := p_age_in_business_days;
    r_dmwcur."Age in Calendar Days" := trunc(nvl(r_dmwcur."Complete Date",sysdate)) - trunc(r_dmwcur."Create Date");
    if (p_sla_days_type = 'B'
        and p_age_in_business_days is not null 
        and p_sla_jeopardy_days is not null 
        and p_age_in_business_days >= p_sla_jeopardy_days)
       or
       (p_sla_days_type = 'C'
         and r_dmwcur."Age in Calendar Days" is not null 
         and p_sla_jeopardy_days is not null 
         and r_dmwcur."Age in Calendar Days" >= p_sla_jeopardy_days) then
          r_dmwcur."Jeopardy Flag" := 'Y';
    else
          r_dmwcur."Jeopardy Flag" := 'N';
    end if;
    r_dmwcur."SLA Days Type" := p_sla_days_type;
    r_dmwcur."SLA Days" := p_sla_days;
    r_dmwcur."SLA Days Type" := p_sla_days_type;
    r_dmwcur."SLA Jeopardy Days" := p_sla_jeopardy_days;
    r_dmwcur."SLA Target Days" := p_sla_target_days;
    if r_dmwcur."Complete Date" is null then
      r_dmwcur."Timeliness Status" := 'Not Complete';
    elsif p_sla_days is null then
      r_dmwcur."Timeliness Status" := 'Not Required';
    elsif (p_sla_days_type = 'B' and p_age_in_business_days > p_sla_days)
          or
          (p_sla_days_type = 'C' and r_dmwcur."Age in Calendar Days" > p_sla_days) then
      r_dmwcur."Timeliness Status" := 'Untimely';
    else
      r_dmwcur."Timeliness Status" := 'Timely';
    end if;
    r_dmwcur."Cancel Work Date" := to_date(p_cancel_work_date,BPM_COMMON.DATE_FMT);
    if r_dmwcur."Cancel Work Date" is null then
      r_dmwcur."Cancel Work Flag" := 'N';
    else
      r_dmwcur."Cancel Work Flag" := 'Y';    
    end if;
    r_dmwcur."Created By Name" := p_created_by_name;
    r_dmwcur."Source Reference ID" := p_source_reference_id;
    r_dmwcur."Source Reference Type" := p_source_reference_type;
    r_dmwcur."Status Age in Business Days" := p_status_age_in_bus_days;
    r_dmwcur."Status Age in Calendar Days" := trunc(nvl(r_dmwcur."Complete Date",sysdate)) - trunc(r_dmwcur."Current Status Date");
    r_dmwcur."Unit of Work" := p_unit_of_work;
    r_dmwcur."Current Escalated Flag" := p_cur_escalated_flag;
    r_dmwcur."Current Escalated To Name" := p_cur_escalated_to_name;
    r_dmwcur."Current Forwarded By Name" := p_cur_forwarded_by_name;
    r_dmwcur."Current Forwarded Flag" := p_cur_forwarded_flag;
    r_dmwcur."Current Group Name" := p_cur_group_name;
    r_dmwcur."Current Group Parent Name" := p_cur_group_parent_name;
    r_dmwcur."Current Group Supervisor Name" := p_cur_group_supervisor_name;
    r_dmwcur."Current Last Update By Name" := p_cur_last_update_by_name;
    r_dmwcur."Current Owner Name" := p_cur_owner_name;
    r_dmwcur."Current Task Status" := p_cur_task_status;
    r_dmwcur."Current Task Type" := p_cur_task_type;
    r_dmwcur."Current Team Name" := p_cur_team_name;
    r_dmwcur."Current Team Parent Name" := p_cur_team_parent_name;
    r_dmwcur."Current Team Supervisor Name" := p_cur_team_supervisor_name;
    r_dmwcur."Current Last Update Date" := to_date(p_cur_last_update_date,BPM_COMMON.DATE_FMT);
    r_dmwcur."Client_ID" :=p_cur_client_id;
    r_dmwcur."Case_ID" :=p_cur_case_id;
    r_dmwcur."Cancel Method"  := p_cancel_method;
    r_dmwcur."Cancel Reason"  := p_cancel_reason;
    r_dmwcur."Cancel By"      := p_cancel_by;
    r_dmwcur.TASK_PRIORITY    := p_task_priority;
   
    if p_set_type = 'INSERT' then
      insert into D_MW_CURRENT
      values r_dmwcur;
    elsif p_set_type = 'UPDATE' then
      update D_MW_CURRENT
      set row = r_dmwcur
      where MW_BI_ID = p_bi_id;
    else
      v_log_message := 'Unexpected p_set_type value "' || p_set_type || '" in procedure ' || v_procedure_name || '.';
      BPM_COMMON.LOGGER(BPM_COMMON.LOG_LEVEL_SEVERE,null,v_procedure_name,v_bsl_id,v_bil_id,p_identifier,p_bi_id,null,v_log_message,v_sql_code);
      RAISE_APPLICATION_ERROR(-20001,v_log_message);
    end if; 
    
  exception
    when OTHERS then
      v_sql_code := SQLCODE;
      v_log_message := SQLERRM;
      BPM_COMMON.LOGGER(BPM_COMMON.LOG_LEVEL_SEVERE,null,v_procedure_name,v_bsl_id,v_bil_id,p_identifier,p_bi_id,null,v_log_message,v_sql_code);
      raise;
  end;
  

  -- Insert BPM Semantic model data.
  procedure INSERT_BPM_SEMANTIC
    (p_data_version in number,
     p_new_data_xml in xmltype)
  as
  
    v_procedure_name varchar2(61) := $$PLSQL_UNIT || '.' || 'INSERT_BPM_SEMANTIC';
    v_sql_code number := null;
    v_log_message clob := null;
    
    v_new_data T_INS_MW_XML := null;
    
    v_bi_id number := null;
    v_identifier varchar2(35) := null;
    
    v_start_date date := null;
    v_end_date date := null;
    
    v_dmwe_id number := null;
    v_dmwf_id number := null;
    v_dmwlubn_id number := null;
    v_dmwlud_id number := null;
    v_dmwo_id number := null;
    v_dmwts_id number := null;
    v_dmwtt_id number := null;
    v_fmwbd_id number := null;
    
  begin

    if p_data_version = 2 or p_data_version = 3 then  
      GET_INS_MW_XML(p_new_data_xml,v_new_data);
    else
      v_log_message := 'Unsupported BPM_UPDATE_EVENT_QUEUE.DATA_VERSION value "' || p_data_version || '" for Manage Work in procedure ' || v_procedure_name || '.';
      RAISE_APPLICATION_ERROR(-20011,v_log_message);        
    end if;

    v_identifier := v_new_data.TASK_ID;
    v_start_date := to_date(v_new_data.CREATE_DATE,BPM_COMMON.DATE_FMT);
    v_end_date := to_date(coalesce(v_new_data.COMPLETE_DATE,v_new_data.CANCEL_WORK_DATE),BPM_COMMON.DATE_FMT);
  
    select BI_ID 
    into v_bi_id
    from BPM_INSTANCE
    where
      IDENTIFIER = v_identifier
      and BEM_ID = v_bem_id
      and BSL_ID = v_bsl_id;

    GET_DMWE_ID(v_identifier,v_bi_id,v_new_data.ESCALATED_FLAG,v_new_data.ESCALATED_TO_NAME,v_dmwe_id);
    GET_DMWF_ID(v_identifier,v_bi_id,v_new_data.FORWARDED_BY_NAME,v_new_data.FORWARDED_FLAG,v_dmwf_id);
    GET_DMWLUBN_ID(v_identifier,v_bi_id,v_new_data.LAST_UPDATE_BY_NAME,v_dmwlubn_id);
    GET_DMWO_ID(v_identifier,v_bi_id,v_new_data.OWNER_NAME,v_dmwo_id);
    GET_DMWTS_ID(v_identifier,v_bi_id,v_new_data.TASK_STATUS,v_dmwts_id);
    GET_DMWTT_ID
      (v_identifier,v_bi_id,v_new_data.GROUP_NAME,v_new_data.GROUP_PARENT_NAME,v_new_data.GROUP_SUPERVISOR_NAME,
       v_new_data.TASK_TYPE,v_new_data.TEAM_NAME,v_new_data.TEAM_PARENT_NAME,v_new_data.TEAM_SUPERVISOR_NAME,v_dmwtt_id);
    
    -- Insert current dimension and fact as a single transaction.
    begin
    
      commit;
    
      SET_DMWCUR
        ('INSERT',v_identifier,v_bi_id,
         v_new_data.TASK_ID,v_new_data.AGE_IN_BUSINESS_DAYS,v_new_data.CREATE_DATE,v_new_data.COMPLETE_DATE,
         v_new_data.SLA_DAYS,v_new_data.SLA_DAYS_TYPE,v_new_data.SLA_JEOPARDY_DAYS,v_new_data.SLA_TARGET_DAYS,
         v_new_data.CANCEL_WORK_DATE,v_new_data.CREATED_BY_NAME,
         v_new_data.SOURCE_REFERENCE_ID,v_new_data.SOURCE_REFERENCE_TYPE,v_new_data.STATUS_AGE_IN_BUS_DAYS,v_new_data.UNIT_OF_WORK,
         v_new_data.ESCALATED_FLAG,v_new_data.ESCALATED_TO_NAME,
         v_new_data.FORWARDED_BY_NAME,v_new_data.FORWARDED_FLAG,
         v_new_data.GROUP_NAME,v_new_data.GROUP_PARENT_NAME,v_new_data.GROUP_SUPERVISOR_NAME,
         v_new_data.LAST_UPDATE_BY_NAME,v_new_data.OWNER_NAME,v_new_data.TASK_STATUS,v_new_data.TASK_TYPE,
         v_new_data.TEAM_NAME,v_new_data.TEAM_PARENT_NAME,v_new_data.TEAM_SUPERVISOR_NAME,
         v_new_data.LAST_UPDATE_DATE,v_new_data.STATUS_DATE,v_new_data.CLIENT_ID,v_new_data.CASE_ID,
         v_new_data.cancel_method,v_new_data.cancel_reason,v_new_data.cancel_by,v_new_data.task_priority);
      
      INS_FMWBD(v_identifier,v_start_date,v_end_date,v_bi_id,v_dmwtt_id,v_dmwe_id,v_dmwf_id,v_dmwo_id,v_dmwts_id,v_dmwlubn_id,v_new_data.LAST_UPDATE_DATE,v_new_data.STATUS_DATE,v_fmwbd_id);
     
      commit;
      
    exception
    
      when OTHERS then
        rollback;
        v_sql_code := SQLCODE;
	      v_log_message := 'Rolled back initial insert for current dimension and fact.  ' || SQLERRM;
        BPM_COMMON.LOGGER(BPM_COMMON.LOG_LEVEL_SEVERE,null,v_procedure_name,v_bsl_id,v_bil_id,v_identifier,v_bi_id,null,v_log_message,v_sql_code);  
        raise;

    end;
    
  exception
    when OTHERS then
      v_sql_code := SQLCODE;
      v_log_message := SQLERRM;
      BPM_COMMON.LOGGER(BPM_COMMON.LOG_LEVEL_SEVERE,null,v_procedure_name,v_bsl_id,v_bil_id,v_identifier,v_bi_id,null,v_log_message,v_sql_code); 
      raise;
    
  end;
  
  
  -- Update fact for BPM Semantic model - Manage Work process. 
  procedure UPD_FMWBD
    (p_identifier in varchar2,
     p_end_date in date,
     p_bi_id in number,
     p_dmwtt_id in number,
     p_dmwe_id in number,
     p_dmwf_id in number,
     p_dmwo_id in number,
     p_dmwts_id in number,
     p_dmwlubn_id in number,
     p_last_update_date in varchar2,
     p_stg_last_update_date in varchar2,
     p_status_date in varchar2,
     p_fmwbd_id out number)
  as
  
    v_procedure_name varchar2(61) := $$PLSQL_UNIT || '.' || 'UPD_FMWBD';
    v_sql_code number := null;
    v_log_message clob := null;
    
    v_fmwbd_id_old number := null;
    v_d_date_old date := null;
    v_stg_last_update_date date := null;
    v_last_update_date date := null;
    v_event_date date := null;
    v_status_date date := null;
    v_creation_count_old number := null;
    v_completion_count_old number := null;
    v_max_d_date date := null;

    v_dmwtt_id   number := null;
    v_dmwe_id    number := null;
    v_dmwf_id    number := null;
    v_dmwo_id    number := null;
    v_dmwts_id   number := null;
    v_dmwlubn_id number := null;
    
    r_fmwbd F_MW_BY_DATE%rowtype := null;
    
  begin
    v_last_update_date := to_date(p_last_update_date,BPM_COMMON.DATE_FMT);
    v_stg_last_update_date := to_date(p_stg_last_update_date,BPM_COMMON.DATE_FMT);
    v_event_date := coalesce(v_stg_last_update_date,v_last_update_date);
    v_status_date := to_date(p_status_date,BPM_COMMON.DATE_FMT);
    
    v_dmwtt_id   := p_dmwtt_id;
    v_dmwe_id    := p_dmwe_id;
    v_dmwf_id    := p_dmwf_id;
    v_dmwo_id    := p_dmwo_id;
    v_dmwts_id   := p_dmwts_id;
    v_dmwlubn_id := p_dmwlubn_id;
    
    with most_recent_fact_bi_id as
      (select 
         max(FMWBD_ID) max_fmwbd_id,
         max(D_DATE) max_d_date
       from F_MW_BY_DATE
       where MW_BI_ID = p_bi_id) 
    select 
      fmwbd.FMWBD_ID,
      fmwbd.D_DATE,
      fmwbd.CREATION_COUNT,
      fmwbd.COMPLETION_COUNT,
      most_recent_fact_bi_id.max_d_date
    into 
      v_fmwbd_id_old,
      v_d_date_old,
      v_creation_count_old,
      v_completion_count_old,
      v_max_d_date
    from 
      F_MW_BY_DATE fmwbd,
      most_recent_fact_bi_id 
    where
     fmwbd.FMWBD_ID = max_fmwbd_id
     and fmwbd.D_DATE = most_recent_fact_bi_id.max_d_date;
     
    -- Do not modify fact table further once an instance has completed ever before.
    if v_completion_count_old >= 1 then
      return;
    end if;
    
    -- Handle case were update to staging table has older event date.
    if v_event_date < v_max_d_date then
      v_event_date := v_max_d_date;
    end if;
    
    if p_end_date is null then
      r_fmwbd.D_DATE := v_event_date;
      r_fmwbd.BUCKET_START_DATE := to_date(to_char(v_event_date,v_date_bucket_fmt),v_date_bucket_fmt);
      r_fmwbd.BUCKET_END_DATE := to_date(to_char(BPM_COMMON.MAX_DATE,v_date_bucket_fmt),v_date_bucket_fmt);
      r_fmwbd.INVENTORY_COUNT := 1;
      r_fmwbd.COMPLETION_COUNT := 0;
    else
    -- Handle case with retroactive complete date by removing facts that have occurred since the complete date.
      if to_date(to_char(p_end_date,v_date_bucket_fmt),v_date_bucket_fmt) < to_date(to_char(v_max_d_date,v_date_bucket_fmt),v_date_bucket_fmt) then
        delete from F_MW_BY_DATE
        where
          MW_BI_ID = p_bi_id
          and BUCKET_START_DATE > to_date(to_char(p_end_date,v_date_bucket_fmt),v_date_bucket_fmt);
    with most_recent_fact_bi_id as
      (select
         max(FMWBD_ID) max_fmwbd_id,
         max(D_DATE) max_d_date
         from F_MW_BY_DATE
         where MW_BI_ID = p_bi_id)
        select
          fmwbd.FMWBD_ID,
          fmwbd.D_DATE,
          fmwbd.CREATION_COUNT,
          fmwbd.COMPLETION_COUNT,
          most_recent_fact_bi_id.max_d_date,
          fmwbd.DMWTT_ID,
          fmwbd.DMWE_ID,
          fmwbd.DMWF_ID,	
          fmwbd.DMWO_ID,
          fmwbd.DMWTS_ID,
          fmwbd.DMWLUBN_ID
          into
          v_fmwbd_id_old,
          v_d_date_old,
          v_creation_count_old,
          v_completion_count_old,
          v_max_d_date,
          v_dmwtt_id,
          v_dmwe_id,
          v_dmwf_id,
          v_dmwo_id,
          v_dmwts_id,
          v_dmwlubn_id
         from
          F_MW_BY_DATE fmwbd,
          most_recent_fact_bi_id
        where
          fmwbd.FMWBD_ID = max_fmwbd_id
          and fmwbd.D_DATE = most_recent_fact_bi_id.max_d_date;
      end if;
    
      r_fmwbd.D_DATE := p_end_date;
      r_fmwbd.BUCKET_START_DATE := to_date(to_char(p_end_date,v_date_bucket_fmt),v_date_bucket_fmt);
      r_fmwbd.BUCKET_END_DATE := r_fmwbd.BUCKET_START_DATE;
      r_fmwbd.INVENTORY_COUNT := 0;
      r_fmwbd.COMPLETION_COUNT := 1;
    end if;

    p_fmwbd_id := SEQ_FMWBD_ID.nextval;
    r_fmwbd.FMWBD_ID := p_fmwbd_id;
    r_fmwbd.MW_BI_ID := p_bi_id;
    r_fmwbd.DMWTT_ID := v_dmwtt_id;
    r_fmwbd.DMWE_ID := v_dmwe_id;
    r_fmwbd.DMWF_ID := v_dmwf_id;
    r_fmwbd.DMWO_ID := v_dmwo_id;
    r_fmwbd.DMWTS_ID := v_dmwts_id;
    r_fmwbd.DMWLUBN_ID := v_dmwlubn_id;
    r_fmwbd."Last Update Date" := v_last_update_date;
    r_fmwbd."Status Date" := v_status_date;
    r_fmwbd.CREATION_COUNT := 0;
    
    -- Validate fact date ranges.
    if r_fmwbd.D_DATE < r_fmwbd.BUCKET_START_DATE
      or to_date(to_char(r_fmwbd.D_DATE,v_date_bucket_fmt),v_date_bucket_fmt) > r_fmwbd.BUCKET_END_DATE
      or r_fmwbd.BUCKET_START_DATE > r_fmwbd.BUCKET_END_DATE
      or r_fmwbd.BUCKET_END_DATE < r_fmwbd.BUCKET_START_DATE
    then
      v_sql_code := -20030;
      v_log_message := 'Attempted to insert invalid fact date range.  ' || 
        'D_DATE = ' || r_fmwbd.D_DATE || 
        ' BUCKET_START_DATE = ' || to_char(r_fmwbd.BUCKET_START_DATE,v_date_bucket_fmt) ||
        ' BUCKET_END_DATE = ' || to_char(r_fmwbd.BUCKET_END_DATE,v_date_bucket_fmt);
      BPM_COMMON.LOGGER(BPM_COMMON.LOG_LEVEL_SEVERE,null,v_procedure_name,v_bsl_id,v_bil_id,p_identifier,p_bi_id,null,v_log_message,v_sql_code);
      RAISE_APPLICATION_ERROR(v_sql_code,v_log_message);
    end if;
   
    
    if to_date(to_char(v_d_date_old,v_date_bucket_fmt),v_date_bucket_fmt) = r_fmwbd.BUCKET_START_DATE then
      -- Same bucket time.
      if v_creation_count_old = 1 then
        r_fmwbd.CREATION_COUNT := v_creation_count_old;
      end if;
      update F_MW_BY_DATE
      set row = r_fmwbd
      where FMWBD_ID = v_fmwbd_id_old;
    else
      -- Different bucket time.
      update F_MW_BY_DATE
      set BUCKET_END_DATE = r_fmwbd.BUCKET_START_DATE
      where FMWBD_ID = v_fmwbd_id_old;
      
      insert into F_MW_BY_DATE
      values r_fmwbd;
    end if;
  
  exception
    when OTHERS then
      v_sql_code := SQLCODE;
      v_log_message := SQLERRM;
      BPM_COMMON.LOGGER(BPM_COMMON.LOG_LEVEL_SEVERE,null,v_procedure_name,v_bsl_id,v_bil_id,p_identifier,p_bi_id,null,v_log_message,v_sql_code); 
      raise;
  end; 


  -- Update BPM Event model data.
  procedure UPDATE_BPM_EVENT
    (p_data_version in number,
     p_old_data_xml in xmltype,
     p_new_data_xml in xmltype,
     p_bue_id out number)
  as

    v_procedure_name varchar2(61) := $$PLSQL_UNIT || '.' || 'UPDATE_BPM_EVENT';  
    v_sql_code number := null;
    v_log_message clob := null;
    
    v_be_id number := null;
    v_bi_id number := null;
    v_bue_id number := null;
  
    v_identifier varchar2(35) := null;
  
    v_start_date date := null;
    v_end_date date := null;
    v_last_update_date date := null;
    v_stg_last_update_date date := null;
    v_event_date date := null;

    v_old_data T_UPD_MW_XML := null;
    v_new_data T_UPD_MW_XML := null;

  begin
    
    if p_data_version = 2 or p_data_version = 3 then
      GET_UPD_MW_XML(p_old_data_xml,v_old_data);
      GET_UPD_MW_XML(p_new_data_xml,v_new_data);
    else
      v_log_message := 'Unsupported BPM_UPDATE_EVENT_QUEUE.DATA_VERSION value "' || p_data_version || '" for Manage Work in procedure ' || v_procedure_name || '.';
      RAISE_APPLICATION_ERROR(-20011,v_log_message);        
    end if;
    
    v_identifier := v_new_data.TASK_ID;
    v_end_date := to_date(coalesce(v_new_data.COMPLETE_DATE,v_new_data.CANCEL_WORK_DATE),BPM_COMMON.DATE_FMT);
    v_last_update_date := to_date(v_new_data.LAST_UPDATE_DATE,BPM_COMMON.DATE_FMT);
    v_stg_last_update_date := to_date(v_new_data.STG_LAST_UPDATE_DATE,BPM_COMMON.DATE_FMT);
    v_event_date := coalesce(v_stg_last_update_date,v_last_update_date);
      
    select BI_ID into v_bi_id
    from BPM_INSTANCE
    where
      IDENTIFIER = v_identifier
      and BEM_ID = v_bem_id
      and BSL_ID = v_bsl_id;

    if v_end_date is not null then
      update BPM_INSTANCE
      set
        END_DATE = v_end_date,
        LAST_UPDATE_DATE = v_event_date
      where BI_ID = v_bi_id;
    else
      update BPM_INSTANCE
      set LAST_UPDATE_DATE = v_event_date
      where BI_ID = v_bi_id;
    end if;

    commit;
    
    v_bue_id := SEQ_BUE_ID.nextval;
  
    insert into BPM_UPDATE_EVENT
      (BUE_ID,BI_ID,BUTL_ID,EVENT_DATE,BPMS_PROCESSED)
    values
      (v_bue_id,v_bi_id,v_butl_id,v_event_date,'N');
      
        /*select 'BPM_EVENT.UPDATE_BIA(v_bi_id, ' ||b.ba_id || ','||bl.bdl_id || ','||''''||b.retain_history_flag||''''||',v_old_data.'|| stg.staging_table_column ||
        ',v_new_data.'|| stg.staging_table_column ||
      ','||'v_bue_id,v_stg_last_update_date);'
    from bpm_attribute b, bpm_attribute_lkup bl,MAXDAT.bpm_attribute_staging_table stg
    where b.bal_id = bl.bal_id
    and stg.ba_id = b.ba_id
    and b.when_populated in ('UPDATE','BOTH')
    and b.bem_id = 1
    and bsl_id = 1
    order by b.ba_id*/
  
    BPM_EVENT.UPDATE_BIA(v_bi_id, 1,1,'N',v_old_data.AGE_IN_BUSINESS_DAYS,v_new_data.AGE_IN_BUSINESS_DAYS,v_bue_id,v_event_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id, 3,3,'Y',v_old_data.CANCEL_WORK_DATE,v_new_data.CANCEL_WORK_DATE,v_bue_id,v_event_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id, 5,3,'Y',v_old_data.COMPLETE_DATE,v_new_data.COMPLETE_DATE,v_bue_id,v_event_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id, 9,2,'Y',v_old_data.ESCALATED_FLAG,v_new_data.ESCALATED_FLAG,v_bue_id,v_event_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id,10,2,'Y',v_old_data.ESCALATED_TO_NAME,v_new_data.ESCALATED_TO_NAME,v_bue_id,v_event_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id,11,2,'Y',v_old_data.FORWARDED_BY_NAME,v_new_data.FORWARDED_BY_NAME,v_bue_id,v_event_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id,12,2,'Y',v_old_data.FORWARDED_FLAG,v_new_data.FORWARDED_FLAG,v_bue_id,v_event_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id,13,2,'Y',v_old_data.GROUP_NAME,v_new_data.GROUP_NAME,v_bue_id,v_event_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id,14,2,'Y',v_old_data.GROUP_PARENT_NAME,v_new_data.GROUP_PARENT_NAME,v_bue_id,v_event_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id,15,2,'Y',v_old_data.GROUP_SUPERVISOR_NAME,v_new_data.GROUP_SUPERVISOR_NAME,v_bue_id,v_event_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id,17,2,'Y',v_old_data.LAST_UPDATE_BY_NAME,v_new_data.LAST_UPDATE_BY_NAME,v_bue_id,v_event_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id,18,3,'Y',v_old_data.LAST_UPDATE_DATE,v_new_data.LAST_UPDATE_DATE,v_bue_id,v_event_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id,19,2,'Y',v_old_data.OWNER_NAME,v_new_data.OWNER_NAME,v_bue_id,v_event_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id,20,1,'N',v_old_data.SLA_DAYS,v_new_data.SLA_DAYS,v_bue_id,v_event_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id,21,2,'N',v_old_data.SLA_DAYS_TYPE,v_new_data.SLA_DAYS_TYPE,v_bue_id,v_event_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id,22,1,'N',v_old_data.SLA_JEOPARDY_DAYS,v_new_data.SLA_JEOPARDY_DAYS,v_bue_id,v_event_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id,23,1,'N',v_old_data.SLA_TARGET_DAYS,v_new_data.SLA_TARGET_DAYS,v_bue_id,v_event_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id,24,1,'N',v_old_data.SOURCE_REFERENCE_ID,v_new_data.SOURCE_REFERENCE_ID,v_bue_id,v_event_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id,25,2,'N',v_old_data.SOURCE_REFERENCE_TYPE,v_new_data.SOURCE_REFERENCE_TYPE,v_bue_id,v_event_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id,26,1,'N',v_old_data.STATUS_AGE_IN_BUS_DAYS,v_new_data.STATUS_AGE_IN_BUS_DAYS,v_bue_id,v_event_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id,28,3,'Y',v_old_data.STATUS_DATE,v_new_data.STATUS_DATE,v_bue_id,v_event_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id,30,2,'Y',v_old_data.TASK_STATUS,v_new_data.TASK_STATUS,v_bue_id,v_event_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id,31,2,'Y',v_old_data.TASK_TYPE,v_new_data.TASK_TYPE,v_bue_id,v_event_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id,32,2,'Y',v_old_data.TEAM_NAME,v_new_data.TEAM_NAME,v_bue_id,v_event_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id,33,2,'Y',v_old_data.TEAM_PARENT_NAME,v_new_data.TEAM_PARENT_NAME,v_bue_id,v_event_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id,34,2,'Y',v_old_data.TEAM_SUPERVISOR_NAME,v_new_data.TEAM_SUPERVISOR_NAME,v_bue_id,v_event_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id,36,2,'N',v_old_data.UNIT_OF_WORK,v_new_data.UNIT_OF_WORK,v_bue_id,v_event_date);

    BPM_EVENT.UPDATE_BIA(v_bi_id,1686,1,'N',v_old_data.CLIENT_ID,v_new_data.CLIENT_ID,v_bue_id,v_event_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id,1687,1,'N',v_old_data.CASE_ID,v_new_data.CASE_ID,v_bue_id,v_event_date);
    
    BPM_EVENT.UPDATE_BIA(v_bi_id, 1770,2,'N',v_old_data.CANCEL_METHOD,v_new_data.CANCEL_METHOD,v_bue_id,v_stg_last_update_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id, 1771,2,'N',v_old_data.CANCEL_REASON,v_new_data.CANCEL_REASON,v_bue_id,v_stg_last_update_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id, 1772,2,'N',v_old_data.CANCEL_BY,v_new_data.CANCEL_BY,v_bue_id,v_stg_last_update_date);
    BPM_EVENT.UPDATE_BIA(v_bi_id, 1780,1,'N',v_old_data.TASK_PRIORITY,v_new_data.TASK_PRIORITY,v_bue_id,v_stg_last_update_date);
    commit;
  
    p_bue_id := v_bue_id;
  
  exception

    when NO_DATA_FOUND then
      v_sql_code := SQLCODE;
      v_log_message := 'No BPM_INSTANCE found.  ' || SQLERRM;
      BPM_COMMON.LOGGER(BPM_COMMON.LOG_LEVEL_SEVERE,null,v_procedure_name,v_bsl_id,v_bil_id,v_identifier,v_bi_id,null,v_log_message,v_sql_code); 
      raise;
      
    when OTHERS then
      v_sql_code := SQLCODE;
      v_log_message := SQLERRM;
      BPM_COMMON.LOGGER(BPM_COMMON.LOG_LEVEL_SEVERE,null,v_procedure_name,v_bsl_id,v_bil_id,v_identifier,v_bi_id,null,v_log_message,v_sql_code); 
      raise;

  end;
  
  
  -- Update BPM Semantic model data.
  procedure UPDATE_BPM_SEMANTIC
    (p_data_version in number,
     p_old_data_xml in xmltype,
     p_new_data_xml in xmltype)
  as
  
    v_procedure_name varchar2(61) := $$PLSQL_UNIT || '.' || 'UPDATE_BPM_SEMANTIC';   
    v_sql_code number := null;
    v_log_message clob := null;
    
    v_old_data T_UPD_MW_XML := null;
    v_new_data T_UPD_MW_XML := null;
  
    v_bi_id number := null;
    v_identifier varchar2(35) := null;
    
    v_start_date date := null;
    v_end_date date := null;
    
    v_dmwe_id number := null;
    v_dmwf_id number := null;
    v_dmwlubn_id number := null;
    v_dmwlud_id number := null;
    v_dmwo_id number := null;
    v_dmwts_id number := null;
    v_dmwtt_id number := null;
    v_fmwbd_id number := null;
    
  begin
 
    if p_data_version = 2 or p_data_version = 3 then
      GET_UPD_MW_XML(p_old_data_xml,v_old_data);
      GET_UPD_MW_XML(p_new_data_xml,v_new_data);
    else
      v_log_message := 'Unsupported BPM_UPDATE_EVENT_QUEUE.DATA_VERSION value "' || p_data_version || '" for Manage Work in procedure ' || v_procedure_name || '.';
      RAISE_APPLICATION_ERROR(-20011,v_log_message);        
    end if;   

    v_identifier := v_new_data.TASK_ID;
    v_end_date := to_date(coalesce(v_new_data.COMPLETE_DATE,v_new_data.CANCEL_WORK_DATE),BPM_COMMON.DATE_FMT);
  
    select BI_ID into v_bi_id
    from BPM_INSTANCE
    where 
      IDENTIFIER = v_identifier
      and BEM_ID = v_bem_id
      and BSL_ID = v_bsl_id;

    GET_DMWE_ID(v_identifier,v_bi_id,v_new_data.ESCALATED_FLAG,v_new_data.ESCALATED_TO_NAME,v_dmwe_id);
    GET_DMWF_ID(v_identifier,v_bi_id,v_new_data.FORWARDED_BY_NAME,v_new_data.FORWARDED_FLAG,v_dmwf_id);
    GET_DMWLUBN_ID(v_identifier,v_bi_id,v_new_data.LAST_UPDATE_BY_NAME,v_dmwlubn_id);
    GET_DMWO_ID(v_identifier,v_bi_id,v_new_data.OWNER_NAME,v_dmwo_id);
    GET_DMWTS_ID(v_identifier,v_bi_id,v_new_data.TASK_STATUS,v_dmwts_id);
    GET_DMWTT_ID
      (v_identifier,v_bi_id,v_new_data.GROUP_NAME,v_new_data.GROUP_PARENT_NAME,v_new_data.GROUP_SUPERVISOR_NAME,
       v_new_data.TASK_TYPE,v_new_data.TEAM_NAME,v_new_data.TEAM_PARENT_NAME,v_new_data.TEAM_SUPERVISOR_NAME,v_dmwtt_id);
       
    -- Update current dimension and fact as a single transaction.
    begin
       
      commit;
       
      SET_DMWCUR
        ('UPDATE',v_identifier,v_bi_id,
         v_new_data.TASK_ID,v_new_data.AGE_IN_BUSINESS_DAYS,v_new_data.CREATE_DATE,v_new_data.COMPLETE_DATE,
         v_new_data.SLA_DAYS,v_new_data.SLA_DAYS_TYPE,v_new_data.SLA_JEOPARDY_DAYS,v_new_data.SLA_TARGET_DAYS,
         v_new_data.CANCEL_WORK_DATE,v_new_data.CREATED_BY_NAME,
         v_new_data.SOURCE_REFERENCE_ID,v_new_data.SOURCE_REFERENCE_TYPE,v_new_data.STATUS_AGE_IN_BUS_DAYS,v_new_data.UNIT_OF_WORK,
         v_new_data.ESCALATED_FLAG,v_new_data.ESCALATED_TO_NAME,
         v_new_data.FORWARDED_BY_NAME,v_new_data.FORWARDED_FLAG,
         v_new_data.GROUP_NAME,v_new_data.GROUP_PARENT_NAME,v_new_data.GROUP_SUPERVISOR_NAME,
         v_new_data.LAST_UPDATE_BY_NAME,v_new_data.OWNER_NAME,v_new_data.TASK_STATUS,v_new_data.TASK_TYPE,
         v_new_data.TEAM_NAME,v_new_data.TEAM_PARENT_NAME,v_new_data.TEAM_SUPERVISOR_NAME,
         v_new_data.LAST_UPDATE_DATE,v_new_data.STATUS_DATE,v_new_data.CLIENT_ID,v_new_data.CASE_ID,
         v_new_data.cancel_method,v_new_data.cancel_reason,v_new_data.cancel_by,v_new_data.task_priority);
      
      UPD_FMWBD(v_identifier,v_end_date,v_bi_id,v_dmwtt_id,v_dmwe_id,v_dmwf_id,v_dmwo_id,v_dmwts_id,v_dmwlubn_id,v_new_data.LAST_UPDATE_DATE,v_new_data.STG_LAST_UPDATE_DATE,v_new_data.STATUS_DATE,v_fmwbd_id);
    
      commit;
      
    exception
    
      when OTHERS then
        rollback;
        v_sql_code := SQLCODE;
        v_log_message := 'Rolled back initial insert for current dimension and fact.  ' || SQLERRM;
        BPM_COMMON.LOGGER(BPM_COMMON.LOG_LEVEL_SEVERE,null,v_procedure_name,v_bsl_id,v_bil_id,v_identifier,v_bi_id,null,v_log_message,v_sql_code); 
        raise;

    end;
    
  exception

    when NO_DATA_FOUND then
      v_sql_code := SQLCODE;
      v_log_message := 'No BPM_INSTANCE found.  ' || SQLERRM;
      BPM_COMMON.LOGGER(BPM_COMMON.LOG_LEVEL_SEVERE,null,v_procedure_name,v_bsl_id,v_bil_id,v_identifier,v_bi_id,null,v_log_message,v_sql_code); 
      raise;
      
    when OTHERS then
      v_sql_code := SQLCODE;
      v_log_message := SQLERRM;
      BPM_COMMON.LOGGER(BPM_COMMON.LOG_LEVEL_SEVERE,null,v_procedure_name,v_bsl_id,v_bil_id,v_identifier,v_bi_id,null,v_log_message,v_sql_code); 
      raise;

  end;

end;
/

alter session set plsql_code_type = interpreted;