Insert into CORP_CLNT_OUTREACH_PROC_LKUP (PROCESS,STEP1,STEP2,STEP3,STEP4,STEP5,STEP6) values ('OUTREACH_REQUEST_1','Letter','Delay1','Phone Call',null,null,null);
Insert into CORP_CLNT_OUTREACH_PROC_LKUP (PROCESS,STEP1,STEP2,STEP3,STEP4,STEP5,STEP6) values ('OUTREACH_REQUEST_2','Letter','Delay1','Phone Call','Home Visit',null,null);
Insert into CORP_CLNT_OUTREACH_PROC_LKUP (PROCESS,STEP1,STEP2,STEP3,STEP4,STEP5,STEP6) values ('OUTREACH_REQUEST_3','Automated Call',null,null,null,null,null);
Insert into CORP_CLNT_OUTREACH_PROC_LKUP (PROCESS,STEP1,STEP2,STEP3,STEP4,STEP5,STEP6) values ('OUTREACH_REQUEST_4','Delay1','Phone Call','Home Visit',null,null,null);
Insert into CORP_CLNT_OUTREACH_PROC_LKUP (PROCESS,STEP1,STEP2,STEP3,STEP4,STEP5,STEP6) values ('OUTREACH_REQUEST_5','Letter',null,null,null,null,null);
Insert into CORP_CLNT_OUTREACH_PROC_LKUP (PROCESS,STEP1,STEP2,STEP3,STEP4,STEP5,STEP6) values ('OUTREACH_REQUEST_6','Phone Call','Delay1','Letter','Delay2','Home Visit',null);
Insert into CORP_CLNT_OUTREACH_PROC_LKUP (PROCESS,STEP1,STEP2,STEP3,STEP4,STEP5,STEP6) values ('OUTREACH_REQUEST_7','Phone Call','Delay1','Letter',null,null,null);
Insert into CORP_CLNT_OUTREACH_PROC_LKUP (PROCESS,STEP1,STEP2,STEP3,STEP4,STEP5,STEP6) values ('OUTREACH_REQUEST_8','Human Task','Human Task',null,null,null,null);
Insert into CORP_CLNT_OUTREACH_PROC_LKUP (PROCESS,STEP1,STEP2,STEP3,STEP4,STEP5,STEP6) values ('OUTREACH_REQUEST_9','Letter','Delay1','Phone Call','Delay2','Phone Call','Home Visit');
Insert into CORP_CLNT_OUTREACH_PROC_LKUP (PROCESS,STEP1,STEP2,STEP3,STEP4,STEP5,STEP6) values ('OUTREACH_REQUEST_10','Human Task','Human Task',null,null,null,null);
Insert into CORP_CLNT_OUTREACH_PROC_LKUP (PROCESS,STEP1,STEP2,STEP3,STEP4,STEP5,STEP6) values ('OUTREACH_REQUEST_11','Human Task','Human Task','Letter',null,null,null);


commit;