
CREATE TABLE D_ME_CURRENT
  (
    ME_BI_ID                          number(18),
    CLIENT_ENROLL_STATUS_ID           number(18),
    CLIENT_ID                         number(18),
    CREATE_DT                         DATE,
    CASE_ID                           number(18),
    CLIENT_CIN                        VARCHAR2(32),
    NEWBORN_FLG                       VARCHAR2(1),
    SERVICE_AREA                      VARCHAR2(32),
    COUNTY_CODE                       VARCHAR2(32),
    ZIP_CODE                          VARCHAR2(80),
    AGE_IN_BUSINESS_DAYS              number(18),
    AGE_IN_CALENDAR_DAYS              number(18),
    CUR_ENROLLMENT_STATUS_CODE        VARCHAR2(32),     
    CUR_ENROLLMENT_STATUS_DATE        DATE,
    AUTO_ASSIGNMENT_DUE_DATE          DATE,
    ENRL_PACKET_REQUEST_ID            NUMBER(18),
    ENRL_PACKET_REQUEST_DATE          DATE,
    ENROLL_FEE_AMNT_DUE               NUMBER,
    ENROLL_FEE_AMNT_PAID              NUMBER,
    ENROLL_FEE_RECVD_DATE             DATE,
	  FEE_PAID_FLG	                    VARCHAR2(1),
    CHIP_PLAN_CHANGE_NOTICE_ID        NUMBER(18),
    CHIP_PLAN_CHANGE_MAILED_DATE      DATE,
    CHIP_ENROLL_MI_NOTICE_ID          NUMBER(18),
    CHIP_ENROLL_MI_SENT_DATE          DATE,
    PLAN_TYPE                         VARCHAR2(32),
    PROGRAM_TYPE                      VARCHAR2(32),
	  SUBPROGRAM_TYPE                   VARCHAR2(32),
    SELECTION_METHOD                  VARCHAR2(32),
    SELECTION_CREATED_BY_NAME         VARCHAR2(80),
    SELECTION_CREATE_DATE             DATE,
    SELECTION_LAST_UPD_BY_NAME        VARCHAR2(80),
    SELECTION_LAST_UPDATE_DATE        DATE,
    SELECTION_AUTO_PROCESSED          VARCHAR2(1),
--
    VALID_SLCN_RECEIVED_START_DATE  DATE,
    VALID_SLCN_RECEIVED_END_DATE    DATE,
    SEND_ENROLL_PKT_START_DATE      DATE,
    SEND_ENROLL_PKT_END_DATE        DATE,
    FIRST_FOLLOW_UP_ID              varchar2(37),
    FIRST_FOLLOW_UP_TYPE_CODE       varchar2(40),
    FIRST_FOLLOW_UP_START_DATE      DATE,
    FIRST_FOLLOW_UP_END_DATE        DATE,
    SECOND_FOLLOW_UP_ID             varchar2(37),
    SECOND_FOLLOW_UP_TYPE_CODE      varchar2(40),
    SECOND_FOLLOW_UP_START_DATE     DATE,
    SECOND_FOLLOW_UP_END_DATE       DATE,
    THIRD_FOLLOW_UP_ID              varchar2(37),
    THIRD_FOLLOW_UP_TYPE_CODE       varchar2(40),
    THIRD_FOLLOW_UP_START_DATE      DATE,
    THIRD_FOLLOW_UP_END_DATE        DATE,
    FOURTH_FOLLOW_UP_ID             varchar2(37),
    FOURTH_FOLLOW_UP_TYPE_CODE      varchar2(40),
    FOURTH_FOLLOW_UP_START_DATE     DATE,
    FOURTH_FOLLOW_UP_END_DATE       DATE,
    AUTO_ASSIGN_START_DATE          DATE,
    AUTO_ASSIGN_END_DATE            DATE,
    WAIT_ENROLL_FEE_START_DATE      DATE,
    WAIT_ENROLL_FEE_END_DATE        DATE,
    INSTANCE_STATUS                 VARCHAR2(10),
    COMPLETE_DATE                   DATE,
    CANCEL_ENROLL_ACTIVITY_DATE     DATE,
    CANCEL_REASON                   VARCHAR2(100),
    CANCEL_METHOD                   VARCHAR2(20),
    CANCELLED_BY   	            varchar2(80),
--ASF flags.
    CANCEL_ENRL_ACTIVITY_FLAG   varchar2(1), 
    SEND_ENROLL_PACKET_FLAG     varchar2(1),  
    SELECTIONS_RECEIVED_FLAG    varchar2(1), 
    FIRST_FOLLOW_UP_COMP_FLAG   varchar2(1), 
    SECOND_FOLLOW_UP_COMP_FLAG  varchar2(1), 
    THIRD_FOLLOW_UP_COMP_FLAG   varchar2(1), 
    FOURTH_FOLLOW_UP_COMP_FLAG  varchar2(1), 
    AUTO_ASSIGN_FLAG            varchar2(1), 
    WAIT_FOR_FEE_FLAG           varchar2(1), 
--Gateway flags.
    ENROLL_PACKET_REQUIRED_FLAG  varchar2(1),
    FIRST_FOLLOW_UP_REQ_FLAG     varchar2(1),
    SECOND_FOLLOW_UP_REQ_FLAG    varchar2(1),
    THIRD_FOLLOW_UP_REQ_FLAG     varchar2(1),
    FOURTH_FOLLOW_UP_REQ_FLAG    varchar2(1),
    REQ_FEE_PAID_FLAG            varchar2(1),
--    
AUTO_ASSIGN_TIMELY_STATUS             varchar2(10),  
AUTO_ASSIGN_SLA_DAYS                  number(18),
AUTO_ASSIGN_SLA_DAYS_TYPE             varchar2(1),
ENROLL_PACKET_TIMELY_STATUS           varchar2(10),  
ENROLL_PACKET_SLA_DAYS                number(18),
ENROLL_PACKET_SLA_DAYS_TYPE           varchar2(1),
FIRST_FOLLOWUP_TIMELY_STATUS          varchar2(10), 
FIRST_FOLLOWUP_SLA_DAYS               number(18),
FIRST_FOLLOWUP_SLA_DAYS_TYPE          varchar2(1),
SECOND_FOLLOWUP_TIMELY_STATUS         varchar2(10),  
SECOND_FOLLOWUP_SLA_DAYS              number(18),
SECOND_FOLLOWUP_SLA_DAYS_TYPE         varchar2(1),
THIRD_FOLLOWUP_TIMELY_STATUS          varchar2(10),
THIRD_FOLLOWUP_SLA_DAYS               number(18),
THIRD_FOLLOWUP_SLA_DAYS_TYPE          varchar2(1),
FOURTH_FOLLOWUP_TIMELY_STATUS         varchar2(10),
FOURTH_FOLLOWUP_SLA_DAYS              number(18),
FOURTH_FOLLOWUP_SLA_DAYS_TYPE         varchar2(1),
FIRST_FOLLOW_UP_TYPE                  varchar2(200), 
SECOND_FOLLOW_UP_TYPE                 varchar2(200),
THIRD_FOLLOW_UP_TYPE                  varchar2(200),
FOURTH_FOLLOW_UP_TYPE                 varchar2(200),
ENROLLMENT_FEE_REQUIRED               varchar2(1),
ENROLLMENT_ACTIVITY_OUTCOME           varchar2(200),
DAYS_TO_AUTO_ASSIGNMENT               number(18),
--
GENERIC_FIELD_1                       VARCHAR2(50),
GENERIC_FIELD_2                       VARCHAR2(50),
GENERIC_FIELD_3                       VARCHAR2(50),
GENERIC_FIELD_4                       VARCHAR2(50),
GENERIC_FIELD_5                       VARCHAR2(50)
  );
  
alter table D_ME_CURRENT add constraint DMECUR_PK primary key (ME_BI_ID);
alter index DMECUR_PK rebuild tablespace MAXDAT_INDX parallel;

create unique index DMECUR_UIX1 on D_ME_CURRENT (CLIENT_ENROLL_STATUS_ID) online tablespace MAXDAT_INDX parallel compute statistics; 

create or replace view D_ME_CURRENT_SV as
select * from D_ME_CURRENT
with read only;

------------------------------------------------------------------------------------------------------------
--D_ME_ENRL_STATUS_CODE    DMESC_ID  "Enrollment Status Code"            VARCHAR2(32),
create sequence SEQ_DMESC_ID
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

create table D_ME_ENRL_STATUS_CODE 
  (DMESC_ID number, 
	 Enrollment_Status_Code           VARCHAR2(32))
tablespace MAXDAT_DATA parallel;

alter table D_ME_ENRL_STATUS_CODE add constraint DMESC_PK primary key (DMESC_ID);
alter index DMESC_PK rebuild tablespace MAXDAT_INDX parallel;

create unique index DMESC_UIX1 on D_ME_ENRL_STATUS_CODE (Enrollment_Status_Code) online tablespace MAXDAT_INDX parallel compute statistics; 

create or replace view D_ME_ENRL_STATUS_CODE_SV as
select * from D_ME_ENRL_STATUS_CODE
with read only;

insert into D_ME_ENRL_STATUS_CODE (DMESC_ID ,Enrollment_Status_Code) values (SEQ_DMESC_ID.nextval,null);
commit;
--------------------------------------------------------------------------------------------------
create sequence SEQ_FMEBD_ID
minvalue 1
maxvalue 999999999999999999999999999
start with 1
increment by 1
cache 20;

 create table F_ME_BY_DATE 
  (FMEBD_ID number not null,
	 D_DATE date not null,
	 BUCKET_START_DATE date not null, 
	 BUCKET_END_DATE date not null,
	 ME_BI_ID number not null, 
	 DMESC_ID number not null, --D_ME_ENRL_STATUS_CODE    DMESC_ID 
	 INVENTORY_COUNT number,
	 CREATION_COUNT number,
	 COMPLETION_COUNT number,
	 Enrollment_Status_date date)
partition by range (BUCKET_START_DATE)
interval (numtodsinterval(1,'day'))
(partition PT_BUCKET_START_DATE_LT_2012 values less than (to_date('20120101','YYYYMMDD')))   
tablespace MAXDAT_DATA parallel;

alter table F_ME_BY_DATE add constraint FMEBD_PK primary key (FMEBD_ID);
alter index FMEBD_PK rebuild  online tablespace MAXDAT_INDX parallel;

create unique index FMEBD_UIX1 on F_ME_BY_DATE (ME_BI_ID,D_DATE) online tablespace MAXDAT_INDX parallel compute statistics; 
create unique index FMEBD_UIX2 on F_ME_BY_DATE (ME_BI_ID,BUCKET_START_DATE) online tablespace MAXDAT_INDX parallel compute statistics; 

create index FMEBD_IX1 on F_ME_BY_DATE (Enrollment_Status_date) online tablespace MAXDAT_INDX parallel compute statistics;

create index FMEBD_IXL1 on F_ME_BY_DATE (BUCKET_END_DATE) local online tablespace MAXDAT_INDX parallel compute statistics;


alter table F_ME_BY_DATE add constraint FMEBD_DMECUR_FK
foreign key (ME_BI_ID)references D_ME_CURRENT (ME_BI_ID);


--D_ME_ENRL_STATUS_CODE    DPIIS_ID  "Instance Status"           VARCHAR2(10),
alter table F_ME_BY_DATE add constraint FMEBD_ID_FK
foreign key (DMESC_ID) references D_ME_ENRL_STATUS_CODE (DMESC_ID);


create or replace view F_ME_BY_DATE_SV as
select
   FMEBD_ID,
	 bdd.D_DATE,
	 BUCKET_START_DATE, 
	 BUCKET_END_DATE,
	 ME_BI_ID, 
	 DMESC_ID, 
   INVENTORY_COUNT,
  case 
    when dense_rank() over (partition by ME_BI_ID order by ME_BI_ID asc, bdd.D_DATE asc) = 1 then 1
    else 0
    end CREATION_COUNT,
  COMPLETION_COUNT, 
  Enrollment_Status_Date
from 
  BPM_D_DATES bdd,
  F_ME_BY_DATE fmebd
where
  bdd.D_DATE >= fmebd.BUCKET_START_DATE 
  and bdd.D_DATE < fmebd.BUCKET_END_DATE
union all
select
   FMEBD_ID,
	 bdd.D_DATE,
	 BUCKET_START_DATE, 
	 BUCKET_END_DATE,
	 ME_BI_ID, 
	 DMESC_ID, 
	 INVENTORY_COUNT,
  case 
    when dense_rank() over (partition by ME_BI_ID order by ME_BI_ID asc, bdd.D_DATE asc) = 1 then 1
    else 0
    end CREATION_COUNT,
  COMPLETION_COUNT, 
  Enrollment_Status_Date
from 
  BPM_D_DATES bdd,
  F_ME_BY_DATE fmebd
where
  bdd.D_DATE = fmebd.BUCKET_START_DATE 
  and bdd.D_DATE = fmebd.BUCKET_END_DATE
with read only;

commit;  
