alter table corp_etl_list_lkup modify (OUT_VAR varchar2(500));

alter table corp_etl_list_lkup_hist modify (OUT_VAR varchar2(500));

commit;