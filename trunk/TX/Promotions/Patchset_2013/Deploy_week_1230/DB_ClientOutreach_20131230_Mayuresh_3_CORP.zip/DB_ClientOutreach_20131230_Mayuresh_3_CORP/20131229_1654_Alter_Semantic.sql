
create or replace view D_COR_OR_EVENT_SV as
select * 
from CORP_ETL_CLNT_OUTREACH_EVENTS
with read only;