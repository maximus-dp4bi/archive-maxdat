Insert into CORP_ETL_CONTROL (NAME,VALUE_TYPE,VALUE,DESCRIPTION,CREATED_TS,UPDATED_TS) 
values ('LAST_COMM_OUTREACH_SESSION_ID','N','0','Used to fetch Sessions from OLTP for Community Outreach Process',sysdate,sysdate);

commit;


