
--  Remove ETL instances 
truncate table CORP_ETL_CLNT_OUTREACH;
truncate table CORP_ETl_CLNT_OUTREACH_OLTP
truncate table CORP_ETL_CLNT_OUTREACH_WIP_BPM;

truncate table CORP_ETL_CLNT_OUTREACH_EVENTS;

update corp_etl_control set value = '0' 
where name = 'CO_LAST_OUTREACH_ID';
commit;


update corp_etl_control set value = '0' 
where name = 'CO_LAST_OUTREACH_EVENT_ID';
commit;
