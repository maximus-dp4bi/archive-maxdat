# ================================================================================
# Do not edit these four SVN_* variable values.  They are populated when you
#     commit code to SVN and used later to identify deployed code.
# $URL: svn://svn-staging.maximus.com/dev1d/maxdat/trunk/Kettle8/CADIR/Scripts/run_deltek_runall.sh $
# $Revision: 28201 $
# $Date: 2019-10-23 15:37:31 -0700 (Wed, 23 Oct 2019) $
# $Author: aa24065 $
# ================================================================================
#!/bin/bash
#source $MD_SETENV
export MD_SETENV=/u01/maximus/maxdat-dev/CADIR8/scripts/.set_env
. $MD_SETENV
export OLD_MAXDAT_ETL_PATH="/u01/maximus/maxdat-dev/CADIR/scripts"

JOBS_DIR=$MAXDAT_ETL_PATH
JOB=Load_Deltek_hours
echo $OLD_MAXDAT_ETL_PATH
echo $MAXDAT_ETL_PATH
echo $JOBS_DIR

today=`date +%Y%m%d`
curr_dir=$(pwd)

TempFol=${OLD_MAXDAT_ETL_PATH//scripts/input}

TempFile=csv.txt

#Remove temp file if already exists 
rm -f $TempFol/$TempFile

#Change directory 
cd $TempFol

#Concate files to load
cat *.csv >> $TempFile

#If data file exists to process
if [ -s $TempFol/$TempFile ]
then
   echo "File is available to process"
   $MAXDAT_KETTLE_DIR/kitchen.sh -file="$JOBS_DIR/$JOB.kjb" -log="$MAXDAT_ETL_LOGS/$JOB$(date +%Y%m%d_%H%M%S).log" -level="$KJB_LOG_LEVEL"
else
      echo "File is not available"
fi

#move files to archive folder
#for fname in *.csv
#do 
#   echo Moved file $fname to archive folder as $fname.${today}
#   mv $fname ./archive/$fname.${today}
#done

rm -f $TempFol/$TempFile

cd $curr_dir