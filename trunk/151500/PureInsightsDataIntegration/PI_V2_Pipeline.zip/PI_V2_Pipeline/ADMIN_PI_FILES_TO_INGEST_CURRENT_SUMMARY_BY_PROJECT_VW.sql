use role SYSADMIN;
use warehouse PUREINSIGHTS_DEV_LOAD_DAILY_WH;
use database PUREINSIGHTS_DEV;
use schema PUBLIC;

CREATE OR REPLACE VIEW ADMIN_PI_FILES_TO_INGEST_CURRENT_SUMMARY_BY_PROJECT_VW COPY GRANTS
(
	PROJECTID,
	PROJECTNAME,
	NUM_FILES,
	NUM_IN_PROGRESS,
	NUM_COMPLETE,
	NUM_FAILED
)
AS
SELECT 	
	s.projectid,
	P.projectname,
	count(*) AS num_files,
	count(CASE WHEN status = 'IN PROGRESS' THEN 1 ELSE null END) num_in_progress,
	count(CASE WHEN status = 'COMPLETE' THEN 1 ELSE null END) num_complete,
	count(CASE WHEN status = 'FAILED' THEN 1 ELSE null END) num_failed
FROM  
	PI_FILES_TO_INGEST_CURRENT_VW	s
INNER JOIN d_pi_tables T ON (s.tablename = T.table_name AND T.active = TRUE AND T.ingest_type IS NOT NULL)
INNER JOIN d_pi_projects P ON (s.projectid = P.projectid)
GROUP BY 
	s.projectid,
	P.projectname;

GRANT SELECT, REFERENCES ON ADMIN_PI_FILES_TO_INGEST_CURRENT_SUMMARY_BY_PROJECT_VW TO ROLE PI_DATA_INGEST_DEV_ALERT_USER;

