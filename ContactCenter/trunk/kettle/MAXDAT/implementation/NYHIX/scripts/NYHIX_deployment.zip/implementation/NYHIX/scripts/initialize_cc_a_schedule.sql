insert into cc_a_schedule (job_type,execution_time) values('load_production_planning','13:00:00');
insert into cc_a_schedule (job_type,execution_time) values('load_contact_center','07:00:00');
commit;
