-- Insert lookup values for default skill groups

insert into cc_a_list_lkup     (	cc_cell_id
					,name
					,list_type
					,value
					,out_var
					,ref_type
					,ref_id
					,start_date
					,end_date
					,comments
					,created_ts
					,updated_ts)
			values (	seq_cc_cell_id.NEXTVAL
					,'Default_Skill_Groups'
					,'SKILLGROUP'
					,'Default_Skill_Groups'
					,'5000,5001'
					,null
					,1
					,trunc(SYSDATE)
					,to_date('07-JUL-7777','DD-MON-YYYY')
					,'Defualt Skill Groups list for Contact Center'
					,SYSDATE
					,SYSDATE);
					
					
										
commit;	

insert into cc_a_list_lkup (name, list_type, value, out_var, ref_id, start_date, end_date, comments, created_ts, updated_ts)
values ('Transfer_Out_Disposition', 'DISPOSITION', 'TRANSFER_OUT_DISPOSITION','28,29', 1,trunc(SYSDATE),to_date('07-JUL-7777','DD-MON-YYYY'), 'Disposition Code for Transfer Out Calls', SYSDATE, SYSDATE );

insert into cc_a_list_lkup (name, list_type, value, out_var, ref_id, start_date, end_date, comments, created_ts, updated_ts)
values ('Handled_Inbound_call_types', 'CALLTYPES', 'Handled_Inbound_call_types',''''||'Inbound'||''''||',''INBOUND'||'''', 1,trunc(SYSDATE),to_date('07-JUL-7777','DD-MON-YYYY'), 'Handled Call Types', SYSDATE, SYSDATE );

insert into cc_a_list_lkup (name, list_type, value, out_var, ref_id, start_date, end_date, comments, created_ts, updated_ts)
values ('Handled_Outbound_call_types', 'CALLTYPES', 'Handled_Outbound_call_types',''''||'Outbound'||''''||',''OUTBOUND'||'''', 1,trunc(SYSDATE),to_date('07-JUL-7777','DD-MON-YYYY'), 'Handled Call Types', SYSDATE, SYSDATE );

insert into cc_a_list_lkup (name, list_type, value, out_var, ref_id, start_date, end_date, comments, created_ts, updated_ts)
values ('VM_call_types', 'CALLTYPES', 'VM_call_types',''''||'Voicemail'||'''', 1,trunc(SYSDATE),to_date('07-JUL-7777','DD-MON-YYYY'), 'VM Call Types', SYSDATE, SYSDATE );

insert into cc_a_list_lkup (name, list_type, value, out_var, ref_id, start_date, end_date, comments, created_ts, updated_ts)
values ('CAHCO_Completed_Event', 'CAHCO_CALLBACK', 'CAHCO_Completed_Event',24, 1,trunc(SYSDATE),to_date('07-JUL-7777','DD-MON-YYYY'), 'CAHCO_Completed_Event', SYSDATE, SYSDATE );

insert into cc_a_list_lkup (name, list_type, value, out_var, ref_id, start_date, end_date, comments, created_ts, updated_ts)
values ('CAHCO_Peripheral_CallType', 'CAHCO_CALLTYPE', 'CAHCO_Peripheral_CallType',2, 1,trunc(SYSDATE),to_date('07-JUL-7777','DD-MON-YYYY'), 'CAHCO_Peripheral_CallType', SYSDATE, SYSDATE );

insert into cc_a_list_lkup (name, list_type, value, out_var, ref_id, start_date, end_date, comments, created_ts, updated_ts)
values ('CAHCO_Enterprise_Name', 'CAHCO_QUEUE_NAME', 'CAHCO_Enterprise_Name','CAR%', 1,trunc(SYSDATE),to_date('07-JUL-7777','DD-MON-YYYY'), 'CAHCO_Enterprise_Name', SYSDATE, SYSDATE );

insert into cc_a_list_lkup     (	cc_cell_id
					,name
					,list_type
					,value
					,out_var
					,ref_type
					,ref_id
					,start_date
					,end_date
					,comments
					,created_ts
					,updated_ts)
			values (	seq_cc_cell_id.NEXTVAL
					,'DNIS_CODE'
					,'DNIS_CODE'
					,'DNIS_CODE'
					,''''||'777'||''''
					,null
					,1
					,trunc(SYSDATE)
					,to_date('07-JUL-7777','DD-MON-YYYY')
					,'DNIS code to ignore for CAHCO Contact Center'
					,SYSDATE
					,SYSDATE);	

insert into cc_a_list_lkup     (	cc_cell_id
					,name
					,list_type
					,value
					,out_var
					,ref_type
					,ref_id
					,start_date
					,end_date
					,comments
					,created_ts
					,updated_ts)
			values (	seq_cc_cell_id.NEXTVAL
					,'HANDLED_CALLS_DNIS_CODE'
					,'DNIS_CODE'
					,'HANDLED_CALLS_DNIS_CODE'
					,''''||'800'||''''||',''866'||''''||',''888'||''''
					,null
					,1
					,trunc(SYSDATE)
					,to_date('07-JUL-7777','DD-MON-YYYY')
					,'Additional DNIS codes to ignore for CAHCO Contact Center'
					,SYSDATE
					,SYSDATE);	

insert into cc_a_list_lkup     (	cc_cell_id
					,name
					,list_type
					,value
					,out_var
					,ref_type
					,ref_id
					,start_date
					,end_date
					,comments
					,created_ts
					,updated_ts)
			values (	seq_cc_cell_id.NEXTVAL
					,'timezone'
					,'TIMEZONE'
					,'TIMEZONE'
					,'US/Pacific'
					,null
					,1
					,trunc(SYSDATE)
					,to_date('07-JUL-7777','DD-MON-YYYY')
					,'Timezone for Contact Center'
					,SYSDATE
					,SYSDATE);

commit;

-- Calls offered formula

insert into cc_a_list_lkup     (	cc_cell_id
					,name
					,list_type
					,value
					,out_var
					,ref_type
					,ref_id
					,start_date
					,end_date
					,comments
					,created_ts
					,updated_ts)
			values (	seq_cc_cell_id.NEXTVAL
					,'CAHCO_CALLS_OFFERED_FORMULA'
					,'CC_S_ACD_INTERVAL-CALLS_OFFERED'
					,'CA HCO'
					,'select (CONTACTS_OFFERED - OUTFLOW_CONTACTS - AGENT_ERROR_COUNT - ERROR_COUNT - CALLS_ROUTED_NON_AGENT - RETURN_RELEASE - CALLS_RONA - RETURN_BUSY - NETWORK_DEFAULT_ROUTED - ICR_DEFAULT_ROUTED - RETURN_RING - INCOMPLETE_CALLS) from cc_s_acd_interval where acd_interval_id = :ACD_INTERVAL_ID'
					,null
					,1
					,trunc(SYSDATE)
					,to_date('07-JUL-7777','DD-MON-YYYY')
					,'Calls offered formula for various projects in the enterprise'
					,SYSDATE
					,SYSDATE);
					
insert into cc_a_list_lkup     (	cc_cell_id
					,name
					,list_type
					,value
					,out_var
					,ref_type
					,ref_id
					,start_date
					,end_date
					,comments
					,created_ts
					,updated_ts)
			values (	seq_cc_cell_id.NEXTVAL
					,'CAHCO_CALLS_OFFERED_FORMULA'
					,'CC_S_ACD_QUEUE_INTERVAL-CALLS_OFFERED'
					,'CA HCO'
					,'select (CONTACTS_OFFERED - OUTFLOW_CONTACTS - AGENT_ERROR_COUNT - ERROR_COUNT - CALLS_ROUTED_NON_AGENT - RETURN_RELEASE - CALLS_RONA - RETURN_BUSY - NETWORK_DEFAULT_ROUTED - ICR_DEFAULT_ROUTED - RETURN_RING - INCOMPLETE_CALLS) from cc_s_acd_queue_interval where acd_queue_interval_id = :ACD_INTERVAL_ID'
					,null
					,1
					,trunc(SYSDATE)
					,to_date('07-JUL-7777','DD-MON-YYYY')
					,'Calls offered formula for various projects in the enterprise'
					,SYSDATE
					,SYSDATE);		
										

commit;		


insert into cc_a_list_lkup     (	cc_cell_id
					,name
					,list_type
					,value
					,out_var
					,ref_type
					,ref_id
					,start_date
					,end_date
					,comments
					,created_ts
					,updated_ts)
			values (	seq_cc_cell_id.NEXTVAL
					,'UNKNOWN_CALLS_OFFERED_FORMULA'
					,'CC_S_ACD_INTERVAL-CALLS_OFFERED'
					,'Unknown'
					,'select (CONTACTS_OFFERED) from cc_s_acd_interval where acd_interval_id = :ACD_INTERVAL_ID'
					,null
					,7
					,trunc(SYSDATE)
					,to_date('07-JUL-7777','DD-MON-YYYY')
					,'Calls offered formula for various projects in the enterprise'
					,SYSDATE
					,SYSDATE);					
					
commit;	

insert into cc_a_list_lkup     (	cc_cell_id
					,name
					,list_type
					,value
					,out_var
					,ref_type
					,ref_id
					,start_date
					,end_date
					,comments
					,created_ts
					,updated_ts)
			values (	seq_cc_cell_id.NEXTVAL
					,'UNKNOWN_CALLS_OFFERED_FORMULA'
					,'CC_S_ACD_QUEUE_INTERVAL-CALLS_OFFERED'
					,'Unknown'
					,'select (CONTACTS_OFFERED) from cc_s_acd_queue_interval where acd_queue_interval_id = :ACD_INTERVAL_ID'
					,null
					,7
					,trunc(SYSDATE)
					,to_date('07-JUL-7777','DD-MON-YYYY')
					,'Calls offered formula for various projects in the enterprise'
					,SYSDATE
					,SYSDATE);
					
-- IVR queue type lookup

insert into cc_a_list_lkup     (	cc_cell_id
					,name
					,list_type
					,value
					,out_var
					,ref_type
					,ref_id
					,start_date
					,end_date
					,comments
					,created_ts
					,updated_ts)
			values (	seq_cc_cell_id.NEXTVAL
					,'IVR QUEUE TYPE'
					,'QUEUE TYPE'
					,'IVR QUEUE TYPE'
					,'IVR'
					,null
					,1
					,trunc(SYSDATE)
					,to_date('07-JUL-7777','DD-MON-YYYY')
					,'Lookup for IVR queue types'
					,SYSDATE
					,SYSDATE);