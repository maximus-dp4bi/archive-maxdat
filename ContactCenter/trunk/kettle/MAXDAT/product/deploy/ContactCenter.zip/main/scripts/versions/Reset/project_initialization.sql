--lookup tables

delete from cc_c_filter;

delete from cc_c_lookup;

delete from cc_a_list_lkup

delete from cc_a_source_lkup;



-- config tables

delete from Cc_c_Unit_Of_Work;

delete from cc_c_contact_queue;

delete from cc_c_project_config;





-- staging tables

delete from cc_s_interval;

delete from cc_s_contact_queue;

delete from cc_s_agent;

delete from cc_d_unit_of_work;



dimensional tables:

delete from cc_d_dates;

delete from cc_d_interval;

delete from cc_d_contact_queue;

delete from cc_d_project;

delete from cc_d_program;

delete from cc_d_country;

delete from cc_d_region;

delete from cc_d_district;

delete from cc_d_province;

delete from cc_d_state;

delete from cc_d_target;

delete from cc_d_activity_type;

delete from cc_d_unit_of_work;

delete from cc_d_geography_master;

delete from cc_d_project_targets;

delete from cc_d_prod_planning_target;




