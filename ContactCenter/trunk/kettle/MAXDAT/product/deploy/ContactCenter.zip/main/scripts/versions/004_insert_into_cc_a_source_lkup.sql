insert into CC_A_SOURCE_LKUP (project_name, acd_source, wfm_source, start_date, end_date) values ('Product', 'CISCO', 'NA', sysdate, null);

commit;