
insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-01 00:00:00', '2014-03-02 00:00:00', 'load_contact_center'); 

insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-02 00:00:00', '2014-03-03 00:00:00', 'load_contact_center'); 

insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-03 00:00:00', '2014-03-04 00:00:00', 'load_contact_center'); 

insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-04 00:00:00', '2014-03-05 00:00:00', 'load_contact_center'); 

insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-05 00:00:00', '2014-03-06 00:00:00', 'load_contact_center'); 

insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-06 00:00:00', '2014-03-07 00:00:00', 'load_contact_center'); 

insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-07 00:00:00', '2014-03-08 00:00:00', 'load_contact_center'); 

insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-08 00:00:00', '2014-03-09 00:00:00', 'load_contact_center'); 

insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-09 00:00:00', '2014-03-10 00:00:00', 'load_contact_center'); 

insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-10 00:00:00', '2014-03-11 00:00:00', 'load_contact_center'); 

insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-11 00:00:00', '2014-03-12 00:00:00', 'load_contact_center'); 

insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-12 00:00:00', '2014-03-13 00:00:00', 'load_contact_center'); 

insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-13 00:00:00', '2014-03-14 00:00:00', 'load_contact_center'); 

insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-14 00:00:00', '2014-03-15 00:00:00', 'load_contact_center'); 

insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-15 00:00:00', '2014-03-16 00:00:00', 'load_contact_center'); 


insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-16 00:00:00', '2014-03-17 00:00:00', 'load_contact_center'); 

insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-17 00:00:00', '2014-03-18 00:00:00', 'load_contact_center'); 

insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-18 00:00:00', '2014-03-19 00:00:00', 'load_contact_center'); 

insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-19 00:00:00', '2014-03-20 00:00:00', 'load_contact_center'); 

insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-20 00:00:00', '2014-03-21 00:00:00', 'load_contact_center'); 

insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-21 00:00:00', '2014-03-22 00:00:00', 'load_contact_center'); 

insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-22 00:00:00', '2014-03-23 00:00:00', 'load_contact_center'); 

insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-23 00:00:00', '2014-03-24 00:00:00', 'load_contact_center'); 

insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-24 00:00:00', '2014-03-25 00:00:00', 'load_contact_center'); 

insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-25 00:00:00', '2014-03-26 00:00:00', 'load_contact_center'); 

insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-26 00:00:00', '2014-03-27 00:00:00', 'load_contact_center'); 

insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-27 00:00:00', '2014-03-28 00:00:00', 'load_contact_center'); 

insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-28 00:00:00', '2014-03-29 00:00:00', 'load_contact_center'); 

insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-29 00:00:00', '2014-03-30 00:00:00', 'load_contact_center'); 

insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-30 00:00:00', '2014-03-31 00:00:00', 'load_contact_center'); 

insert into cc_a_adhoc_job (START_DATETIME_PARAM, END_DATETIME_PARAM, ADHOC_JOB_TYPE) 
values ( '2014-03-31 00:00:00', '2014-04-01 00:00:00', 'load_contact_center'); 

INSERT INTO CC_L_PATCH_LOG ( PATCH_VERSION , SCRIPT_SEQUENCE , SCRIPT_NAME)
VALUES ('0.3.1','119','119_INSERT_MARCH_SCHEDULE');

COMMIT;