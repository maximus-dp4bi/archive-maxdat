BEGIN
	--SET CC_F_AGENT_BY_DATE.FIRST_LOGIN as NULLABLE
	DECLARE
	   already_null EXCEPTION;
	   PRAGMA EXCEPTION_INIT(already_null, -1451);
	BEGIN
	   execute immediate 'ALTER TABLE CC_F_AGENT_BY_DATE MODIFY (FIRST_LOGIN NULL)';
	EXCEPTION
	   WHEN already_null THEN
		  null; -- do nothing
	END;

	--SET CC_F_AGENT_BY_DATE.LAST_LOGOUT as NULLABLE
	DECLARE
	   already_null EXCEPTION;
	   PRAGMA EXCEPTION_INIT(already_null, -1451);
	BEGIN
	   execute immediate 'ALTER TABLE CC_F_AGENT_BY_DATE MODIFY (LAST_LOGOUT NULL)';
	EXCEPTION
	   WHEN already_null THEN
		  null; -- do nothing
	END;

	--SET CC_F_AGENT_BY_DATE.SCHEDULED_SHIFT_MINUTES as NULLABLE
	DECLARE
	   already_null EXCEPTION;
	   PRAGMA EXCEPTION_INIT(already_null, -1451);
	BEGIN
	   execute immediate 'ALTER TABLE CC_F_AGENT_BY_DATE MODIFY (SCHEDULED_SHIFT_MINUTES NULL)';
	EXCEPTION
	   WHEN already_null THEN
		  null; -- do nothing
	END;

	--SET CC_F_AGENT_BY_DATE.ACTUAL_SHIFT_MINUTES as NULLABLE
	DECLARE
	   already_null EXCEPTION;
	   PRAGMA EXCEPTION_INIT(already_null, -1451);
	BEGIN
	   execute immediate 'ALTER TABLE CC_F_AGENT_BY_DATE MODIFY (ACTUAL_SHIFT_MINUTES NULL)';
	EXCEPTION
	   WHEN already_null THEN
		  null; -- do nothing
	END;

	--SET CC_F_AGENT_BY_DATE.ACTUAL_OVERTIME_MINUTES as NULLABLE
	DECLARE
	   already_null EXCEPTION;
	   PRAGMA EXCEPTION_INIT(already_null, -1451);
	BEGIN
	   execute immediate 'ALTER TABLE CC_F_AGENT_BY_DATE MODIFY (ACTUAL_OVERTIME_MINUTES NULL)';
	EXCEPTION
	   WHEN already_null THEN
		  null; -- do nothing
	END;
END;