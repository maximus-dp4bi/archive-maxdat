--------------------------------------------------------
--  File created - Friday-September-13-2013   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Sequence SEQ_CC_S_IVR_SELF_SERVICE_PATH
--------------------------------------------------------

   CREATE SEQUENCE  "SEQ_CC_S_IVR_SELF_SERVICE_PATH"  MINVALUE 1 MAXVALUE 9999999999999999999 INCREMENT BY 1 START WITH 181 CACHE 20 NOORDER  NOCYCLE ;
