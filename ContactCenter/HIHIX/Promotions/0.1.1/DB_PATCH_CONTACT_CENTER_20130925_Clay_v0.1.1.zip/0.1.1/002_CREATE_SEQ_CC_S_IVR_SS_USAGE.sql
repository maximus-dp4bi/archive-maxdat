--------------------------------------------------------
--  File created - Friday-September-13-2013   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Sequence SEQ_CC_S_IVR_SS_USAGE
--------------------------------------------------------

   CREATE SEQUENCE  "SEQ_CC_S_IVR_SS_USAGE"  MINVALUE 1 MAXVALUE 9999999999999999999 INCREMENT BY 1 START WITH 101 CACHE 20 NOORDER  NOCYCLE ;
