
update d_metric_definition set status = 'Active' where status = 'OK';

commit;