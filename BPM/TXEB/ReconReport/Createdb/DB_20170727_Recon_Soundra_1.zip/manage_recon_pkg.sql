alter session set plsql_code_type = native;

create or replace package manage_recon is

function ins_p79daily(p_job_id in number) return varchar2;

end;
/

create or replace package body manage_recon as

function ins_p79daily(p_job_id in number) return varchar2 is
v_count number;
begin
  begin
    select count(1)
    into v_count
    from tx_etl_recon_ctrl
    where job_name = 'P79Daily'
    and job_slice = 1
    and job_id = p_job_id
    and status in ('DONE','PEND','WORK');

  exception when no_data_found then
            v_count := 0;
  end;
  if v_count > 0 then
    return 'NO';
  end if;
  insert into tx_etl_recon_ctrl ( job_name , job_slice , job_id ) values
                                  ('P79Daily', 1, p_job_id);
  commit;
  return 'YES';
end;

end;
/

alter session set plsql_code_type = interpreted;