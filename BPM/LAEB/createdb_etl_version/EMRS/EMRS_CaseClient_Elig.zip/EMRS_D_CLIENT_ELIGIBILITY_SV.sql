CREATE OR REPLACE VIEW EMRS_D_CLIENT_ELIGIBILITY_SV
AS
SELECT CSI.CLIENT_CIN Medicaid_ID,
         CSI.LAST_NAME  LAST_NAME,
         CSI.FIRST_NAME FIRST_NAME,
         'LTC'          SEGMENT_TYPE_CD,
         esad1.start_date LTC_START_DATE
    FROM emrs_d_client_eligibility ces
         INNER JOIN emrs_d_client_supplementary_info csi
             ON ces.client_id = CSI.CLIENT_ID
         INNER JOIN emrs_d_elig_segment_details esad1
             ON     esad1.client_id = ces.client_id
                AND esad1.segment_type_cd = 'LTC'
                AND esad1.start_nd < TO_CHAR (SYSDATE - 30, 'YYYYMMDD')
                AND esad1.end_nd > TO_CHAR (LAST_DAY (SYSDATE), 'YYYYMMDD')
   WHERE     CES.ELIG_STATUS_CD IN ('M', 'V')
         AND CES.END_DATE IS NULL
         --AND ces.SUBPROGRAM_TYPE = 'BH_ONLY'
         AND CES.MVX_CORE_REASON LIKE 'X29%'
         AND EXISTS
                 (SELECT 1
                    FROM emrs_d_elig_segment_details esad2
                   WHERE     esad2.client_id = ces.client_id
                         AND esad2.segment_type_cd = 'MI'
                         AND esad2.end_nd = 20501231
                         AND esad2.SEGMENT_DETAIL_VALUE_1 = 'B')
         AND EXISTS
                 (SELECT 1
                    FROM emrs_d_elig_segment_details esad
                   WHERE     esad.client_id = ces.client_id
                         AND ESAD.SEGMENT_TYPE_CD = 'ME'
                         AND ESAD.END_ND >
                                 TO_CHAR (LAST_DAY (SYSDATE), 'YYYYMMDD')
                         AND    ESAD.SEGMENT_DETAIL_VALUE_1
                             || '-'
                             || ESAD.SEGMENT_DETAIL_VALUE_2 IN
                                 (SELECT AID_Category || '-' || TYPE_CASE
                                    FROM D_MVX_XWALK
                                   WHERE     ACUTE_MVX IN ('M', 'V - Opt-In')
                                         AND EFFECTIVE_END_DATE IS NULL))
;

GRANT SELECT ON EMRS_D_CLIENT_ELIGIBILITY_SV TO &role_name;

