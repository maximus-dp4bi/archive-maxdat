CREATE OR REPLACE VIEW EMRS_D_CLIENT_ELIG_OUTCOME_SV
AS
SELECT clnt.clnt_cin      medicaid_id,
       CLNT.CLNT_LNAME    last_name,
       clnt.clnt_fname    first_name,
       CLNT.CLNT_SSN,
       CLNT.CLNT_DOB,  
       ST.SELECTION_GENERIC_FIELD5_TXT,    
       esad.eligibility_outcome,
       esad.me_start_date,
       esad.me_end_date,
       county.county_code county_code,
       county.county_name county_desc
  FROM (SELECT * FROM emrs_d_client_eligibility cels       
        WHERE cels.subprogram_type IN ('BH_ONLY')
        AND cels.end_date IS NULL ) cels
     INNER JOIN emrs_d_selection_txn st
        ON     st.client_id = cels.client_id
       AND ST.SELECTION_GENERIC_FIELD5_TXT = 'B'
       AND st.status_cd = 'acceptedByState'
       AND TRUNC (st.status_date) = TRUNC (SYSDATE - 1)          
     INNER JOIN emrs_d_client clnt ON clnt.client_id = st.client_id
     INNER JOIN emrs_d_case_client CSE_CLNT
       ON     CSE_CLNT.client_id = st.client_id
      AND cse_clnt.cscl_status_cd = 'O'
     INNER JOIN emrs_d_address addr ON cse_clnt.cscl_res_addr_id = addr.addr_id
     INNER JOIN emrs_d_county county ON county.county_code = addr.addr_ctlk_id
     INNER JOIN emrs_d_elig_segment_details esad2
       ON     esad2.segment_type_cd = 'ME'
       AND esad2.client_id = st.client_id
       AND esad2.end_nd >= TO_CHAR (SYSDATE, 'YYYYMMDD')
       AND ESAD2.SEGMENT_DETAIL_VALUE_2 = '550'
     INNER JOIN emrs_d_elig_segment_details esad1
       ON     esad1.segment_type_cd = 'MI'
       AND esad1.client_id = st.client_id
       AND esad1.end_nd > esad1.start_nd
       AND ESAD1.start_nd = ST.START_ND
       AND ESAD1.SEGMENT_DETAIL_VALUE_2 = ST.PLAN_ID_EXT
       AND transaction_type_cd IN ('Transfer', 'NewEnrollment', 'DefaultEnroll')
     INNER JOIN ( SELECT client_id,
                         'CHISHOLM'          Eligibility_Outcome,
                          esad.start_date    ME_Start_Date,
                          esad.end_date      ME_End_Date
                  FROM   emrs_d_elig_segment_details esad          
                  WHERE esad.segment_type_cd = 'ELIG'
                    --first day of next month
                  AND esad.end_date > LAST_DAY (ADD_MONTHS (SYSDATE, 0)) + 1 
                  UNION
                  SELECT client_id,
                         'MA/MB'            Eligibility_Outcome,
                         esad.start_date    ME_Start_Date,
                         esad.end_date      ME_End_Date
                  FROM emrs_d_elig_segment_details esad 
                  WHERE  esad.segment_type_cd = 'OHC'
                  AND esad.segment_detail_value_1 IN ('MA', 'MB')
                  AND esad.end_nd = 20501231
                  UNION
                  SELECT client_id,
                        'LTC'              Eligibility_Outcome,
                         esad.start_date    ME_Start_Date,
                         esad.end_date      ME_End_Date
                  FROM  emrs_d_elig_segment_details esad 
                  WHERE  esad.segment_type_cd ='LTC'
                  AND (esad.end_date IS NULL OR TRUNC(esad.end_date) = '31-DEC-2050') 
                  UNION
                  SELECT client_id,
                         '17/095 Medicare'  Eligibility_Outcome,
                         esad.start_date   ME_Start_Date,
                         esad.end_date     ME_End_Date
                  FROM  emrs_d_elig_segment_details esad 
                  WHERE  esad.segment_type_cd ='ME'
                  AND esad.end_nd >= TO_CHAR (SYSDATE, 'YYYYMMDD')
                  AND esad.segment_detail_value_2 = '095' ) esad ON esad.client_id = cels.client_id;	



grant select on EMRS_D_CLIENT_ELIG_OUTCOME_SV to &role_name;