insert into BPM_D_HOURS (D_HOUR) values ( 0);
insert into BPM_D_HOURS (D_HOUR) values ( 1);
insert into BPM_D_HOURS (D_HOUR) values ( 2);
insert into BPM_D_HOURS (D_HOUR) values ( 3);
insert into BPM_D_HOURS (D_HOUR) values ( 4);
insert into BPM_D_HOURS (D_HOUR) values ( 5);
insert into BPM_D_HOURS (D_HOUR) values ( 6);
insert into BPM_D_HOURS (D_HOUR) values ( 7);
insert into BPM_D_HOURS (D_HOUR) values ( 8);
insert into BPM_D_HOURS (D_HOUR) values ( 9);
insert into BPM_D_HOURS (D_HOUR) values (10);
insert into BPM_D_HOURS (D_HOUR) values (11);
insert into BPM_D_HOURS (D_HOUR) values (12);
insert into BPM_D_HOURS (D_HOUR) values (13);
insert into BPM_D_HOURS (D_HOUR) values (14);
insert into BPM_D_HOURS (D_HOUR) values (15);
insert into BPM_D_HOURS (D_HOUR) values (16);
insert into BPM_D_HOURS (D_HOUR) values (17);
insert into BPM_D_HOURS (D_HOUR) values (18);
insert into BPM_D_HOURS (D_HOUR) values (19);
insert into BPM_D_HOURS (D_HOUR) values (20);
insert into BPM_D_HOURS (D_HOUR) values (21);
insert into BPM_D_HOURS (D_HOUR) values (22);
insert into BPM_D_HOURS (D_HOUR) values (23);

commit;

