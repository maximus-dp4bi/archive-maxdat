insert into BPM_DATA_MODEL (BDM_ID,CODE,NAME) values (1,'BPM_EVENT','BPM Event');
insert into BPM_DATA_MODEL (BDM_ID,CODE,NAME) values (2,'BPM_SEMANTIC','BPM Semantic');

commit;
