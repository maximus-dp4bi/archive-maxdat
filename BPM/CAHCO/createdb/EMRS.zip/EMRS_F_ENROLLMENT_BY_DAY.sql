CREATE OR REPLACE VIEW EMRS_F_ENROLLMENT_BY_DAY_SV
AS
SELECT d_date
       ,SUM(forms_received) forms_received
       ,SUM(forms_processed) forms_processed
       ,SUM(forms_inventory) forms_inventory
       ,SUM(transfers_processed) transfers_processed
       ,SUM(exemptions_processed) exemptions_processed              
       ,ROUND(SUM(forms_enroll_process_time)/CASE WHEN SUM(forms_enrolled) = 0 THEN 1 ELSE SUM(forms_enrolled) END,1) forms_avg_enroll_process_time
       ,ROUND(SUM(forms_manual_enrl_process_time)/CASE WHEN SUM(forms_manual_enroll) = 0 THEN 1 ELSE SUM(forms_manual_enroll) END,1) forms_avg_manual_enroll_process_time
       ,ROUND(SUM(forms_process_time_days)/CASE WHEN SUM(forms_processed) = 0 THEN 1 ELSE SUM(forms_processed) END,1) forms_avg_process_time_in_days
       ,SUM(forms_processed_timely) forms_processed_timely
       ,SUM(forms_processed_untimely) forms_processed_untimely  
       ,SUM(forms_remaining) forms_remaining
FROM (
SELECT d_date
       ,forms_received
       ,forms_processed
       ,LAG(forms_remaining, 1, 0) OVER (ORDER BY d_date) forms_inventory
       ,0 transfers_processed
       ,0 exemptions_processed   
       ,forms_enroll_process_time
       ,forms_manual_enrl_process_time
       ,forms_process_time_days
       ,forms_processed_timely
       ,forms_processed_untimely
       ,forms_enrolled
       ,forms_manual_enroll
       ,forms_remaining
FROM  
  (SELECT f.*
         ,SUM(forms_remaining_cnt) OVER (ORDER BY d_date) forms_remaining
  FROM 
   (SELECT d_date
       ,COUNT(DISTINCT f.dcn) forms_received
       ,COUNT(DISTINCT CASE WHEN processed_date IS NOT NULL THEN f.dcn ELSE null END) forms_processed
       ,COUNT(DISTINCT f.dcn) - COUNT(DISTINCT CASE WHEN processed_date IS NOT NULL THEN f.dcn ELSE null END) forms_remaining_cnt
       ,0 transfers_processed
       ,0 exemptions_processed   
       ,SUM(days_to_process_enrl) forms_enroll_process_time
       ,SUM(CASE WHEN form_manually_entered = 'Y'  THEN days_to_process ELSE 0 END) forms_manual_enrl_process_time
       ,SUM(days_to_process) forms_process_time_days
       ,COUNT(DISTINCT CASE WHEN processed_date IS NOT NULL AND days_to_process <= TO_NUMBER(sla_days) THEN f.dcn ELSE null END) forms_processed_timely
       ,COUNT(DISTINCT CASE WHEN processed_date IS NOT NULL AND days_to_process > TO_NUMBER(sla_days) THEN f.dcn ELSE null END) forms_processed_untimely
       ,COUNT(DISTINCT CASE WHEN enrollment_id IS NOT NULL THEN f.dcn ELSE null END) forms_enrolled
       ,COUNT(DISTINCT CASE WHEN form_manually_entered = 'Y' THEN f.dcn ELSE null END) forms_manual_enroll
   FROM  bpm_d_dates dd
     LEFT JOIN (SELECT DISTINCT df.dcn,processed_date,form_manually_entered,enrollment_id,cl.out_var sla_days,df.date_form_received,
               CASE WHEN processed_date IS NOT NULL AND processed_date >= date_form_received THEN 
                (SELECT CASE WHEN (COUNT(*)-1) < 0  THEN 0 ELSE COUNT(*)-1  END
                 FROM D_DATES_SV
                 WHERE business_day_flag = 'Y'
                 AND d_date BETWEEN TRUNC(date_form_received) AND TRUNC(processed_date) ) ELSE 0 END days_to_process,
               CASE WHEN enrollment_id IS NOT NULL AND transaction_date >= date_form_received THEN 
                (SELECT CASE WHEN (COUNT(*)-1) < 0  THEN 0 ELSE COUNT(*)-1  END
                 FROM D_DATES_SV
                 WHERE business_day_flag = 'Y'
                 AND d_date BETWEEN TRUNC(date_form_received) AND TRUNC(transaction_date) ) ELSE 0 END days_to_process_enrl                  
             FROM hco_d_form df
               LEFT JOIN emrs_d_selection_trans st ON df.enrollment_id = st.selection_transaction_id
              JOIN corp_etl_list_lkup cl ON df.form_type = cl.name AND cl.list_type = 'FORM_SLA_DAYS' ) f ON dd.d_date = TRUNC(f.date_form_received) AND f.dcn IS NOT NULL
   GROUP BY d_date) f 
    ) f 
UNION ALL
SELECT d_date
       ,0 forms_received
       ,0 forms_processed
       ,0 forms_inventory
       ,COUNT(selection_transaction_id) transfers_processed
       ,0 exemptions_processed
       ,0 forms_enroll_process_time
       ,0 forms_manual_enrl_process_time
       ,0 forms_process_time_days
       ,0 forms_processed_timely
       ,0 forms_processed_untimely
       ,0 forms_enrolled
       ,0 forms_manual_enroll
       ,0 forms_remaining
FROM  bpm_d_dates dd
  LEFT JOIN emrs_d_selection_trans st ON dd.d_date = TRUNC(st.record_date) AND transfer_flag = 'Y'  
     AND record_name  NOT IN ('errorusr', 'recon', 'newelig', 'newelg','errusr','errmed','rcnfix') AND st.plan_id <> st.prior_plan_id
GROUP BY d_date
UNION ALL
SELECT d_date
       ,0 forms_received
       ,0 forms_processed
       ,0 forms_inventory
       ,0 transfers_processed
       ,COUNT(exemption_id) exemptions_processed       
       ,0 forms_enroll_process_time
       ,0 forms_manual_enrl_process_time
       ,0 forms_process_time_days
       ,0 forms_processed_timely
       ,0 forms_processed_untimely
       ,0 forms_enrolled
       ,0 forms_manual_enroll       
       ,0 forms_remaining
FROM bpm_d_dates dd
  LEFT JOIN emrs_d_exemption_req ON dd.d_date = TRUNC(disposition_date)
GROUP BY d_date  
)
GROUP BY d_date
;

GRANT SELECT ON "EMRS_F_ENROLLMENT_BY_DAY_SV" TO "MAXDAT_READ_ONLY";