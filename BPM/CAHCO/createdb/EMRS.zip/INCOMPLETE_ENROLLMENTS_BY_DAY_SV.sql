
CREATE OR REPLACE VIEW INCOMPLETE_ENROLLMENTS_BY_DAY_SV
AS 
SELECT d_date
      ,st.plan_id
      ,st.plan_name
      ,st.county_code      
      ,CASE WHEN st.plan_type = 'M' THEN 'M' ELSE 'D' END plan_type
      ,'Incomplete'  type
      ,st.county_name
      ,plan_change_reason_code
      ,transaction_type
      ,COUNT(DISTINCT dcn) dcn_count
FROM bpm_d_dates dd
  LEFT JOIN (SELECT d.form_incomplete_create_date,d.dcn,ct.county_name,ct.county_code,p.plan_id,p.plan_name,p.plan_type,
                  CASE WHEN st.transaction_type_cd not in ('1','5') AND (st.change_reason_code IS NULL OR LENGTH(st.change_reason_code)=0) 
                      THEN 'F10' ELSE st.change_reason_code END plan_change_reason_code,
                   CASE WHEN st.transaction_type_cd = '6' THEN 'FFS Choice' ELSE tt.enrollment_trans_type END transaction_type
             FROM hco_d_form d
              LEFT JOIN emrs_d_selection_trans st ON st.selection_transaction_id = d.enrollment_id
                  AND transaction_type_cd in ('1','2','3','5','6','8')
                  AND SUBSTR(d.esr_id,1,3) = 'PLN'
                  AND st.record_name NOT IN ('errorusr', 'recon', 'newelig', 'newelg', 'errusr', 'errmed', 'rcnfix')              
                  AND st.disregard_trans_ind = 'N'              
                  AND (st.non_meds_ind = 'N' OR (st.non_meds_ind = 'Y' AND st.switch_to_meds_ind = 'Y'))
              LEFT JOIN emrs_d_enroll_trans_type tt ON st.transaction_type_cd = tt.enrollment_trans_type_code
              LEFT JOIN emrs_d_plan p ON TRIM(SUBSTR(d.esr_id,4,3)) = p.plan_id
              LEFT JOIN emrs_d_county ct ON p.county_code = ct.county_code
             WHERE form_incomplete = 'Y' 
             AND SUBSTR(esr_id,1,3) = 'PLN' ) st  ON dd.d_date = TRUNC(st.form_incomplete_create_date)     
GROUP BY d_date
      ,st.plan_id
      ,st.plan_name
      ,st.county_code      
      ,CASE WHEN st.plan_type = 'M' then 'M' else 'D' end 
      ,st.county_name
      ,plan_change_reason_code
      ,transaction_type
UNION ALL
SELECT d_date
      ,st.plan_id
      ,st.plan_name
      ,st.county_code      
      ,CASE WHEN st.plan_type = 'M' THEN 'M' ELSE 'D' END plan_type
      , 'Processed' type
      ,st.county_name
      ,st.plan_change_reason_code
      ,st.transaction_type
      ,COUNT(DISTINCT st.dcn) dcn_count
FROM bpm_d_dates dd  
  LEFT JOIN (SELECT st.transaction_date,d.dcn, ct.county_name,ct.county_code,p.plan_id,p.plan_name,p.plan_type, 
                   CASE WHEN st.transaction_type_cd not in ('1','5') AND (st.change_reason_code IS NULL OR LENGTH(st.change_reason_code)=0) 
                      THEN 'F10' ELSE st.change_reason_code END plan_change_reason_code,
                   CASE WHEN st.transaction_type_cd = '6' THEN 'FFS Choice' ELSE tt.enrollment_trans_type END transaction_type                   
             FROM hco_d_form d
               JOIN emrs_d_selection_trans st ON st.selection_transaction_id = d.enrollment_id
               JOIN emrs_d_plan p ON TRIM(SUBSTR(d.esr_id,4,3)) = p.plan_id
               JOIN emrs_d_county ct ON p.county_code = ct.county_code
               JOIN emrs_d_enroll_trans_type tt ON st.transaction_type_cd = tt.enrollment_trans_type_code
             WHERE d.form_incomplete = 'N'
             AND transaction_type_cd in ('1','2','3','5','6','8')
             AND SUBSTR(d.esr_id,1,3) = 'PLN'
             AND st.record_name NOT IN ('errorusr', 'recon', 'newelig', 'newelg', 'errusr', 'errmed', 'rcnfix')              
             AND st.disregard_trans_ind = 'N'              
             AND (st.non_meds_ind = 'N' OR (st.non_meds_ind = 'Y' AND st.switch_to_meds_ind = 'Y')))st ON dd.d_date = TRUNC(st.transaction_date) 
GROUP BY d_date  
       ,st.plan_id
      ,st.plan_name
      ,st.county_code      
      ,CASE WHEN st.plan_type = 'M' then 'M' else 'D' end 
      ,st.county_name
      ,st.plan_change_reason_code
      ,st.transaction_type      
;

GRANT SELECT ON "INCOMPLETE_ENROLLMENTS_BY_DAY_SV" TO "MAXDAT_READ_ONLY";