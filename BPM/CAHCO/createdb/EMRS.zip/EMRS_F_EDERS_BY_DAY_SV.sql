CREATE OR REPLACE VIEW EMRS_F_EDERS_BY_DAY_SV
AS
SELECT d_date  
  ,eders_med_processed  
  ,CASE WHEN eders_med_remaining < 0 THEN 0 ELSE LAG(eders_med_remaining, 1, 0) OVER (ORDER BY d_date) END eders_med_inventory
  ,eders_med_received
  ,eders_med_remaining
  ,eders_med_received_back
  ,eders_med_denied
  ,eders_med_approved
  ,eders_med_processed_timely
  ,eders_med_processed_untimely
  ,eders_den_processed
  ,CASE WHEN eders_den_remaining < 0 THEN 0 ELSE LAG(eders_den_remaining, 1, 0) OVER (ORDER BY d_date) END eders_den_inventory
  ,eders_den_received
  ,eders_den_remaining
  ,eders_den_received_back
  ,eders_den_denied
  ,eders_den_approved
  ,eders_den_processed_timely
  ,eders_den_processed_untimely
  ,eders_retro_processed
  ,CASE WHEN eders_retro_remaining < 0 THEN 0 ELSE LAG(eders_retro_remaining, 1, 0) OVER (ORDER BY d_date) END eders_retro_inventory
  ,eders_retro_received
  ,eders_retro_remaining
  ,eders_retro_received_back
  ,eders_retro_denied
  ,eders_retro_approved
  ,eders_retro_processed_timely
  ,eders_retro_processed_untimely  
  ,ROUND(eders_med_process_time/CASE WHEN eders_med_processed = 0 THEN 1 ELSE eders_med_processed END,1) eders_med_avg_process_time
  ,ROUND(eders_den_process_time/CASE WHEN eders_den_processed = 0 THEN 1 ELSE eders_den_processed END,1) eders_den_avg_process_time
  ,eders_med_pending
  ,eders_den_pending
  ,ROUND(eders_retro_process_time/CASE WHEN eders_retro_processed = 0 THEN 1 ELSE eders_retro_processed END,1) eders_retro_avg_process_time
FROM (
 SELECT  d.*
        ,sum(eders_med_received - eders_med_processed) over (order by d_date)  eders_med_remaining
        ,sum(eders_den_received - eders_den_processed) over (order by d_date)  eders_den_remaining
        ,sum(eders_retro_received - eders_retro_processed) over (order by d_date)  eders_retro_remaining        
 FROM (SELECT d_date     
       ,COUNT(DISTINCT CASE WHEN proc.processed_date IS NOT NULL AND proc.plan_type = 'M' THEN proc.emrgcy_disenroll_id ELSE null END) eders_med_processed     
       ,COUNT(DISTINCT CASE WHEN pt.plan_type = 'M' THEN d.emrgcy_disenroll_id ELSE NULL END) eders_med_received     
       ,COUNT(DISTINCT CASE WHEN pt.plan_type = 'M' THEN rb.rcvd_back_denr_id ELSE NULL END) eders_med_received_back
       ,COUNT(DISTINCT CASE WHEN proc.denial_status_date IS NOT NULL AND proc.plan_type = 'M' THEN proc.emrgcy_disenroll_id ELSE null END) eders_med_denied
       ,COUNT(DISTINCT CASE WHEN proc.approved_status_date IS NOT NULL AND proc.plan_type = 'M' THEN proc.emrgcy_disenroll_id ELSE null END) eders_med_approved
       ,COUNT(DISTINCT CASE WHEN (proc.days_to_process <= TO_NUMBER(cl.out_var) AND proc.plan_type = 'M') --OR proc.emrgcy_denr_status_code IN('5','P') 
         THEN proc.emrgcy_disenroll_id ELSE NULL END) eders_med_processed_timely
       ,COUNT(DISTINCT CASE WHEN proc.days_to_process > TO_NUMBER(cl.out_var) AND proc.plan_type = 'M' THEN proc.emrgcy_disenroll_id ELSE NULL END) eders_med_processed_untimely       
       
       ,COUNT(DISTINCT CASE WHEN proc.processed_date IS NOT NULL AND proc.plan_type = 'D' THEN proc.emrgcy_disenroll_id ELSE null END) eders_den_processed       
       ,COUNT(DISTINCT CASE WHEN pt.plan_type = 'D' THEN d.emrgcy_disenroll_id ELSE NULL END) eders_den_received       
       ,COUNT(DISTINCT CASE WHEN pt.plan_type = 'D' THEN rb.rcvd_back_denr_id ELSE NULL END) eders_den_received_back
       ,COUNT(DISTINCT CASE WHEN proc.denial_status_date IS NOT NULL AND proc.plan_type = 'D' THEN proc.emrgcy_disenroll_id ELSE null END) eders_den_denied
       ,COUNT(DISTINCT CASE WHEN proc.approved_status_date IS NOT NULL AND proc.plan_type = 'D' THEN proc.emrgcy_disenroll_id ELSE null END) eders_den_approved
       ,COUNT(DISTINCT CASE WHEN proc.days_to_process <= TO_NUMBER(cl.out_var) AND proc.plan_type = 'D' --OR proc.emrgcy_denr_status_code IN('5','P') 
            THEN proc.emrgcy_disenroll_id ELSE NULL END) eders_den_processed_timely
       ,COUNT(DISTINCT CASE WHEN proc.days_to_process > TO_NUMBER(cl.out_var) AND proc.plan_type = 'D' THEN proc.emrgcy_disenroll_id ELSE NULL END) eders_den_processed_untimely       

       ,COUNT(DISTINCT CASE WHEN proc.processed_date IS NOT NULL AND proc.retro_disenroll = 'Y' THEN proc.emrgcy_disenroll_id ELSE null END) eders_retro_processed       
       ,COUNT(DISTINCT CASE WHEN d.retro_disenroll = 'Y' THEN d.emrgcy_disenroll_id ELSE NULL END) eders_retro_received       
       ,COUNT(DISTINCT CASE WHEN rb.rcvd_back_retro = 'Y' THEN rcvd_back_denr_id ELSE NULL END) eders_retro_received_back
       ,COUNT(DISTINCT CASE WHEN proc.denial_status_date IS NOT NULL AND proc.retro_disenroll = 'Y'  THEN proc.emrgcy_disenroll_id ELSE null END) eders_retro_denied
       ,COUNT(DISTINCT CASE WHEN proc.approved_status_date IS NOT NULL AND proc.retro_disenroll = 'Y'  THEN proc.emrgcy_disenroll_id ELSE null END) eders_retro_approved
       ,COUNT(DISTINCT CASE WHEN proc.days_to_process <= TO_NUMBER(cl.out_var) AND proc.retro_disenroll = 'Y' THEN proc.emrgcy_disenroll_id ELSE NULL END) eders_retro_processed_timely
       ,COUNT(DISTINCT CASE WHEN proc.days_to_process > TO_NUMBER(cl.out_var) AND proc.retro_disenroll = 'Y' THEN proc.emrgcy_disenroll_id ELSE NULL END) eders_retro_processed_untimely       
       ,SUM(CASE WHEN proc.plan_type = 'M' THEN proc.days_to_process ELSE 0 END) eders_med_process_time
       ,SUM(CASE WHEN proc.plan_type = 'D' THEN proc.days_to_process ELSE 0 END) eders_den_process_time
       ,SUM(CASE WHEN proc.retro_disenroll = 'Y' THEN proc.days_to_process ELSE 0 END) eders_retro_process_time
       ,COUNT(DISTINCT CASE WHEN proc.pending_status_date IS NOT NULL AND proc.emrgcy_denr_status_code NOT IN('2','4','B','D','M') AND proc.plan_type = 'M' THEN proc.emrgcy_disenroll_id ELSE null END) eders_med_pending
       ,COUNT(DISTINCT CASE WHEN proc.pending_status_date IS NOT NULL AND proc.emrgcy_denr_status_code NOT IN('2','4','B','D','M') AND proc.plan_type = 'D' THEN proc.emrgcy_disenroll_id ELSE null END) eders_den_pending
  FROM bpm_d_dates dd
    CROSS JOIN emrs_d_plan_type pt
    JOIN corp_etl_list_lkup cl ON cl.name = 'EDER' AND cl.list_type = 'FORM_SLA_DAYS'
    LEFT JOIN emrs_d_emrgcy_disenroll d ON pt.plan_type = d.plan_type AND dd.d_date = TRUNC(d.record_date)
    LEFT JOIN(SELECT retro_disenroll,
                   d.plan_type,
                   dcn,
                   emrgcy_denr_status_code,
                   record_date,
                   approved_status_date,
                   denial_status_date,
                   pending_status_date,
                   emrgcy_disenroll_id,
                   TRUNC(COALESCE(approved_status_date,denial_status_date,pending_status_date)) processed_date,
                   --TRUNC(COALESCE(approved_status_date,denial_status_date)) processed_date,                     
                   CASE WHEN COALESCE(approved_status_date,denial_status_date) IS NOT NULL AND COALESCE(approved_status_date,denial_status_date,pending_status_date) >= record_date THEN 
                     (SELECT CASE WHEN (COUNT(*)-1) < 0  THEN 0 ELSE COUNT(*)-1  END
                      FROM D_DATES_SV
                      WHERE business_day_flag = 'Y'
                      AND d_date BETWEEN TRUNC(record_date) AND TRUNC(COALESCE(approved_status_date,denial_status_date,pending_status_date)) ) ELSE 0 END days_to_process
            FROM emrs_d_emrgcy_disenroll d
            WHERE (emrgcy_denr_status_code IN('2','4','B','D','M')
              OR pending_status_date IS NOT NULL )) proc ON pt.plan_type = proc.plan_type AND dd.d_date = proc.processed_date
    LEFT JOIN (SELECT TRUNC(h.record_date) received_back_date,
                    plan_type,
                    emrgcy_denr_id rcvd_back_denr_id, 
                    retro_disenroll rcvd_back_retro                    
             FROM emrs_d_emrgcy_denr_hist h
               JOIN emrs_d_emrgcy_disenroll d ON h.emrgcy_denr_id = d.emrgcy_disenroll_id
             WHERE h.emrgcy_denr_status_code IN('1','R','3')  )  rb ON pt.plan_type = rb.plan_type AND dd.d_date = rb.received_back_date          
   GROUP BY dd.d_date) d
 ) f;
 
 GRANT SELECT ON "EMRS_F_EDERS_BY_DAY_SV" TO "MAXDAT_READ_ONLY";
 