CREATE OR REPLACE VIEW hco_f_inventory_by_day_sv
AS
SELECT COALESCE(inv.item_id,0) item_id
       ,d.d_date
       ,COALESCE(quantity_on_hand,0) quantity_on_hand
       ,COALESCE(daily_usage,0) usage
FROM bpm_d_dates d 
 LEFT JOIN hco_d_item_inventory inv ON d.d_date = TRUNC(inv.date_record_created)
--GROUP BY inv.item_id,d.d_date
;

GRANT SELECT ON "HCO_F_INVENTORY_BY_DAY_SV" TO "MAXDAT_READ_ONLY";

CREATE OR REPLACE VIEW hco_f_inventory_by_month_sv
AS
SELECT COALESCE(inv.item_id,0) item_id
       ,d.d_month
       ,d.d_month_short_name||' '||d.d_year month_shortname_year
       ,SUM(COALESCE(quantity_on_hand,0)) quantity_on_hand
       ,SUM(COALESCE(monthly_usage,0)) usage
FROM bpm_d_dates d 
 LEFT JOIN hco_d_item_inventory inv ON d.d_date = TRUNC(inv.date_record_created)
GROUP BY inv.item_id,d.d_month,d.d_month_short_name,d.d_year ;

GRANT SELECT ON "HCO_F_INVENTORY_BY_MONTH_SV" TO "MAXDAT_READ_ONLY";

