insert into CORP_ETL_CONTROL
values ('HCO_MATERIALORDER_CREATE_DATE','D','2018/01/01 00:00:00','Max material order creation date from source', sysdate, sysdate);

insert into CORP_ETL_CONTROL
values ('HCO_MATERIALORDER_UPDATE_DATE','D','2018/01/01 00:00:00','Max material order update date from source', sysdate, sysdate);

insert into CORP_ETL_CONTROL
values ('HCO_LETTERMAILING_UPDATE_DATE','D','2018/01/01 00:00:00','Max letter mailing creation date from source', sysdate, sysdate);

insert into CORP_ETL_CONTROL
values ('HCO_PACKETMAILING_UPDATE_DATE','D','2018/01/01 00:00:00','Max letter mailing creation date from source', sysdate, sysdate);

insert into CORP_ETL_CONTROL
values ('HCO_MAILING_CREATE_DATE','D','2018/01/01 00:00:00','Date parameter to use to extract custom mailing indicator', sysdate, sysdate);

insert into CORP_ETL_CONTROL
values ('HCO_ITEMINVENTORY_CREATE_DATE','D','2018/01/01 00:00:00','Max item inventory creation date from source', sysdate, sysdate);

insert into CORP_ETL_CONTROL
values ('HCO_ITEMINVENTORY_UPDATE_DATE','D','2018/01/01 00:00:00','Max item inventory update date from source', sysdate, sysdate);


commit;

