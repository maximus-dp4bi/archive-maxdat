delete corp_bpm_mv_refresh where process = 'ManageWork' and refresh_name = 'V_D_AGE_IN_CALENDAR_DAYS';
delete corp_bpm_mv_refresh where process = 'ManageWork' and refresh_name = 'V_D_STATUS_AGE_IN_CAL_DAYS';
delete corp_bpm_mv_refresh where process = 'ManageWork' and refresh_name = 'V_D_CANCEL_WORK_FLAG';
delete corp_bpm_mv_refresh where process = 'ManageWork' and refresh_name = 'V_D_COMPLETE_FLAG';
delete corp_bpm_mv_refresh where process = 'ManageWork' and refresh_name = 'V_D_JEOPARDY_FLAG';
delete corp_bpm_mv_refresh where process = 'ManageWork' and refresh_name = 'V_D_TIMELINESS_STATUS';
commit;
